# RYOOXIT Driver Loader status — candidate scan fix

## Updated behavior
- Kernel release parsing now extracts the numeric release from vendor-suffixed `uname -r` values (for example `6.12.38-android16-5-...` -> `6.12.38`).
- Candidate discovery compares the kernel major.minor against generic bundles such as `6.12.sh`, and exact patch bundles such as `6.12.23.sh` only against the same patch release.
- The terminal reports selected family, parsed release, number of bundled assets, and exact candidate filenames.
- Changing RT/RTHook family clears the previous selection and resets driver status.

## Safety policy remains
Candidate discovery is not proof of compatibility. Bundled driver assets contain an embedded ELF payload and root-level operations. The Load action remains disabled until the ELF architecture, module metadata (vermagic/dependencies/symbol CRCs), provenance, and script side effects are reviewed. No driver is executed by this build.

## Expected result for Infinix X6853 / kernel 6.12.38
- RT: `6.12.sh` appears as a filename candidate.
- RTHook: `6.12.23.sh` and `6.12.58.sh` do not appear as exact patch matches for `6.12.38`.
- A visible candidate must be labelled as unverified, not compatible.
