# RYOOXIT Android Project

Project Android native berbasis Kotlin + XML.

## Navigasi dan Driver Loader

Navigasi utama hanya menyediakan **Home**, **File Manager**, dan **Profile**. Halaman Home memuat panel Driver Loader yang membaca versi kernel dengan `uname -r` dan menampilkan kandidat aset RT/RTHook. Tombol Load sengaja dinonaktifkan sampai kompatibilitas driver dibuktikan melalui pemeriksaan kernel, ABI, simbol, dan checksum. Kecocokan nama versi saja tidak cukup untuk memuat modul kernel.

## Build

Buka folder project ini di Android Studio, atau gunakan workflow GitHub Actions pada `.github/workflows/build.yml`. Jalankan workflow manual untuk menghasilkan APK **debug** uji coba tanpa keystore release. Event GitHub Release menghasilkan APK **release** dan tetap memerlukan keystore resmi yang cocok dengan hash `EXPECTED_SHA256` di `app/src/main/java/com/ryooxit/app/MainActivity.kt`. Jangan distribusikan APK debug.
