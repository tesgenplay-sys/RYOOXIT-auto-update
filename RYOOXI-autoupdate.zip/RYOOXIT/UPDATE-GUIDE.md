# Update otomatis RyooXIT (build & rilis lewat GitHub Actions)

## Setup sekali (bisa dari HP)
1. Repo publik: tesgenplay-sys/RYOOXIT-auto-update. Aktifkan 2FA di akun GitHub.
2. Unggah project ke root repo: cukup unggah file `RYOOXIT-autoupdate.zip` (workflow akan mengekstraknya sendiri).
3. Buat file `.github/workflows/build.yml` di repo (Add file > Create new file, ketik nama
   `.github/workflows/build.yml`, tempel isi file build.yml, Commit).
4. Isi 4 Secrets: Settings > Secrets and variables > Actions > New repository secret
   - KEYSTORE_BASE64   : isi file keystore (.jks) dalam base64 (Termux: base64 -w0 ryooxit.jks)
   - KEYSTORE_PASSWORD : password keystore
   - KEY_ALIAS         : alias key
   - KEY_PASSWORD      : password key
   Keystore harus yang hash-nya = EXPECTED_SHA256 di MainActivity.kt. Workflow akan menolak kalau beda.

## Rilis (contoh 1.0.3 lalu 1.0.4)
1. Releases > Create a new release > tag `v1.0.3` (format wajib v angka.angka.angka) > Publish release.
2. Tunggu tab Actions selesai (centang hijau). APK `RyooXIT-1.0.3.apk` otomatis menempel di release,
   dan `version.json` otomatis diperbarui di cabang utama.
3. Unduh APK dari release, pasang di HP (hanya sekali).
4. Untuk update berikutnya cukup buat release tag `v1.0.4` dst. Tidak perlu mengedit versi di kode:
   versionName diambil dari tag, versionCode = major*10000 + minor*100 + patch (1.0.4 -> 10004).

## Perilaku di aplikasi
- HP root: unduh, verifikasi, pasang diam-diam, app terbuka lagi sendiri.
- HP non-root: dialog "Update tersedia", unduh, ketuk Instal sekali.
- Matikan di Settings > Update otomatis, atau cek manual lewat tombol "Cek update" di App Info.

## Keamanan
- Jangan unggah keystore / keystore.properties ke repo.
- Update ditolak otomatis kalau hash APK, tanda tangan, nama paket, atau versionCode tidak cocok.

## File Manager

Project ini juga memiliki tab **APK**. Pengguna dapat memilih aplikasi container dan aplikasi terpasang, menyimpan pilihan, lalu membuka aplikasi dengan `PackageManager` + `Intent` native Android. Detail penggunaan dan batas integrasi container ada di `ADD-APK-NATIVE-GUIDE.md`.
