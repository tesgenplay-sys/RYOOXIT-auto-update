# Driver asset audit — 2026-11-12

The driver files under `app/src/main/assets/drivers/{RT,RTHook}` are binary-containing shell bundles, not plain shell scripts. They contain a shell preamble followed by a marker and an embedded ELF payload.

Observed in RT/5.15.sh:
- Requires UID 0.
- Writes marker strings to files under `/storage/emulated/0/Android/data/org.telegram.messenger/cache/`.
- Extracts the appended payload using `sed` into `/data/tmpf`.
- Runs `insmod` on that payload.
- Runs `dmesg -C` after successful insertion.

These are high-impact root/kernel operations. A filename such as `5.15.sh` or `6.12.23.sh` is not sufficient evidence of compatibility. No driver is marked verified by this audit. The app must not auto-load these assets until the ELF and kernel compatibility checks and unrelated side-effect review are complete.
