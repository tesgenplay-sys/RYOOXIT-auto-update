# RYOOXIT Sensitivity Engine — source integration 1.0.4

## What is included

- Floating RYOOXIT sensitivity panel with X and Y sliders.
- X/Y values are persisted in RYOOXIT preferences.
- ARM64 `libtouch_engine.so` copied from the Zayon ARM64 split supplied by the user.
- JNI declarations use the exported `com.zayon.optimize.touch.TouchBridge` symbol names.
- A root `app_process` runner loads the native library and calls `nativeRun(configPath)`.
- The engine config file is written to `/data/local/tmp/ryooxit_sensitivity.cfg`. The same file is rewritten in place when X/Y changes, because the native engine watches its config file for changes.
- A shutdown hook calls `nativeReleaseAll()` when the root runner exits.

## What was confirmed from the supplied Zayon files

- `TouchRunner.main(String[])` takes two arguments, loads `TouchBridge`, and invokes `nativeRun` with the second argument as the config path.
- `libtouch_engine.so` exports `nativeRun`, `nativeRetune`, `nativeAttach`, `nativeRelease`, and `nativeReleaseAll` for `com.zayon.optimize.touch.TouchBridge`.
- The native parser's first config record is six values: two floats followed by four integers (`%f %f %d %d %d %d`). The first two values are clamped by the native parser to 1.00–2.25.
- The native engine monitors the supplied config file and uses `/dev/input` and `/dev/uinput`. Therefore, the runner is launched as root.
- `libtouch_engine.so` has only Android system-library dependencies (`libm`, `libdl`, `libc`); `libzycore.so` is not needed for this native touch-engine entry point.

## Conservative configuration mapping

The initial config line is `X Y 1 0 1 0`. Only X and Y are changed by the sliders. The four integer fields are left at the values in the supplied baseline `zayon_touch.cfg` because their exact mapping to Zayon's `sensi_global`, `sensi_accel`, and `sensi_zone` preferences has not been proven. The panel therefore does not expose those controls yet.

## Device and permission requirements

- ARM64 Android device.
- Root access must be explicitly granted to RYOOXIT when the native engine is enabled.
- User must grant the Android “Display over other apps” permission for the floating panel.

## Validation status

Static checks were performed on the supplied APK/library symbols, the native config parser, manifest XML, and Java JNI declarations. This environment does not contain Android SDK/Gradle build tools or a connected Android device, so this source has **not** been compiled into an APK or runtime-tested. Treat this as an integration build candidate, not a verified release. Test first with a non-competitive touch test app and stop the engine immediately if touch input behaves unexpectedly.
