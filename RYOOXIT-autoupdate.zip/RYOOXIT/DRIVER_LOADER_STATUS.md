# RYOOXIT Driver Loader status

The Home screen now includes a kernel/device summary, root status, RT/RTHook candidate list, and an in-app terminal panel.

## Current execution policy

Driver execution is intentionally locked. The bundled `.sh` assets are not ordinary text-only shell scripts: they append an embedded ELF payload and call `insmod`. Inspection of RT/5.15.sh also found creation of marker files under the Telegram cache path and clearing the kernel log (`dmesg -C`) after a successful load. These actions are not justified by a filename match and must be reviewed before granting a root execution path.

The UI therefore lists filename candidates and records the audit reason in the terminal, but does not copy or execute a driver in `/data/local/tmp`. Kernel major/minor matching is only candidate discovery, not proof of ABI, vermagic, symbol CRC, or device compatibility.

## Next verification required

- Identify and document the origin and purpose of each embedded ELF payload.
- Verify ELF architecture and kernel module metadata (vermagic, dependencies, symbol versions/CRCs) against the target device kernel.
- Remove or justify unrelated marker-file creation and kernel-log clearing.
- Test only on a recoverable test device after a source-level review.
