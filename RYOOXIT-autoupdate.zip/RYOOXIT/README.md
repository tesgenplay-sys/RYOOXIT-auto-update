# RYOOXIT Android Project

Project Android native berbasis Kotlin + XML.

## Fitur Add APK Native

Tab **APK** memungkinkan pengguna memilih aplikasi container/host dan aplikasi Android yang terpasang melalui `PackageManager`, menyimpan pilihan, lalu membukanya dengan Android `Intent` melalui tombol **JALANKAN**. Fitur ini tidak bergantung pada command shell untuk membuka aplikasi.

Untuk detail penggunaan dan batas integrasi aplikasi container, baca [`ADD-APK-NATIVE-GUIDE.md`](ADD-APK-NATIVE-GUIDE.md).

## Build

Buka folder project ini di Android Studio, atau gunakan workflow GitHub Actions pada `.github/workflows/build.yml`. Build release tetap memerlukan keystore resmi yang cocok dengan hash `EXPECTED_SHA256` di `app/src/main/java/com/ryooxit/app/MainActivity.kt`.
