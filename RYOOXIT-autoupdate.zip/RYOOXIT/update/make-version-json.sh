#!/usr/bin/env bash
# Buat version.json dari APK release.
# Pemakaian: ./make-version-json.sh RyooXIT-1.0.4.apk 4 1.0.4 "Perbaikan bug" GITHUB_USER GITHUB_REPO [force]
set -euo pipefail
APK="${1:?file apk}"; CODE="${2:?versionCode}"; NAME="${3:?versionName}"
LOG="${4:-}"; USER_="${5:?github user}"; REPO="${6:?github repo}"; FORCE="${7:-false}"
SHA=$(sha256sum "$APK" | cut -d' ' -f1)
FILE=$(basename "$APK")
cat > version.json <<JSON
{
  "versionCode": $CODE,
  "versionName": "$NAME",
  "apkUrl": "https://github.com/$USER_/$REPO/releases/download/v$NAME/$FILE",
  "sha256": "$SHA",
  "changelog": "$LOG",
  "forceUpdate": $FORCE
}
JSON
echo "version.json dibuat. SHA-256: $SHA"
