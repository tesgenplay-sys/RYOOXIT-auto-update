# Add APK Native System

Fitur ini menambahkan tab **APK** di navigasi bawah RYOOXIT.

## Cara menggunakan

1. Instal aplikasi container/host yang ingin dipakai di Android.
2. Buka tab **APK** di RYOOXIT.
3. Tekan **PILIH** pada bagian **Aplikasi Container / Host** dan pilih aplikasi dari daftar aplikasi yang terpasang.
4. Jika ingin membuka aplikasi lain yang terpasang secara langsung (tanpa container), pilih pada bagian **Aplikasi Tujuan**. Saat container dipilih, container diprioritaskan; hapus pilihan container dari dialog jika ingin menjalankan target secara langsung.
5. Jika game hanya muncul di menu internal container, isi nama game pada kolom nama internal.
6. Isi **Deep link / Intent URI resmi** hanya jika pengembang container menyediakan rute integrasi tersebut.
7. Tekan **SIMPAN PILIHAN**, lalu **JALANKAN**.

## Perilaku yang tersedia

- Daftar aplikasi diambil dari Android `PackageManager` dengan launcher Activity, bukan dari command shell.
- Ikon, nama aplikasi, dan package ID ditampilkan.
- Pilihan container, target, nama game internal, dan deep link disimpan di SharedPreferences.
- Tombol **JALANKAN** membuka aplikasi container melalui launch Intent Android.
- Jika container tidak dipilih, aplikasi tujuan yang dipilih dapat dibuka langsung.
- Deep link/Intent URI, jika disediakan oleh container, diarahkan hanya ke package container yang dipilih.
- Daftar aplikasi menggunakan deklarasi `<queries>` untuk launcher apps; fitur ini tidak meminta `QUERY_ALL_PACKAGES`.

## Batasan integrasi container

`PackageManager` hanya dapat menemukan aplikasi Android yang terpasang. Game yang disimpan di daftar internal aplikasi container bukan paket Android terpisah, sehingga RYOOXIT tidak dapat membaca atau memilihnya hanya dengan API native umum.

Untuk membuka game internal secara otomatis, container harus menyediakan salah satu dari:

- deep link resmi;
- Activity/Service/Receiver yang diekspor dan memang ditujukan untuk integrasi;
- custom Intent action/extra yang didokumentasikan; atau
- API resmi lain dari pengembang container.

Tanpa mekanisme tersebut, tombol **JALANKAN** hanya membuka container. RYOOXIT tidak mencoba melewati login, key, atau autentikasi internal. Jika container meminta login, pengguna harus login manual; setelah kembali ke RYOOXIT, tombol **JALANKAN** dapat ditekan lagi. Android tetap dapat menghentikan proses background sehingga sesi tidak dijamin bertahan.

## Pemeriksaan APK contoh AincradClient 3.7

Manifest APK contoh menunjukkan:

- package ID: `com.microsoft.copilot`;
- Activity utama: `com.aincrad.application.MainActivity` dengan `exported=true`;
- Activity tersebut memiliki filter `MAIN` + `LAUNCHER`;
- service `com.aincrad.application.services.Floater` memiliki `exported=false`;
- tidak ditemukan deep link game khusus pada manifest.

Artinya RYOOXIT dapat membuka layar utama AincradClient jika APK itu sudah terpasang, tetapi manifest tersebut belum menunjukkan cara publik untuk memilih game internal secara otomatis. Selain itu, package ID contoh memakai nama `com.microsoft.copilot` walaupun kode Activity memakai namespace Aincrad; pastikan sumber APK tepercaya sebelum memasangnya, dan jangan berikan akses root jika belum diverifikasi.

## Build

Project tetap menggunakan Gradle Android/Kotlin yang sudah ada. Build release melalui workflow GitHub Actions yang disertakan tetap memerlukan keystore asli yang cocok dengan `EXPECTED_SHA256` di `MainActivity.kt`.
