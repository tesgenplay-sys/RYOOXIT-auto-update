# RYOOXIT Aincrad Accessibility - test notes

This source update adds an opt-in Android AccessibilityService for one narrow task: find the exact configured game label inside the selected container and click its clickable Accessibility node once.

## Safety boundaries

- No root is used by this feature.
- The user must manually enable the service in Android Accessibility Settings.
- When idle, the service filters events to RYOOXIT only.
- During a run, the service filters events to the selected container package only.
- It does not capture the screen, use OCR, dispatch coordinate gestures, read login fields, save UI text, or transmit UI content.
- It stops after one successful game-label click, a click failure, or a 60-second timeout.
- The next screen's launch button is deliberately left for manual confirmation until its exact UI has been inspected.

## Current limitation

Aincrad's game catalog appears to be rendered with Jetpack Compose and game entries may be loaded dynamically. The service can only click a label if Aincrad exposes the exact label as a visible, clickable Accessibility node. Test this on a disposable/virtual environment first.

## Build and test signing

The source archive does not contain a signing keystore.

- **Build test APK from GitHub Actions:** open `Actions` → `Build RyooXIT` → `Run workflow`, enter a version such as `1.0.5`, then download the `RyooXIT-1.0.5-test-debug` artifact. This debug build does not require release keystore secrets.
- **Build debug in Android Studio:** select the `debug` variant and build the APK. The release-certificate guard is bypassed only when `BuildConfig.DEBUG` is true.
- **Build release:** the guard remains enabled and requires the project's original release certificate matching `EXPECTED_SHA256` in `MainActivity.kt`. The release workflow still requires the official keystore secrets.

Do not distribute a debug APK as a public release. The debug bypass does not change the Accessibility permission requirement or make the service run automatically; the user must enable it manually in Android Settings.
