# Build Fix – BuildConfig

GitHub Actions sebelumnya gagal pada `MainActivity.kt` dengan pesan `Unresolved reference: BuildConfig`.

Penyebab: Android Gradle Plugin 8.x tidak selalu menghasilkan kelas `BuildConfig` secara default.

Perbaikan: `app/build.gradle.kts` sekarang mengaktifkan `buildFeatures { buildConfig = true }`.
Dengan demikian `BuildConfig.DEBUG` tersedia saat kompilasi. Pemeriksaan tanda tangan tetap dilewati
hanya untuk APK debug; build release tetap memeriksa sertifikat yang sudah ditentukan oleh
`EXPECTED_SHA256` dan harus memakai keystore release asli melalui GitHub Secrets.

Catatan: perubahan ini memperbaiki error kompilasi yang terlihat pada log, tetapi build akhir tetap
harus diverifikasi melalui GitHub Actions pada repository pengguna.
