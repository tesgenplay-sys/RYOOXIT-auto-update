# RYOOXIT V2.3 preset integration

- The RYOOXIT V2.3 script and key file are bundled in `app/src/main/assets/ryooxit_v23/`.
- The command picker now has one built-in preset named `RYOOXIT V2.3`.
- Selecting the preset fills the command field.
- The preset currently uses a harmless informational `echo` command; the bundled overlay script is not extracted or executed by the Run button.
- User-created commands remain available through the Add Command feature.
