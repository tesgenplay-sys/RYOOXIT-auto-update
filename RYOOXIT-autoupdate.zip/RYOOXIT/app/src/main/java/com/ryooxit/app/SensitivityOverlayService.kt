package com.ryooxit.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.pm.ServiceInfo
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import kotlin.math.abs

/** Floating sensitivity panel backed by the ARM64 native input engine. */
class SensitivityOverlayService : Service() {
    companion object {
        const val ACTION_SHOW = "com.ryooxit.app.action.SENSITIVITY_SHOW"
        const val ACTION_HIDE = "com.ryooxit.app.action.SENSITIVITY_HIDE"
        private const val CHANNEL_ID = "ryooxit_sensitivity_engine"
        private const val NOTIFICATION_ID = 7418
        private const val PREFS = "ryooxit_sensitivity_engine"
        private const val CONFIG = "/data/local/tmp/ryooxit_sensitivity.cfg"
        private const val PID_FILE = "/data/local/tmp/ryooxit_sensitivity.pid"
        private const val LOG_FILE = "/data/local/tmp/ryooxit_sensitivity.log"
        private const val X_MIN = 1.00f
        private const val X_MAX = 2.25f
    }

    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val mainHandler = Handler(Looper.getMainLooper())
    private lateinit var windowManager: WindowManager
    private var overlay: View? = null
    private var x = 1.40f
    private var y = 1.40f
    private var engineEnabled = false
    private var statusView: TextView? = null
    private var dragX = 0
    private var dragY = 0
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var pendingConfigUpdate: Runnable? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        x = prefs.getFloat("sensi_x", 1.40f).coerceIn(X_MIN, X_MAX)
        y = prefs.getFloat("sensi_y", 1.40f).coerceIn(X_MIN, X_MAX)
        engineEnabled = prefs.getBoolean("enabled", false)
        createNotificationChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_HIDE) {
            stopSelf()
        } else if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) {
            showBubble()
        } else {
            Toast.makeText(this, "Izinkan RYOOXIT tampil di atas aplikasi lain terlebih dahulu.", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopNativeEngine()
        removeOverlay()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "RYOOXIT Sensitivity Engine", NotificationManager.IMPORTANCE_LOW)
            channel.description = "Menjaga panel sensitivitas dan mesin input tetap aktif."
            channel.setShowBadge(false)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    @Suppress("DEPRECATION")
    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("RYOOXIT Sensitivity Engine")
            .setContentText("Panel sensitivitas aktif")
            .setContentIntent(pending).setOngoing(true).build()
    }

    private fun showBubble() {
        removeOverlay()
        val bubble = TextView(this).apply {
            text = "X/Y"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(27, 105, 205))
                setStroke(dp(2), Color.rgb(125, 190, 255))
            }
            elevation = dp(8).toFloat()
            contentDescription = "Buka panel sensitivitas RYOOXIT"
        }
        val params = WindowManager.LayoutParams(
            dp(58), dp(58), windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("overlay_x", dp(18)).coerceAtLeast(0)
            y = prefs.getInt("overlay_y", dp(220)).coerceAtLeast(0)
        }
        bubble.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragX = params.x; dragY = params.y
                    downX = event.rawX; downY = event.rawY; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                    if (abs(dx) + abs(dy) > dp(5)) moved = true
                    params.x = (dragX + dx).coerceAtLeast(0); params.y = (dragY + dy).coerceAtLeast(0)
                    try { windowManager.updateViewLayout(bubble, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("overlay_x", params.x).putInt("overlay_y", params.y).apply()
                    if (!moved) showPanel()
                    true
                }
                else -> true
            }
        }
        overlay = bubble
        try { windowManager.addView(bubble, params) } catch (e: Exception) {
            overlay = null
            Toast.makeText(this, "Panel mengambang gagal: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun showPanel() {
        removeOverlay()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(Color.rgb(17, 27, 45)); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.rgb(65, 135, 220))
            }
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply {
            text = "RYOOXIT SENSITIVITY"
            textSize = 15f; setTextColor(Color.WHITE); setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val collapse = TextView(this).apply {
            text = "—"; textSize = 23f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            setOnClickListener { showBubble() }
        }
        header.addView(title, LinearLayout.LayoutParams(0, dp(38), 1f))
        header.addView(collapse, LinearLayout.LayoutParams(dp(38), dp(38)))
        panel.addView(header)

        statusView = TextView(this).apply {
            text = if (engineEnabled) "Memeriksa mesin root…" else "MESIN NONAKTIF"
            textSize = 10f; setTextColor(Color.rgb(255, 205, 115)); setPadding(0, dp(3), 0, dp(10))
        }
        panel.addView(statusView)

        lateinit var toggle: Switch
        toggle = Switch(this).apply {
            text = "Aktifkan mesin sensitivitas"
            textSize = 14f; setTextColor(Color.WHITE); isChecked = engineEnabled
            setOnCheckedChangeListener { _, checked ->
                engineEnabled = checked
                prefs.edit().putBoolean("enabled", checked).apply()
                setControlsEnabled(panel, checked)
                statusView?.text = if (checked) "Menjalankan mesin native…" else "Menghentikan mesin…"
                Thread {
                    val result = if (checked) startNativeEngine() else stopNativeEngine()
                    mainHandler.post {
                        statusView?.text = result.second
                        if (!result.first) {
                            engineEnabled = false
                            prefs.edit().putBoolean("enabled", false).apply()
                            toggle.isChecked = false
                            setControlsEnabled(panel, false)
                        }
                    }
                }.start()
            }
        }
        panel.addView(toggle)

        addSensitivitySlider(panel, "Sensitivitas X", "sensi_x", x) { value ->
            x = value; prefs.edit().putFloat("sensi_x", value).apply(); updateNativeConfigIfRunning()
        }
        addSensitivitySlider(panel, "Sensitivitas Y", "sensi_y", y) { value ->
            y = value; prefs.edit().putFloat("sensi_y", value).apply(); updateNativeConfigIfRunning()
        }
        val range = TextView(this).apply {
            text = "Rentang mesin native: 1,00 – 2,25"
            textSize = 10f; setTextColor(Color.LTGRAY); setPadding(0, dp(4), 0, dp(8))
        }
        panel.addView(range)
        val info = TextView(this).apply {
            text = "X/Y dikirim ke file konfigurasi yang dipantau mesin native. Mesin membutuhkan root dan perangkat ARM64."
            textSize = 10f; setTextColor(Color.rgb(185, 198, 216))
        }
        panel.addView(info)
        val close = TextView(this).apply {
            text = "TUTUP PANEL"; gravity = Gravity.CENTER; textSize = 12f
            setTextColor(Color.WHITE); setPadding(0, dp(12), 0, dp(2))
            setOnClickListener { showBubble() }
        }
        panel.addView(close)

        val params = WindowManager.LayoutParams(
            dp(310), WindowManager.LayoutParams.WRAP_CONTENT, windowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs.getInt("overlay_x", dp(18)).coerceAtLeast(0)
            y = prefs.getInt("overlay_y", dp(180)).coerceAtLeast(0)
        }
        title.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { dragX = params.x; dragY = params.y; downX = event.rawX; downY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (dragX + (event.rawX - downX).toInt()).coerceAtLeast(0)
                    params.y = (dragY + (event.rawY - downY).toInt()).coerceAtLeast(0)
                    try { windowManager.updateViewLayout(panel, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    prefs.edit().putInt("overlay_x", params.x).putInt("overlay_y", params.y).apply(); true
                }
                else -> true
            }
        }
        overlay = panel
        try { windowManager.addView(panel, params) } catch (e: Exception) {
            overlay = null; Toast.makeText(this, "Panel gagal ditampilkan: ${e.message}", Toast.LENGTH_LONG).show(); stopSelf()
        }
        setControlsEnabled(panel, engineEnabled)
        if (engineEnabled) Thread {
            val alive = isEngineAlive()
            mainHandler.post { statusView?.text = if (alive) "MESIN NATIVE AKTIF" else "Mesin tidak berjalan; matikan lalu aktifkan kembali" }
        }.start()
    }

    private fun addSensitivitySlider(parent: LinearLayout, label: String, key: String, initial: Float, onChanged: (Float) -> Unit) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = TextView(this).apply { text = label; textSize = 13f; setTextColor(Color.WHITE) }
        val value = TextView(this).apply {
            text = String.format(Locale.US, "%.2f", initial); textSize = 13f
            setTextColor(Color.rgb(120, 190, 255)); gravity = Gravity.END
        }
        row.addView(name, LinearLayout.LayoutParams(0, dp(28), 1f))
        row.addView(value, LinearLayout.LayoutParams(dp(52), dp(28)))
        parent.addView(row)
        val seek = SeekBar(this).apply {
            max = 125
            progress = ((initial.coerceIn(X_MIN, X_MAX) - X_MIN) * 100f).toInt().coerceIn(0, 125)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val v = X_MIN + progress / 100f
                    value.text = String.format(Locale.US, "%.2f", v)
                    if (fromUser) onChanged(v)
                }
                override fun onStartTrackingTouch(bar: SeekBar?) {}
                override fun onStopTrackingTouch(bar: SeekBar?) {}
            })
        }
        parent.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36)))
    }

    private fun setControlsEnabled(root: View, enabled: Boolean) {
        if (root is SeekBar) root.isEnabled = enabled
        if (root is android.view.ViewGroup) for (i in 0 until root.childCount) setControlsEnabled(root.getChildAt(i), enabled)
    }

    private fun configLine(): String = String.format(Locale.US, "%.2f %.2f 1 0 1 0", x.coerceIn(X_MIN, X_MAX), y.coerceIn(X_MIN, X_MAX))

    private fun startNativeEngine(): Pair<Boolean, String> {
        if (Build.SUPPORTED_ABIS.none { it == "arm64-v8a" }) return false to "Mesin ini hanya tersedia untuk ARM64."
        val lib = File(applicationInfo.nativeLibraryDir, "libtouch_engine.so")
        if (!lib.isFile) return false to "libtouch_engine.so tidak ditemukan di APK."
        val apk = applicationInfo.sourceDir
        val script = """
            mkdir -p /data/local/tmp || exit 10
            printf '%s\n' '${configLine()}' > '$CONFIG' || exit 11
            chmod 600 '$CONFIG'
            if [ -f '$PID_FILE' ] && kill -0 \$(cat '$PID_FILE') 2>/dev/null; then echo ALREADY_RUNNING; exit 0; fi
            ( CLASSPATH='$apk' /system/bin/app_process /system/bin com.ryooxit.app.TouchEngineRunner '${lib.absolutePath}' '$CONFIG' >> '$LOG_FILE' 2>&1 < /dev/null & echo \$! > '$PID_FILE' )
            sleep 1
            if [ -f '$PID_FILE' ] && kill -0 \$(cat '$PID_FILE') 2>/dev/null; then echo ENGINE_STARTED; else echo ENGINE_FAILED; cat '$LOG_FILE' 2>/dev/null; exit 12; fi
        """.trimIndent()
        val result = rootCommand(script)
        val ok = result.first == 0 && (result.second.contains("ENGINE_STARTED") || result.second.contains("ALREADY_RUNNING"))
        return if (ok) true to "MESIN NATIVE AKTIF • ROOT" else false to "Gagal menjalankan mesin: ${result.second.take(180)}"
    }

    private fun updateNativeConfigIfRunning() {
        if (!engineEnabled) return
        pendingConfigUpdate?.let { mainHandler.removeCallbacks(it) }
        val line = configLine()
        val update = Runnable {
            Thread {
                val result = rootCommand("if [ -f '$PID_FILE' ] && kill -0 \$(cat '$PID_FILE') 2>/dev/null; then printf '%s\\n' '$line' > '$CONFIG'; echo UPDATED; else echo NOT_RUNNING; exit 2; fi")
                mainHandler.post {
                    statusView?.text = if (result.first == 0 && result.second.contains("UPDATED")) "MESIN AKTIF • X/Y DIPERBARUI" else "Nilai tersimpan; mesin perlu dijalankan ulang"
                }
            }.start()
        }
        pendingConfigUpdate = update
        mainHandler.postDelayed(update, 180)
    }

    private fun stopNativeEngine(): Pair<Boolean, String> {
        val result = rootCommand("if [ -f '$PID_FILE' ]; then P=\$(cat '$PID_FILE'); kill -TERM \$P 2>/dev/null; sleep 2; if kill -0 \$P 2>/dev/null; then kill -TERM \$P 2>/dev/null; fi; rm -f '$PID_FILE'; fi; echo ENGINE_STOPPED")
        return if (result.first == 0) true to "MESIN NONAKTIF" else false to "Gagal menghentikan mesin: ${result.second.take(140)}"
    }

    private fun isEngineAlive(): Boolean {
        val result = rootCommand("[ -f '$PID_FILE' ] && kill -0 \$(cat '$PID_FILE') 2>/dev/null && echo ALIVE")
        return result.first == 0 && result.second.contains("ALIVE")
    }

    private fun rootCommand(command: String): Pair<Int, String> = try {
        val process = ProcessBuilder("su", "-c", command).redirectErrorStream(true).start()
        val output = process.inputStream.bufferedReader().use { it.readText() }
        process.waitFor() to output.trim()
    } catch (e: Exception) { -1 to (e.message ?: e.javaClass.simpleName) }

    private fun removeOverlay() {
        overlay?.let { try { windowManager.removeView(it) } catch (_: Exception) { } }
        overlay = null; statusView = null
    }

    private fun windowType(): Int {
        return if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
