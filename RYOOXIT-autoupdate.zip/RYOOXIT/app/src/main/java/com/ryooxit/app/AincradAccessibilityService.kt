package com.ryooxit.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Local, user-enabled helper for Aincrad only.
 * It looks for one exact game label, taps its clickable parent once, then stops.
 * It does not capture screenshots, collect credentials, or send UI data anywhere.
 */
class AincradAccessibilityService : AccessibilityService() {

    private val prefs by lazy { getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastScanAt = 0L

    private val timeoutRunnable = Runnable {
        if (prefs.getBoolean(PREF_ACTIVE, false)) {
            finishAutomation(
                "Tidak menemukan label game dalam 60 detik. Pastikan daftar game Aincrad terbuka dan nama game tampil sebagai teks yang dapat diakses."
            )
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        applyPackageFilter()
        if (prefs.getBoolean(PREF_ACTIVE, false)) {
            mainHandler.removeCallbacks(timeoutRunnable)
            mainHandler.postDelayed(timeoutRunnable, TIMEOUT_MS)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !prefs.getBoolean(PREF_ACTIVE, false)) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val host = prefs.getString(PREF_HOST, "").orEmpty()
        if (host.isBlank() || event.packageName?.toString() != host) return

        val now = System.currentTimeMillis()
        if (now - lastScanAt < SCAN_INTERVAL_MS) return
        lastScanAt = now

        val gameLabel = prefs.getString(PREF_GAME, "").orEmpty().normalizeLabel()
        if (gameLabel.isBlank()) {
            finishAutomation("Nama game belum diisi. Buka RYOOXIT dan isi nama game yang tepat.")
            return
        }

        val root = rootInActiveWindow ?: return
        val match = findExactVisibleLabel(root, gameLabel) ?: return
        val clickable = findClickableAncestor(match)
        if (clickable == null) {
            finishAutomation("Nama game ditemukan, tetapi elemen tersebut tidak menyediakan tombol klik Accessibility. Tidak ada sentuhan paksa yang dilakukan.")
            return
        }

        if (clickable.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            finishAutomation(
                "Game '$gameLabel' berhasil dipilih. Pemantauan RYOOXIT dihentikan. Periksa layar Aincrad lalu tekan tombol MULAI/PLAY secara manual."
            )
        } else {
            finishAutomation("Game '$gameLabel' ditemukan, tetapi Aincrad menolak aksi klik Accessibility.")
        }
    }

    override fun onInterrupt() {
        // No continuous work is performed outside an explicitly started run.
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(timeoutRunnable)
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun findExactVisibleLabel(root: AccessibilityNodeInfo, expected: String): AccessibilityNodeInfo? {
        val pending = ArrayList<AccessibilityNodeInfo>()
        pending.add(root)
        var visited = 0
        while (pending.isNotEmpty() && visited < MAX_NODES) {
            val node = pending.removeAt(pending.lastIndex)
            visited++
            if (node.isVisibleToUser && !node.isEditable && !node.isPassword && (
                    node.text?.toString().normalizeLabel() == expected ||
                    node.contentDescription?.toString().normalizeLabel() == expected
                )) return node

            for (index in 0 until node.childCount) {
                val child = node.getChild(index)
                if (child != null) pending.add(child)
            }
        }
        return null
    }

    private fun findClickableAncestor(start: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var node: AccessibilityNodeInfo? = start
        repeat(MAX_CLICK_ANCESTORS) {
            if (node == null) return null
            if (node!!.isVisibleToUser && node!!.isClickable) return node
            node = node!!.parent
        }
        return null
    }

    private fun finishAutomation(message: String) {
        mainHandler.removeCallbacks(timeoutRunnable)
        prefs.edit()
            .putBoolean(PREF_ACTIVE, false)
            .putString(PREF_STATUS, message)
            .apply()
        applyPackageFilter()
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun applyPackageFilter() {
        val host = if (prefs.getBoolean(PREF_ACTIVE, false)) {
            prefs.getString(PREF_HOST, "").orEmpty().takeIf { it.isNotBlank() }
        } else null
        val info = serviceInfo ?: return
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
        info.notificationTimeout = 150L
        // While idle, receive only RYOOXIT events. During a run, receive only Aincrad events.
        info.packageNames = arrayOf(host ?: packageName)
        setServiceInfo(info)
    }

    private fun String?.normalizeLabel(): String =
        this.orEmpty().trim().replace(Regex("\\s+"), " ").lowercase()

    companion object {
        private const val PREFS_NAME = "ryooxit"
        const val PREF_ACTIVE = "aincrad_access_active"
        const val PREF_HOST = "aincrad_access_host"
        const val PREF_GAME = "aincrad_access_game"
        const val PREF_STATUS = "aincrad_access_status"
        private const val TIMEOUT_MS = 60_000L
        private const val SCAN_INTERVAL_MS = 300L
        private const val MAX_NODES = 500
        private const val MAX_CLICK_ANCESTORS = 7

        @Volatile private var instance: AincradAccessibilityService? = null

        /** Returns false until Android has connected the user-enabled service. */
        fun begin(context: Context, hostPackage: String, gameLabel: String): Boolean {
            val service = instance ?: return false
            if (hostPackage.isBlank() || gameLabel.isBlank()) return false
            service.mainHandler.removeCallbacks(service.timeoutRunnable)
            service.lastScanAt = 0L
            service.prefs.edit()
                .putString(PREF_HOST, hostPackage)
                .putString(PREF_GAME, gameLabel.trim())
                .putString(PREF_STATUS, "Menunggu label '${gameLabel.trim()}' di Aincrad...")
                .putBoolean(PREF_ACTIVE, true)
                .apply()
            service.applyPackageFilter()
            service.mainHandler.postDelayed(service.timeoutRunnable, TIMEOUT_MS)
            return true
        }

        fun cancel(context: Context, message: String) {
            val service = instance
            if (service != null) {
                service.finishAutomation(message)
            } else {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                    .putBoolean(PREF_ACTIVE, false)
                    .putString(PREF_STATUS, message)
                    .apply()
            }
        }
    }
}
