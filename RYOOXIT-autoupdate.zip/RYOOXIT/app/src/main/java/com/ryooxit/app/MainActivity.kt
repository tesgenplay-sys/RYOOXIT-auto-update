package com.ryooxit.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("ryooxit", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val updater by lazy { Updater(this) }

    private lateinit var cmdBox: EditText
    private lateinit var keyBox: EditText
    private lateinit var pageHome: View
    private lateinit var pageProfile: View

    private var page = PAGE_HOME
    private var rootFound = false
    private var rootChecked = false
    private var tick = 0
    private var pinging = false

    // ===== Siklus hidup =====
    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Tema (Biru / Ungu) dipilih dari pengaturan; bawaan Biru
        setTheme(if (isPurple()) R.style.Theme_Ryooxit_Purple else R.style.Theme_Ryooxit)
        super.onCreate(savedInstanceState)

        if (!isSignatureValid()) {
            // APK sudah diubah / ditandatangani ulang oleh orang lain: hentikan app.
            AlertDialog.Builder(this)
                .setTitle(R.string.verify_fail_title)
                .setMessage(R.string.verify_fail_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.close) { _, _ -> finishAffinity(); exitProcess(0) }
                .show()
            return
        }

        setContentView(R.layout.activity_main)
        page = savedInstanceState?.getInt("page", PAGE_HOME) ?: PAGE_HOME

        // Kedua tema gelap: ikon status bar & navigation bar berwarna terang
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        pageHome = findViewById(R.id.pageHome)
        pageProfile = findViewById(R.id.pageProfile)
        loadBackground()

        cmdBox = findViewById(R.id.cmdBox)
        keyBox = findViewById(R.id.keyBox)
        val btnRun = findViewById<Button>(R.id.btnRun)
        cmdBox.setText(prefs.getString("cmd", DEFAULT_CMD))
        updateLastRun()
        keyBox.setText(prefs.getString("key", ""))

        setupSplash(savedInstanceState == null)
        // Update otomatis: cek sekali tiap app dibuka (bukan saat activity dibuat ulang karena ganti tema/bahasa)
        if (savedInstanceState == null && prefs.getBoolean("autoUpdate", true)) {
            window.decorView.postDelayed({ if (!isFinishing) updater.check(false) }, 2500)
        }
        setupAnimations(btnRun)
        checkRoot()
        fillStaticInfo()

        // Navigasi bawah
        findViewById<View>(R.id.navHome).setOnClickListener { showPage(PAGE_HOME, true) }
        findViewById<View>(R.id.navProfile).setOnClickListener { showPage(PAGE_PROFILE, true) }
        showPage(page)
        playThemeSwitchAnim()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (page == PAGE_PROFILE) showPage(PAGE_HOME, true)
                else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnInfo).setOnClickListener { showInfo() }
        findViewById<View>(R.id.btnProfileTop).setOnClickListener { showPage(PAGE_PROFILE, true) }
        findViewById<View>(R.id.btnCmdGo).setOnClickListener {
            cmdBox.requestFocus(); cmdBox.setSelection(cmdBox.text.length)
            (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .showSoftInput(cmdBox, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
        }
        findViewById<LinearLayout>(R.id.btnChannel).setOnClickListener {
            openLink(WA_CHANNEL_URL, R.string.link_fail)
        }
        findViewById<LinearLayout>(R.id.btnAdmin).setOnClickListener {
            openLink(WA_ADMIN_URL, R.string.wa_fail)
        }

        findViewById<LinearLayout>(R.id.btnTiktok).setOnClickListener {
            openLink(TIKTOK_URL, R.string.link_fail)
        }

        btnRun.setOnClickListener {
            val cmd = cmdBox.text.toString().trim()
            if (cmd.isEmpty()) return@setOnClickListener
            val root = prefs.getBoolean("root", true)
            val key = keyBox.text.toString().trim()
            prefs.edit().putString("key", key).putString("cmd", cmd).apply()
            btnRun.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            btnRun.isEnabled = false
            btnRun.setText(R.string.running)
            val writeKeyFile = prefs.getBoolean("keyToFile", false)
            thread {
                val out = try {
                    // Opsional: tulis key ke /data/local/tmp/key.txt dulu, sebelum script dijalankan.
                    // Script bisa membacanya sendiri, misalnya: KEY=$(cat /data/local/tmp/key.txt)
                    if (writeKeyFile && key.isNotEmpty() && root) {
                        val wp = ProcessBuilder("su", "-c", "cat > /data/local/tmp/key.txt")
                            .redirectErrorStream(true).start()
                        wp.outputStream.bufferedWriter().use { w -> w.write(key) }
                        wp.waitFor()
                    }
                    // mode root: jalankan lewat su; mode biasa: sh biasa
                    val args = if (root) arrayOf("su", "-c", cmd.removePrefix("su -c ").trim('"'))
                               else arrayOf("sh", "-c", cmd)
                    val p = ProcessBuilder(*args).redirectErrorStream(true).start()
                    // kirim key ke stdin script juga (untuk `read`), lalu tutup stdin
                    p.outputStream.bufferedWriter().use { w -> if (key.isNotEmpty()) w.write(key + "\n") }
                    val o = p.inputStream.bufferedReader().readText()
                    p.waitFor()
                    o.ifBlank { getString(R.string.done_no_output) }
                } catch (ex: Exception) { "Error: ${ex.message}" }
                prefs.edit().putLong("lastRun", System.currentTimeMillis()).apply()
                runOnUiThread {
                    updateLastRun()
                    btnRun.isEnabled = true
                    btnRun.setText(R.string.run)
                    AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.output_title).setMessage(out)
                        .setPositiveButton(R.string.ok, null).showGlass()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
    }

    override fun onResume() {
        super.onResume()
        if (::pageProfile.isInitialized && page == PAGE_PROFILE) startTicker()
    }

    override fun onPause() {
        super.onPause()
        stopTicker()
    }

    // ===== Navigasi Home / Profile (dengan animasi geser + pudar) =====
    private fun showPage(p: Int, animate: Boolean = false) {
        val prev = page
        page = p
        val inV = if (p == PAGE_HOME) pageHome else pageProfile
        val outV = if (p == PAGE_HOME) pageProfile else pageHome
        inV.animate().cancel(); outV.animate().cancel()

        if (animate && prev != p) {
            // Bar bawah: label membuka/menutup dengan mulus
            val nav = findViewById<View>(R.id.navHome).parent as ViewGroup
            android.transition.TransitionManager.beginDelayedTransition(
                nav, android.transition.AutoTransition().setDuration(260))
        }
        setNavItem(R.id.navHome, R.id.navHomeLabel, p == PAGE_HOME)
        setNavItem(R.id.navProfile, R.id.navProfileLabel, p == PAGE_PROFILE)
        if (p == PAGE_PROFILE) startTicker() else stopTicker()

        if (!animate || prev == p) {
            inV.visibility = View.VISIBLE; inV.alpha = 1f; inV.translationX = 0f
            outV.visibility = View.GONE; outV.alpha = 1f; outV.translationX = 0f
            return
        }
        val dx = resources.displayMetrics.widthPixels * 0.14f
        val dir = if (p == PAGE_PROFILE) 1f else -1f   // ke Profile: masuk dari kanan; kembali: dari kiri
        outV.animate().alpha(0f).translationX(-dir * dx * 0.6f).setDuration(200)
            .withEndAction {
                if (page == p) { outV.visibility = View.GONE }
                outV.alpha = 1f; outV.translationX = 0f
            }.start()
        inV.alpha = 0f; inV.translationX = dir * dx; inV.visibility = View.VISIBLE
        inV.animate().alpha(1f).translationX(0f).setStartDelay(70).setDuration(340)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        staggerIn(if (p == PAGE_PROFILE) (pageProfile as ViewGroup).getChildAt(0) as ViewGroup
                  else ((pageHome as ViewGroup).getChildAt(0) as ViewGroup).getChildAt(0) as ViewGroup)
    }

    // Kartu-kartu muncul berurutan dari bawah
    private fun staggerIn(col: ViewGroup) {
        val rise = resources.displayMetrics.density * 26f
        for (i in 0 until col.childCount) {
            val ch = col.getChildAt(i)
            ch.animate().cancel()
            ch.alpha = 0f; ch.translationY = rise
            ch.animate().alpha(1f).translationY(0f)
                .setStartDelay(110L + i * 55L).setDuration(360)
                .setInterpolator(DecelerateInterpolator(1.5f)).start()
        }
    }

    private fun setNavItem(itemId: Int, labelId: Int, selected: Boolean) {
        findViewById<View>(labelId).visibility = if (selected) View.VISIBLE else View.GONE
        findViewById<View>(itemId).setBackgroundResource(if (selected) R.drawable.bg_nav_sel else 0)
    }

    // ===== Tema: Biru (bawaan) / Ungu =====
    private fun isPurple(): Boolean = prefs.getString("theme", "blue") == "purple"

    // Ganti tema: ambil "foto" tampilan lama, buat ulang activity dengan tema baru,
    // lalu foto lama memudar sehingga terasa seperti transisi halus.
    private fun switchTheme(key: String) {
        val content = findViewById<View>(android.R.id.content)
        pendingSnapshot = try {
            Bitmap.createBitmap(content.width, content.height, Bitmap.Config.ARGB_8888)
                .also { content.draw(Canvas(it)) }
        } catch (e: Exception) { null }
        prefs.edit().putString("theme", key).apply()
        recreate()
    }

    private fun playThemeSwitchAnim() {
        val snap = pendingSnapshot ?: return
        pendingSnapshot = null
        val host = findViewById<ViewGroup>(android.R.id.content)
        val root = host.getChildAt(0)
        val overlay = ImageView(this).apply { setImageBitmap(snap); isClickable = true }
        host.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.alpha = 0.55f; root.scaleX = 0.97f; root.scaleY = 0.97f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f)).start()
        overlay.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .withEndAction { host.removeView(overlay) }.start()
    }

    private fun openLink(url: String, errRes: Int) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: Exception) { Toast.makeText(this, errRes, Toast.LENGTH_SHORT).show() }
    }

    // ===== Data perangkat (dibaca langsung dari sistem HP) =====
    private val ticker = object : Runnable {
        override fun run() {
            updateSession()
            if (tick % 2 == 0) updateStats()
            if (tick % 4 == 0) updateNet()
            tick++
            handler.postDelayed(this, 1000)
        }
    }

    private fun startTicker() {
        handler.removeCallbacks(ticker)
        tick = 0
        handler.post(ticker)
    }

    private fun stopTicker() { handler.removeCallbacks(ticker) }

    private fun fillStaticInfo() {
        findViewById<TextView>(R.id.txtDeviceId).text = deviceId()
        findViewById<TextView>(R.id.txtDeviceIdHome).text = deviceId()
        val man = Build.MANUFACTURER.orEmpty()
        val model = Build.MODEL.orEmpty()
        val name = if (model.startsWith(man, ignoreCase = true)) model
                   else man.replaceFirstChar { it.uppercase() } + " " + model
        findViewById<TextView>(R.id.txtModel).text = name.trim()
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "-"
        findViewById<TextView>(R.id.txtOs).text = "Android ${Build.VERSION.RELEASE}  •  $abi"
        val ver = appVersion()
        findViewById<TextView>(R.id.txtVersion).text = "V$ver"
        findViewById<TextView>(R.id.txtVersionHome).text = "v$ver"
        findViewById<TextView>(R.id.txtInfoSub).text = "RyooXIT v$ver"
        applyRootUi()
    }

    private fun appVersion(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.3" } catch (e: Exception) { "1.0.3" }

    private fun updateLastRun() {
        val t = prefs.getLong("lastRun", 0L)
        findViewById<TextView>(R.id.txtLastRun).text =
            if (t == 0L) getString(R.string.last_run_never)
            else getString(R.string.last_run,
                java.text.SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(java.util.Date(t)))
    }

    // ID unik perangkat (8 digit) diturunkan dari ANDROID_ID
    private fun deviceId(): String {
        val raw = try { Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) }
                  catch (e: Exception) { null } ?: Build.FINGERPRINT
        val d = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        var n = 0L
        for (i in 0 until 4) n = (n shl 8) or (d[i].toLong() and 0xFF)
        return "%08d".format(n % 100_000_000L)
    }

    private fun updateSession() {
        val s = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        findViewById<TextView>(R.id.txtSession).text =
            "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }

    private fun updateStats() {
        // RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramPct = if (mi.totalMem > 0) (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt() else 0
        findViewById<TextView>(R.id.txtRam).text = ramPct.toString()
        setVerticalBar(ramPct)

        // Storage (partisi data)
        val st = try { StatFs(Environment.getDataDirectory().path) } catch (e: Exception) { null }
        val stPct = if (st != null && st.totalBytes > 0)
            (((st.totalBytes - st.availableBytes) * 100) / st.totalBytes).toInt() else 0
        findViewById<TextView>(R.id.txtStorage).text = stPct.toString()
        findViewById<ProgressBar>(R.id.progStorage).progress = stPct

        // CPU: frekuensi saat ini (kHz) dari sysfs. Kalau diblokir sistem, tampilkan jumlah core.
        val cores = Runtime.getRuntime().availableProcessors()
        var cur = 0L; var max = 0L
        for (i in 0 until cores) {
            cur = maxOf(cur, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq"))
            max = maxOf(max, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq"))
        }
        val tvCpu = findViewById<TextView>(R.id.txtCpu)
        val tvUnit = findViewById<TextView>(R.id.txtCpuUnit)
        val pbCpu = findViewById<ProgressBar>(R.id.progCpu)
        if (cur > 0) {
            tvCpu.text = String.format(Locale.US, "%.2f", cur / 1_000_000.0)
            tvUnit.text = "GHz"
            pbCpu.progress = if (max > 0) ((cur * 100) / max).toInt().coerceIn(0, 100) else 0
        } else {
            tvCpu.text = cores.toString()
            tvUnit.setText(R.string.cpu_core_unit)
            pbCpu.progress = 0
        }

        // Skor performa: berdasarkan RAM & storage yang masih lega
        val score = (0.6 * (100 - ramPct) + 0.4 * (100 - stPct)).roundToInt().coerceIn(0, 100)
        findViewById<TextView>(R.id.txtScore).text = "$score / 100"
        findViewById<ProgressBar>(R.id.progScore).progress = score
    }

    private fun readLong(path: String): Long =
        try { File(path).readText().trim().toLong() } catch (e: Exception) { 0L }

    private fun setVerticalBar(pct: Int) {
        val p = pct.coerceIn(0, 100)
        val empty = findViewById<View>(R.id.barEmpty)
        val fill = findViewById<View>(R.id.barFill)
        (empty.layoutParams as LinearLayout.LayoutParams).weight = (100 - p).toFloat()
        (fill.layoutParams as LinearLayout.LayoutParams).weight = p.toFloat()
        findViewById<View>(R.id.barTrack).requestLayout()
    }

    private fun updateNet() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        val type = when {
            caps == null -> getString(R.string.net_none)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getString(R.string.net_mobile)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> getString(R.string.net_other)
        }
        findViewById<TextView>(R.id.txtNetInfo).text = if (caps == null) type else "$type  •  $PING_HOST"
        val tvPing = findViewById<TextView>(R.id.txtPing)
        if (caps == null) { tvPing.text = "—"; return }
        if (pinging) return
        pinging = true
        thread {
            // Latensi = waktu sambung TCP ke host DNS publik
            val ms = try {
                val t0 = SystemClock.elapsedRealtime()
                Socket().use { it.connect(InetSocketAddress(PING_HOST, 443), 2000) }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (e: Exception) { -1 }
            runOnUiThread {
                pinging = false
                tvPing.text = if (ms >= 0) ms.toString() else "—"
            }
        }
    }

    // ===== Pengaturan: hanya Tema & Bahasa =====
    private fun showSettings() {
        val d = Dialog(this, R.style.RyooSheet)
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        d.setContentView(v)
        v.findViewById<TextView>(R.id.valTheme).text = optionLabel(THEME_KEYS, if (isPurple()) "purple" else "blue")
        v.findViewById<TextView>(R.id.valLang).text = optionLabel(LANG_KEYS, prefs.getString("lang", "system"))
        // Mode root & kirim key lewat file: tersimpan langsung saat diubah
        bindSwitch(v, R.id.rowRoot, R.id.swRoot, "root", true)
        bindSwitch(v, R.id.rowKeyFile, R.id.swKeyFile, "keyToFile", false)
        bindSwitch(v, R.id.rowAutoUpdate, R.id.swAutoUpdate, "autoUpdate", true)
        v.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { d.dismiss() }
        v.findViewById<View>(R.id.rowTheme).setOnClickListener { d.dismiss(); chooseTheme() }
        v.findViewById<View>(R.id.rowLang).setOnClickListener { d.dismiss(); chooseLang() }
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun bindSwitch(v: View, rowId: Int, swId: Int, key: String, def: Boolean) {
        val sw = v.findViewById<androidx.appcompat.widget.SwitchCompat>(swId)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { b, on ->
            prefs.edit().putBoolean(key, on).apply()
            b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        v.findViewById<View>(rowId).setOnClickListener { sw.toggle() }
    }

    private fun optionLabel(keys: Array<String>, key: String?): String {
        val labels = when {
            keys === THEME_KEYS -> arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
            else -> arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        }
        return labels[keys.indexOf(key).coerceAtLeast(0)]
    }

    private fun chooseTheme() {
        val labels = arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
        val cur = if (isPurple()) 1 else 0
        var sel = cur
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.appearance)
            .setSingleChoiceItems(labels, cur) { _, which -> sel = which }
            .setPositiveButton(R.string.ok) { _, _ -> if (sel != cur) switchTheme(THEME_KEYS[sel]) }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    private fun chooseLang() {
        val labels = arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        val cur = LANG_KEYS.indexOf(prefs.getString("lang", "system")).coerceAtLeast(0)
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.language)
            .setSingleChoiceItems(labels, cur) { dlg, which ->
                prefs.edit().putString("lang", LANG_KEYS[which]).apply()
                dlg.dismiss()
                RyooApp.applyLang(LANG_KEYS[which])     // activity dibuat ulang otomatis
            }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    private fun AlertDialog.Builder.showGlass() {
        val d = create()
        d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        d.show()
    }

    private fun showInfo() {
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle("RyooXIT v${appVersion()}")
            .setMessage(R.string.info_msg)
            .setNeutralButton(R.string.check_update) { _, _ -> updater.check(true) }
            .setPositiveButton(R.string.ok, null).showGlass()
    }

    // ===== Cek tanda tangan APK =====
    // Ganti EXPECTED_SHA256 dengan hash sertifikat keystore kamu sendiri.
    // Cara dapat hash: keytool -list -v -keystore nama.jks -alias alias_kamu
    private fun isSignatureValid(): Boolean {
        return try {
            val sigHash = getSigningSha256() ?: return false
            sigHash.equals(EXPECTED_SHA256, ignoreCase = true)
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    private fun getSigningSha256(): String? {
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = packageManager.getPackageInfo(
                packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signingInfo = info.signingInfo ?: return null
            if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
            else signingInfo.signingCertificateHistory
        } else {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            info.signatures ?: return null
        }
        if (sigs.isEmpty()) return null
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(sigs[0].toByteArray())
        return digest.joinToString(":") { b -> "%02X".format(b) }
    }

    // ===== Background terenkripsi (XOR) dari assets/bg_blue.dat & bg_purple.dat (satu foto per tema) =====
    private fun loadBackground() {
        val iv = findViewById<ImageView>(R.id.imgBg)
        val file = if (isPurple()) "bg_purple.dat" else "bg_blue.dat"
        thread {
            try {
                val raw = assets.open(file).readBytes()
                val out = ByteArray(raw.size)
                for (i in raw.indices) out[i] = (raw[i].toInt() xor BG_KEY).toByte()
                val bmp = BitmapFactory.decodeByteArray(out, 0, out.size)
                runOnUiThread { iv.setImageBitmap(bmp) }
            } catch (e: Exception) { /* biarkan background polos kalau gagal */ }
        }
    }

    // Splash: logo + nama dua warna, lalu fade-out (dilewati saat activity dibuat ulang karena ganti tema/bahasa)
    private fun setupSplash(show: Boolean) {
        val splash = findViewById<View>(R.id.splash)
        if (!show) { splash.visibility = View.GONE; return }
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(600)
                .withEndAction { splash.visibility = View.GONE }.start()
        }, 1200)
    }

    // Logo berdenyut, XIT bercahaya, tombol mengecil saat ditekan
    @SuppressLint("ClickableViewAccessibility")
    private fun setupAnimations(btnRun: Button) {
        ObjectAnimator.ofPropertyValuesHolder(
            findViewById<View>(R.id.imgLogo),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f)
        ).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        ObjectAnimator.ofFloat(findViewById<View>(R.id.txtXit), View.ALPHA, 1f, 0.55f).apply {
            duration = 1100; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        btnRun.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    // Deteksi root ringan (tidak memunculkan popup izin)
    private fun checkRoot() {
        thread {
            val found = try {
                listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                    "/vendor/bin/su", "/product/bin/su").any { File(it).exists() } ||
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "command -v su"))
                        .inputStream.bufferedReader().readText().isNotBlank()
            } catch (e: Exception) { false }
            runOnUiThread { rootFound = found; rootChecked = true; applyRootUi() }
        }
    }

    private fun applyRootUi() {
        val tv = findViewById<TextView>(R.id.rootStatus)
        val badge = findViewById<TextView>(R.id.txtRootBadge)
        val sub = findViewById<TextView>(R.id.txtAccessSub)
        if (!rootChecked) {
            tv.setText(R.string.root_checking)
            badge.setText(R.string.root_checking)
            return
        }
        if (rootFound) {
            tv.setText(R.string.root_found)
            tv.setTextColor(Color.parseColor("#3DFF8F"))
            badge.setText(R.string.root_active)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#3DDC84"))
            badge.setTextColor(Color.parseColor("#06301A"))
            sub.setText(R.string.access_sub_root)
        } else {
            tv.setText(R.string.root_not_found)
            tv.setTextColor(Color.parseColor("#FF5A5A"))
            badge.setText(R.string.root_inactive)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FF8A80"))
            badge.setTextColor(Color.parseColor("#4A0A0A"))
            sub.setText(R.string.access_sub_noroot)
        }
    }

    companion object {
        private const val PAGE_HOME = 0
        private const val PAGE_PROFILE = 1
        private const val PING_HOST = "1.1.1.1"
        private val sessionStart = SystemClock.elapsedRealtime()

        // GANTI dengan link channel WhatsApp kamu
        const val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb8eX0Z1NCrYCXEXuu0K"
        // GANTI dengan nomor WhatsApp admin (format internasional tanpa + / 0 di depan, contoh 6281234567890)
        const val WA_ADMIN_URL = "https://wa.me/6285861526715"
        const val TIKTOK_URL = "https://www.tiktok.com/@ryoofren?_r=1&_t=ZS-9BE8WQ79dxu"
        private val THEME_KEYS = arrayOf("blue", "purple")
        private var pendingSnapshot: Bitmap? = null
        private val LANG_KEYS = arrayOf("system", "id", "en")
        const val DEFAULT_CMD = "su -c \"cd /data/local/tmp && sh ./RyooXIT.sh\""

        // Kunci XOR untuk background terenkripsi (harus sama dengan yang dipakai saat enkripsi).
        const val BG_KEY = 0x5A

        // Hash SHA-256 sertifikat RELEASE resmi kamu.
        // Dapatkan dengan: keytool -list -v -keystore ryooxit.jks -alias ryooxit
        const val EXPECTED_SHA256 =
            "26:A5:E8:E3:4F:9A:AA:5C:EF:4C:A8:F8:FA:9A:EB:5F:36:85:66:33:0C:83:2E:82:E6:B4:DA:31:E1:4C:0C:06"
    }
}
