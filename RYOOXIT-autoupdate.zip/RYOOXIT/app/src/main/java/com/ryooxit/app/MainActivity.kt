package com.ryooxit.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.media.ExifInterface
import android.view.ViewOutlineProvider
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.content.FileProvider
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.system.exitProcess

// Command tersimpan: nama (boleh kosong) + isi command
private data class SavedCmd(val name: String, val cmd: String)

// Item yang dipilih untuk disalin / dipindah (menunggu ditempel)
// Isi zip (untuk menjelajah zip tanpa ekstrak)
private data class ZipItem(val name: String, val isDir: Boolean, val size: Long)

private data class ClipItem(val path: String, val isDir: Boolean, val cut: Boolean, val viaRoot: Boolean)

// Aplikasi yang mempunyai launcher Activity dan terlihat oleh PackageManager.
private data class InstalledApp(val label: String, val packageName: String, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("ryooxit", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val updater by lazy { Updater(this) }

    // Status perintah yang sedang dijalankan (untuk tombol STOP)
    @Volatile private var running = false
    @Volatile private var runProc: Process? = null
    @Volatile private var runRoot = true
    private val stopRequested = java.util.concurrent.atomic.AtomicBoolean(false)
    private lateinit var txtCmdTitle: TextView

    private lateinit var cmdBox: EditText
    private lateinit var keyBox: EditText
    private lateinit var pageHome: View
    private lateinit var pageProfile: View
    private lateinit var pageFile: FrameLayout
    private lateinit var pageApk: FrameLayout

    // Add APK Native: pilihan disimpan setelah pengguna menekan SIMPAN.
    private lateinit var apkHostIcon: ImageView
    private lateinit var apkHostName: TextView
    private lateinit var apkHostPackage: TextView
    private lateinit var apkTargetIcon: ImageView
    private lateinit var apkTargetName: TextView
    private lateinit var apkTargetPackage: TextView
    private lateinit var apkInternalNameInput: EditText
    private lateinit var apkRouteInput: EditText
    private lateinit var apkStatus: TextView
    private lateinit var apkAccessibilityStatus: TextView
    private var pendingHostPackage = ""
    private var pendingTargetPackage = ""

    private var page = PAGE_HOME
    private var rootFound = false
    private var rootChecked = false
    private var tick = 0
    private var pinging = false
    private var fileTab = FILE_INTERNAL
    private var internalPath: File = Environment.getExternalStorageDirectory()
    private var rootPath: String = "/"
    private val recentFiles = linkedSetOf<String>()
    @Volatile private var rootDirectories: Set<String> = emptySet()
    private var renderToken = 0
    private var clip: ClipItem? = null

    // Foto profil: disimpan di penyimpanan privat app (tetap ada setelah update)
    private val avatarFile by lazy { File(filesDir, "avatar.png") }
    private val pickAvatar = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveAvatar(uri)
    }

    // Pencarian File Manager: searchQuery = kata kunci aktif (kosong = mode normal)
    private var searchQuery = ""
    private var searchBar: LinearLayout? = null
    private var searchInput: EditText? = null

    // Mode jelajah zip: zipOrig = file zip aslinya, zipSrc = salinan yang bisa dibaca app
    private var zipOrig: File? = null
    private var zipSrc: File? = null
    private var zipIsCopy = false
    private var zipInner = ""                     // folder di dalam zip yang sedang dibuka ("" = akar)
    private var zipIndex: List<ZipItem> = emptyList()

    // ===== Siklus hidup =====
    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Tema (Biru / Ungu) dipilih dari pengaturan; bawaan Biru
        setTheme(if (isPurple()) R.style.Theme_Ryooxit_Purple else R.style.Theme_Ryooxit)
        super.onCreate(savedInstanceState)

        if (!isSignatureValid()) {
            // APK sudah diubah / ditandatangani ulang oleh orang lain: hentikan app.
            AlertDialog.Builder(this)
                .setTitle(R.string.verify_fail_title)
                .setMessage(R.string.verify_fail_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.close) { _, _ -> finishAffinity(); exitProcess(0) }
                .show()
            return
        }

        setContentView(R.layout.activity_main)
        page = savedInstanceState?.getInt("page", PAGE_HOME) ?: PAGE_HOME

        // Kedua tema gelap: ikon status bar & navigation bar berwarna terang
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        pageHome = findViewById(R.id.pageHome)
        pageProfile = findViewById(R.id.pageProfile)
        pageFile = findViewById(R.id.pageFile)
        pageApk = findViewById(R.id.pageApk)
        buildFileExplorer()
        buildApkLauncher()
        findViewById<View>(R.id.avatarFrame).setOnClickListener { showAvatarMenu() }
        applyAvatar()
        loadBackground()

        cmdBox = findViewById(R.id.cmdBox)
        keyBox = findViewById(R.id.keyBox)
        val btnRun = findViewById<Button>(R.id.btnRun)
        cmdBox.setText(prefs.getString("cmd", DEFAULT_CMD))
        txtCmdTitle = findViewById(R.id.txtCmdTitle)
        cmdBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { refreshCmdTitle() }
        })
        refreshCmdTitle()
        updateLastRun()
        keyBox.setText(prefs.getString("key", ""))

        setupSplash(savedInstanceState == null)
        // Update otomatis: cek sekali tiap app dibuka (bukan saat activity dibuat ulang karena ganti tema/bahasa)
        if (savedInstanceState == null && prefs.getBoolean("autoUpdate", true)) {
            window.decorView.postDelayed({ if (!isFinishing) updater.check(false) }, 2500)
        }
        setupAnimations(btnRun)
        checkRoot()
        fillStaticInfo()

        // Navigasi bawah
        findViewById<View>(R.id.navHome).setOnClickListener { showPage(PAGE_HOME, true) }
        findViewById<View>(R.id.navApk).setOnClickListener { showPage(PAGE_APK, true) }
        findViewById<View>(R.id.navFile).setOnClickListener { showPage(PAGE_FILE, true) }
        findViewById<View>(R.id.navProfile).setOnClickListener { showPage(PAGE_PROFILE, true) }
        showPage(page)
        playThemeSwitchAnim()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (page) {
                    PAGE_FILE -> { if (searchQuery.isNotEmpty() || searchBar?.visibility == View.VISIBLE) resetSearch(true) else if (!navigateFileUp()) showPage(PAGE_HOME, true) }
                    PAGE_PROFILE, PAGE_APK -> showPage(PAGE_HOME, true)
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnInfo).setOnClickListener { showInfo() }
        findViewById<View>(R.id.btnProfileTop).setOnClickListener { showPage(PAGE_PROFILE, true) }
        findViewById<View>(R.id.btnCmdGo).setOnClickListener { showCommandPicker() }
        findViewById<LinearLayout>(R.id.btnChannel).setOnClickListener {
            openLink(WA_CHANNEL_URL, R.string.link_fail)
        }
        findViewById<LinearLayout>(R.id.btnAdmin).setOnClickListener {
            openLink(WA_ADMIN_URL, R.string.wa_fail)
        }

        findViewById<LinearLayout>(R.id.btnTiktok).setOnClickListener {
            openLink(TIKTOK_URL, R.string.link_fail)
        }

        btnRun.setOnClickListener {
            // Sedang berjalan -> tombol ini menjadi STOP
            if (running) { stopRunning(); return@setOnClickListener }
            val cmd = cmdBox.text.toString().trim()
            if (cmd.isEmpty()) return@setOnClickListener
            val root = prefs.getBoolean("root", true)
            val key = keyBox.text.toString().trim()
            prefs.edit().putString("key", key).putString("cmd", cmd).apply()
            btnRun.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            running = true
            runRoot = root
            stopRequested.set(false)
            btnRun.setText(R.string.stop)
            val writeKeyFile = prefs.getBoolean("keyToFile", false)
            thread {
                val pidFile = File(cacheDir, "run.pid")
                val script = File(cacheDir, "run_cmd.sh")
                val out = try {
                    // Opsional: tulis key ke /data/local/tmp/key.txt dulu, sebelum script dijalankan.
                    // Script bisa membacanya sendiri, misalnya: KEY=$(cat /data/local/tmp/key.txt)
                    if (writeKeyFile && key.isNotEmpty() && root) {
                        val wp = ProcessBuilder("su", "-c", "umask 077; cat > /data/local/tmp/key.txt")
                            .redirectErrorStream(true).start()
                        wp.outputStream.bufferedWriter().use { w -> w.write(key) }
                        wp.waitFor()
                    }
                    // Hindari "su -c su -c ..." jika prefix su -c sudah ditulis pengguna.
                    // Kutip penutup yang lupa ditulis ikut ditoleransi.
                    val hadSu = Regex("^su\\s+-c\\s+").containsMatchIn(cmd)
                    var cleanCmd = cmd.replace(Regex("^su\\s+-c\\s+"), "")
                    if (hadSu && cleanCmd.startsWith('"')) {
                        cleanCmd = cleanCmd.removePrefix("\"").removeSuffix("\"")
                    } else if (cleanCmd.length >= 2 && cleanCmd.startsWith('"') && cleanCmd.endsWith('"')) {
                        cleanCmd = cleanCmd.substring(1, cleanCmd.length - 1)
                    }

                    // Perintah dijalankan lewat file skrip yang mencatat PID-nya, supaya STOP bisa
                    // mematikan skrip beserta semua proses turunannya (bukan hanya "su"-nya).
                    pidFile.delete()
                    if (root && pidFile.exists()) shellOut(true, "rm -f '${pidFile.absolutePath}'")
                    script.writeText("echo \$\$ > '${pidFile.absolutePath}'\n$cleanCmd\n")
                    val args = if (root) arrayOf("su", "-c", "sh '${script.absolutePath}'")
                               else arrayOf("sh", script.absolutePath)
                    val p = ProcessBuilder(*args).redirectErrorStream(true).start()
                    runProc = p
                    if (stopRequested.get()) p.destroy()

                    // Kirim key bila diperlukan, lalu tutup stdin agar proses menerima EOF.
                    p.outputStream.bufferedWriter().use { w ->
                        if (key.isNotEmpty()) w.write(key + "\n")
                    }

                    val output = p.inputStream.use { readCapped(it, OUT_CAP) }
                    val exitCode = p.waitFor()
                    // key.txt hanya perlu ada selama script berjalan: hapus setelah selesai
                    if (writeKeyFile && key.isNotEmpty() && root) {
                        try {
                            ProcessBuilder("su", "-c", "rm -f /data/local/tmp/key.txt")
                                .redirectErrorStream(true).start().waitFor()
                        } catch (_: Exception) { }
                    }
                    val diagnosis = when {
                        stopRequested.get() -> ""
                        output.contains("cannot locate symbol", ignoreCase = true) ||
                            output.contains("CANNOT LINK EXECUTABLE", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Kegagalan linker: executable atau library-nya tidak cocok/tidak menyediakan simbol yang diminta. Runner tidak dapat memperbaiki ABI atau library yang salah secara otomatis."
                        output.contains("Permission denied", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Izin ditolak. Periksa izin file, konteks SELinux, dan hak akses proses."
                        output.contains("not found", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Perintah atau file yang dipanggil tidak ditemukan. Periksa PATH dan lokasi file."
                        else -> ""
                    }
                    val stopNote = if (stopRequested.get()) "\n\n[Dihentikan oleh pengguna]" else ""
                    (output.ifBlank { getString(R.string.done_no_output) }).takeLast(20000) +
                        "\n\nExit code: $exitCode" + diagnosis + stopNote
                } catch (ex: Exception) {
                    if (stopRequested.get()) "[Dihentikan oleh pengguna]" else "Error: ${ex.message}"
                }
                runProc = null
                script.delete(); pidFile.delete()
                prefs.edit().putLong("lastRun", System.currentTimeMillis()).apply()
                runOnUiThread {
                    running = false
                    updateLastRun()
                    btnRun.isEnabled = true
                    btnRun.setText(R.string.run)
                    showTextDialog(getString(R.string.output_title), out, getString(R.string.ok))
                }
            }
        }
    }

    // ===== STOP: hentikan perintah yang sedang berjalan beserta semua proses turunannya =====
    private fun stopRunning() {
        if (!running || stopRequested.getAndSet(true)) return
        val p = runProc
        val root = runRoot
        thread {
            var pid: Int? = null
            for (n in 0 until 15) {                 // tunggu sebentar kalau skrip baru saja dimulai
                pid = readRunPid(root)
                if (pid != null) break
                Thread.sleep(100)
            }
            try { if (pid != null) killTree(pid, root) } catch (_: Exception) { }
            try { p?.destroy() } catch (_: Exception) { }
            Thread.sleep(3000)
            // Kalau masih ada proses yang menahan output, putuskan pembacaan secara paksa
            if (running && runProc === p) { try { p?.inputStream?.close() } catch (_: Exception) { } }
        }
    }

    private fun readRunPid(root: Boolean): Int? {
        val f = File(cacheDir, "run.pid")
        val txt = try { f.readText() }
                  catch (_: Exception) { if (root) shellOut(true, "cat '${f.absolutePath}'") else "" }
        return txt.trim().toIntOrNull()
    }

    private fun shellOut(root: Boolean, cmd: String): String = try {
        val args = if (root) arrayOf("su", "-c", cmd) else arrayOf("sh", "-c", cmd)
        val p = ProcessBuilder(*args).redirectErrorStream(true).start()
        val t = readCapped(p.inputStream, TEXT_CAP); p.waitFor(); t
    } catch (e: Exception) { "" }

    // Cari semua proses turunan dari rootPid lalu hentikan (dibekukan dulu supaya tidak sempat membuat proses baru)
    private fun killTree(rootPid: Int, root: Boolean) {
        if (rootPid <= 1) return
        val kids = HashMap<Int, MutableList<Int>>()
        var parsed = 0
        for (line in shellOut(root, "ps -A -o PID,PPID 2>/dev/null").lines()) {
            val t = line.trim().split(Regex("\\s+"))
            val a = t.getOrNull(0)?.toIntOrNull(); val b = t.getOrNull(1)?.toIntOrNull()
            if (a != null && b != null) { kids.getOrPut(b) { mutableListOf() }.add(a); parsed++ }
        }
        if (parsed == 0) {                          // Android lama: format "ps" biasa (USER PID PPID ...)
            for (line in shellOut(root, "ps").lines()) {
                val t = line.trim().split(Regex("\\s+"))
                val a = t.getOrNull(1)?.toIntOrNull(); val b = t.getOrNull(2)?.toIntOrNull()
                if (a != null && b != null) kids.getOrPut(b) { mutableListOf() }.add(a)
            }
        }
        val all = mutableListOf(rootPid)
        var i = 0
        while (i < all.size) {
            kids[all[i]]?.forEach { c -> if (c !in all) all.add(c) }
            i++
        }
        val list = all.joinToString(" ")
        shellOut(root, "kill -STOP $list 2>/dev/null; kill -KILL $list 2>/dev/null")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
    }

    override fun onResume() {
        super.onResume()
        if (::pageProfile.isInitialized && page == PAGE_PROFILE) startTicker()
        if (::pageFile.isInitialized && page == PAGE_FILE && fileTab == FILE_INTERNAL && hasAllFilesAccess())
            renderCurrentFileTab()
        if (::pageApk.isInitialized && page == PAGE_APK) {
            refreshApkSelectionViews()
            refreshAincradAccessibilityStatus()
        }
    }

    override fun onPause() {
        super.onPause()
        stopTicker()
    }

    // ===== Navigasi Home / Profile (dengan animasi geser + pudar) =====
    private fun showPage(p: Int, animate: Boolean = false) {
        val prev = page
        val next = p.coerceIn(PAGE_HOME, PAGE_APK)
        page = next
        val pages = listOf(pageHome, pageFile, pageProfile, pageApk)
        val inV = pages[next]
        val outV = pages[prev.coerceIn(PAGE_HOME, PAGE_APK)]
        inV.animate().cancel(); outV.animate().cancel()

        if (animate && prev != next) {
            // Bar bawah: label membuka/menutup dengan mulus
            val nav = findViewById<View>(R.id.navHome).parent as ViewGroup
            android.transition.TransitionManager.beginDelayedTransition(
                nav, android.transition.AutoTransition().setDuration(260))
        }
        setNavItem(R.id.navHome, R.id.navHomeLabel, next == PAGE_HOME)
        setNavItem(R.id.navApk, R.id.navApkLabel, next == PAGE_APK)
        setNavItem(R.id.navFile, R.id.navFileLabel, next == PAGE_FILE)
        setNavItem(R.id.navProfile, R.id.navProfileLabel, next == PAGE_PROFILE)
        if (next == PAGE_PROFILE) startTicker() else stopTicker()
        if (next == PAGE_APK) refreshAincradAccessibilityStatus()

        if (!animate || prev == next) {
            pages.forEachIndexed { i, v ->
                v.visibility = if (i == next) View.VISIBLE else View.GONE
                v.alpha = 1f; v.translationX = 0f
            }
            return
        }
        val dx = resources.displayMetrics.widthPixels * 0.14f
        val dir = if (next > prev) 1f else -1f
        outV.animate().alpha(0f).translationX(-dir * dx * 0.6f).setDuration(200)
            .withEndAction {
                if (page == next) { outV.visibility = View.GONE }
                outV.alpha = 1f; outV.translationX = 0f
            }.start()
        inV.alpha = 0f; inV.translationX = dir * dx; inV.visibility = View.VISIBLE
        inV.animate().alpha(1f).translationX(0f).setStartDelay(70).setDuration(340)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        val staggerTarget = when (next) {
            PAGE_PROFILE -> (pageProfile as ViewGroup).getChildAt(0) as? ViewGroup
            PAGE_FILE -> pageFile.getChildAt(0) as? ViewGroup
            PAGE_APK -> pageApk.getChildAt(0) as? ViewGroup
            else -> ((pageHome as ViewGroup).getChildAt(0) as ViewGroup).getChildAt(0) as? ViewGroup
        }
        staggerTarget?.let { staggerIn(it) }
    }

    // Kartu-kartu muncul berurutan dari bawah
    private fun staggerIn(col: ViewGroup) {
        val rise = resources.displayMetrics.density * 26f
        for (i in 0 until col.childCount) {
            val ch = col.getChildAt(i)
            ch.animate().cancel()
            ch.alpha = 0f; ch.translationY = rise
            ch.animate().alpha(1f).translationY(0f)
                .setStartDelay(110L + i * 55L).setDuration(360)
                .setInterpolator(DecelerateInterpolator(1.5f)).start()
        }
    }

    // ===== FILE: tiga halaman (Internal, Root, Terbaru) =====
    private fun buildFileExplorer() {
        val accent = if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255)
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(38), dp(18), dp(110))
        }
        val title = TextView(this).apply {
            text = "File Manager"
            textSize = 30f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val searchBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_search)
            contentDescription = "Cari"
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = fileCardBackground()
        }
        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            addView(searchBtn, LinearLayout.LayoutParams(dp(46), dp(46)))
        }
        base.addView(titleRow)
        val subtitle = TextView(this).apply {
            text = "Jelajahi penyimpanan dan file sistem"
            textSize = 13f; setTextColor(Color.LTGRAY)
            setPadding(0, dp(3), 0, dp(16))
        }
        base.addView(subtitle)
        val input = EditText(this).apply {
            hint = "Cari file atau folder di sini…"
            setHintTextColor(0xFFAA99BB.toInt()); setTextColor(Color.WHITE); textSize = 14f
            isSingleLine = true
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            background = null
            setPadding(dp(14), dp(12), dp(8), dp(12))
        }
        val clearBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_close)
            contentDescription = "Tutup pencarian"
            background = null; scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = fileCardBackground(); visibility = View.GONE
            addView(input, LinearLayout.LayoutParams(0, -2, 1f))
            addView(clearBtn, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        base.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        searchBar = bar; searchInput = input
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x55301050); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0x887F42B8.toInt())
            }
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabLabels = listOf("Internal", "Root", "Terbaru")
        tabLabels.forEachIndexed { index, label ->
            val tab = TextView(this).apply {
                text = label; textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12)); setTextColor(Color.WHITE)
                setOnClickListener { closeZipBrowser(); fileTab = index; renderCurrentFileTab() }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        base.addView(tabs)
        base.addView(content, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(14) })
        pageFile.addView(ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false; addView(base)
        }, FrameLayout.LayoutParams(-1, -1))
        pageFile.tag = Pair(tabs, content)

        // Tombol cari: buka/tutup kolom pencarian
        searchBtn.setOnClickListener {
            if (bar.visibility == View.VISIBLE) resetSearch(true)
            else {
                bar.visibility = View.VISIBLE
                input.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
        clearBtn.setOnClickListener { resetSearch(true) }
        input.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                searchQuery = v.text.toString().trim()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                    .hideSoftInputFromWindow(v.windowToken, 0)
                renderCurrentFileTab()
                true
            } else false
        }
        updateFileTabStyles(tabs, accent)
        renderFileTab(content, accent)
    }

    // ===== ADD APK NATIVE: pilih aplikasi terpasang tanpa command shell =====
    private fun buildApkLauncher() {
        pendingHostPackage = prefs.getString(PREF_APK_HOST, "").orEmpty()
        pendingTargetPackage = prefs.getString(PREF_APK_TARGET, "").orEmpty()

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(38), dp(20), dp(132))
        }
        content.addView(TextView(this).apply {
            text = "Add APK Native"
            textSize = 30f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
        })
        content.addView(TextView(this).apply {
            text = "Pilih aplikasi container dan aplikasi tujuan dari daftar aplikasi Android."
            textSize = 13f
            setTextColor(themeColor(R.attr.t_text_secondary))
            setPadding(0, dp(4), 0, dp(16))
        })

        // Kartu aplikasi container/host.
        val hostCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundResource(R.drawable.bg_card)
        }
        hostCard.addView(TextView(this).apply {
            text = "APLIKASI CONTAINER / HOST"
            textSize = 12f
            letterSpacing = 0.08f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_accent))
        })
        val hostRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        apkHostIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = fileCardBackground()
        }
        hostRow.addView(apkHostIcon, LinearLayout.LayoutParams(dp(52), dp(52)))
        val hostLabels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apkHostName = TextView(this).apply {
            text = "Belum dipilih"; textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
        }
        apkHostPackage = TextView(this).apply {
            text = "Pilih aplikasi yang akan dibuka lebih dulu"; textSize = 10f
            setTextColor(themeColor(R.attr.t_text_hint)); maxLines = 2
        }
        hostLabels.addView(apkHostName)
        hostLabels.addView(apkHostPackage)
        hostRow.addView(hostLabels, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        val pickHost = TextView(this).apply {
            text = "PILIH"; textSize = 12f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setBackgroundResource(R.drawable.bg_btn_secondary)
            setOnClickListener { showInstalledAppPicker(true) }
        }
        hostRow.addView(pickHost, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        hostCard.addView(hostRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        content.addView(hostCard)

        // Kartu aplikasi tujuan yang memang terpasang sebagai aplikasi Android tersendiri.
        val targetCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundResource(R.drawable.bg_card)
        }
        targetCard.addView(TextView(this).apply {
            text = "APLIKASI TUJUAN (JALANKAN LANGSUNG)"
            textSize = 12f; letterSpacing = 0.08f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_accent))
        })
        val targetRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        apkTargetIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_grid)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = fileCardBackground()
        }
        targetRow.addView(apkTargetIcon, LinearLayout.LayoutParams(dp(52), dp(52)))
        val targetLabels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apkTargetName = TextView(this).apply {
            text = "Belum dipilih"; textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
        }
        apkTargetPackage = TextView(this).apply {
            text = "Pilih aplikasi tujuan yang terpasang"; textSize = 10f
            setTextColor(themeColor(R.attr.t_text_hint)); maxLines = 2
        }
        targetLabels.addView(apkTargetName)
        targetLabels.addView(apkTargetPackage)
        targetRow.addView(targetLabels, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        val pickTarget = TextView(this).apply {
            text = "PILIH"; textSize = 12f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setBackgroundResource(R.drawable.bg_btn_secondary)
            setOnClickListener { showInstalledAppPicker(false) }
        }
        targetRow.addView(pickTarget, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        targetCard.addView(targetRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        targetCard.addView(TextView(this).apply {
            text = "Dipakai untuk membuka aplikasi tujuan secara langsung jika container tidak dipilih."
            textSize = 10f
            setTextColor(themeColor(R.attr.t_text_hint))
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(targetCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // Nama game internal dapat dicatat manual; daftar internal milik host tidak terlihat oleh PackageManager.
        val integrationCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundResource(R.drawable.bg_card)
        }
        integrationCard.addView(TextView(this).apply {
            text = "INTEGRASI GAME DI DALAM CONTAINER"
            textSize = 12f; letterSpacing = 0.06f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_accent))
        })
        apkInternalNameInput = EditText(this).apply {
            hint = "Nama game internal, contoh: Free Fire MAX"
            setText(prefs.getString(PREF_APK_INTERNAL_NAME, "").orEmpty().ifBlank { "Free Fire MAX" })
            textSize = 13f
            setTextColor(themeColor(R.attr.t_text_primary))
            setHintTextColor(themeColor(R.attr.t_text_hint))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = fileCardBackground()
        }
        integrationCard.addView(apkInternalNameInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        apkRouteInput = EditText(this).apply {
            hint = "Deep link / Intent URI resmi (opsional)"
            setText(prefs.getString(PREF_APK_ROUTE, ""))
            textSize = 13f
            setTextColor(themeColor(R.attr.t_text_primary))
            setHintTextColor(themeColor(R.attr.t_text_hint))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = fileCardBackground()
        }
        integrationCard.addView(apkRouteInput, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        integrationCard.addView(TextView(this).apply {
            text = "Catatan integrasi: game yang hanya ada di menu internal container tidak bisa dibaca otomatis oleh PackageManager. Agar bisa langsung dibuka, container harus menyediakan deep link, Intent, atau API resmi."
            textSize = 11f
            setTextColor(themeColor(R.attr.t_text_hint))
            setPadding(0, dp(10), 0, 0)
        })
        integrationCard.addView(TextView(this).apply {
            text = "Jika container meminta key/login, lakukan login secara manual. Kembali ke RYOOXIT lalu tekan JALANKAN lagi. Sesi background tidak dijamin tetap hidup karena Android dapat menghentikan proses aplikasi."
            textSize = 11f
            setTextColor(themeColor(R.attr.t_text_hint))
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(integrationCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        // Accessibility hanya untuk memilih label game di Aincrad; pengguna mengaktifkannya manual.
        val accessibilityCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(R.drawable.bg_card)
        }
        accessibilityCard.addView(TextView(this).apply {
            text = "AKSESIBILITAS AINCRAD"
            textSize = 12f
            letterSpacing = 0.07f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_accent))
        })
        apkAccessibilityStatus = TextView(this).apply {
            textSize = 11f
            setTextColor(themeColor(R.attr.t_text_secondary))
            setPadding(0, dp(8), 0, dp(10))
        }
        accessibilityCard.addView(apkAccessibilityStatus)
        val accessibilityButton = TextView(this).apply {
            text = "BUKA PENGATURAN AKSESIBILITAS"
            textSize = 12f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
            setPadding(dp(12), dp(13), dp(12), dp(13))
            setBackgroundResource(R.drawable.bg_btn_secondary)
            setOnClickListener { openAincradAccessibilitySettings() }
        }
        accessibilityCard.addView(accessibilityButton, LinearLayout.LayoutParams(-1, -2))
        accessibilityCard.addView(TextView(this).apply {
            text = "Izin ini wajib diaktifkan sendiri. Saat proses berjalan, layanan dibatasi ke aplikasi container yang dipilih dan berhenti setelah menemukan serta memilih nama game yang tepat."
            textSize = 10f
            setTextColor(themeColor(R.attr.t_text_hint))
            setPadding(0, dp(9), 0, 0)
        })
        content.addView(accessibilityCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val saveButton = TextView(this).apply {
            text = "SIMPAN PILIHAN"; textSize = 14f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_on_accent))
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundResource(R.drawable.bg_btn_primary)
            setOnClickListener { saveApkConfiguration(true) }
        }
        content.addView(saveButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })

        val runButton = TextView(this).apply {
            text = "▶  JALANKAN"; textSize = 16f; gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_on_accent))
            setPadding(dp(16), dp(17), dp(16), dp(17))
            setBackgroundResource(R.drawable.bg_btn_primary)
            setOnClickListener { runNativeApkFlow() }
        }
        content.addView(runButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        apkStatus = TextView(this).apply {
            text = "Pilih aplikasi container untuk memulai."
            textSize = 11f
            setTextColor(themeColor(R.attr.t_text_secondary))
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(4))
        }
        content.addView(apkStatus)

        pageApk.addView(ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(content)
        }, FrameLayout.LayoutParams(-1, -1))
        refreshApkSelectionViews()
    }

    private fun isAincradAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        val expected = ComponentName(this, AincradAccessibilityService::class.java).flattenToString()
        return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun openAincradAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, "Pengaturan Accessibility tidak dapat dibuka: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshAincradAccessibilityStatus() {
        if (!::apkAccessibilityStatus.isInitialized) return
        apkAccessibilityStatus.text = if (isAincradAccessibilityEnabled()) {
            "● AKTIF — layanan menunggu perintah JALANKAN. Pemantauan UI hanya dilakukan pada container yang dipilih."
        } else {
            "○ BELUM AKTIF — aktifkan manual agar RYOOXIT dapat menemukan nama game di Aincrad."
        }
        val savedStatus = prefs.getString(AincradAccessibilityService.PREF_STATUS, "").orEmpty()
        if (savedStatus.isNotBlank() && ::apkStatus.isInitialized) apkStatus.text = savedStatus
    }

    @Suppress("DEPRECATION")
    private fun queryInstalledLauncherApps(): List<InstalledApp> {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return try {
            packageManager.queryIntentActivities(launcherIntent, 0)
                .mapNotNull { info ->
                    val appInfo = info.activityInfo ?: return@mapNotNull null
                    val pkg = appInfo.packageName
                    if (pkg == packageName) return@mapNotNull null
                    try {
                        InstalledApp(
                            label = info.loadLabel(packageManager)?.toString()?.ifBlank { pkg } ?: pkg,
                            packageName = pkg,
                            icon = info.loadIcon(packageManager)
                        )
                    } catch (_: Exception) { null }
                }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase(Locale.ROOT) }
        } catch (_: Exception) { emptyList() }
    }

    private fun showInstalledAppPicker(forHost: Boolean) {
        val apps = queryInstalledLauncherApps().filterNot {
            !forHost && it.packageName == pendingHostPackage
        }
        if (apps.isEmpty()) {
            AlertDialog.Builder(this, R.style.RyooDialog)
                .setTitle("Aplikasi tidak ditemukan")
                .setMessage("Tidak ada aplikasi dengan ikon launcher yang dapat ditampilkan.")
                .setPositiveButton(R.string.ok, null).showGlass()
            return
        }
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): InstalledApp = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val app = apps[position]
                val row = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(9), dp(12), dp(9))
                    val icon = ImageView(this@MainActivity)
                    addView(icon, LinearLayout.LayoutParams(dp(42), dp(42)))
                    val labels = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                    labels.addView(TextView(this@MainActivity).apply {
                        textSize = 15f; setTypeface(typeface, android.graphics.Typeface.BOLD)
                        setTextColor(themeColor(R.attr.t_text_primary))
                    })
                    labels.addView(TextView(this@MainActivity).apply {
                        textSize = 10f; setTextColor(themeColor(R.attr.t_text_hint))
                    })
                    addView(labels, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
                }
                (row.getChildAt(0) as ImageView).setImageDrawable(app.icon)
                val labels = row.getChildAt(1) as LinearLayout
                (labels.getChildAt(0) as TextView).text = app.label
                (labels.getChildAt(1) as TextView).text = app.packageName
                return row
            }
        }
        val picker = AlertDialog.Builder(this, R.style.RyooDialog)
            .setTitle(if (forHost) "Pilih aplikasi container" else "Pilih aplikasi tujuan")
            .setAdapter(adapter) { _, which ->
                if (forHost) {
                    pendingHostPackage = apps[which].packageName
                    if (pendingTargetPackage == pendingHostPackage) pendingTargetPackage = ""
                } else {
                    pendingTargetPackage = apps[which].packageName
                }
                refreshApkSelectionViews()
            }
            .setNegativeButton(R.string.cancel, null)
        picker.setNeutralButton(if (forHost) "Hapus container" else "Hapus tujuan") { _, _ ->
            if (forHost) pendingHostPackage = "" else pendingTargetPackage = ""
            refreshApkSelectionViews()
        }
        picker.showGlass()
    }

    private fun refreshApkSelectionViews() {
        if (!::apkHostName.isInitialized) return
        updateApkAppRow(pendingHostPackage, apkHostIcon, apkHostName, apkHostPackage, "Pilih aplikasi container")
        updateApkAppRow(pendingTargetPackage, apkTargetIcon, apkTargetName, apkTargetPackage, "Pilih aplikasi tujuan")
    }

    @Suppress("DEPRECATION")
    private fun updateApkAppRow(pkg: String, iconView: ImageView, nameView: TextView, packageView: TextView, emptyText: String) {
        if (pkg.isBlank()) {
            nameView.text = "Belum dipilih"
            packageView.text = emptyText
            iconView.setImageResource(R.drawable.ic_grid)
            return
        }
        try {
            val appInfo = packageManager.getApplicationInfo(pkg, 0)
            nameView.text = packageManager.getApplicationLabel(appInfo)?.toString() ?: pkg
            packageView.text = pkg
            iconView.setImageDrawable(packageManager.getApplicationIcon(appInfo))
        } catch (_: Exception) {
            nameView.text = "Aplikasi tidak terpasang"
            packageView.text = pkg
            iconView.setImageResource(R.drawable.ic_info)
        }
    }

    private fun saveApkConfiguration(showToast: Boolean) {
        val internalName = apkInternalNameInput.text.toString().trim()
        val route = apkRouteInput.text.toString().trim()
        prefs.edit()
            .putString(PREF_APK_HOST, pendingHostPackage)
            .putString(PREF_APK_TARGET, pendingTargetPackage)
            .putString(PREF_APK_INTERNAL_NAME, internalName)
            .putString(PREF_APK_ROUTE, route)
            .apply()
        if (showToast) {
            apkStatus.text = "Pilihan aplikasi berhasil disimpan."
            Toast.makeText(this, "Pilihan Add APK disimpan", Toast.LENGTH_SHORT).show()
        }
    }

    private fun runNativeApkFlow() {
        saveApkConfiguration(false)
        val host = pendingHostPackage
        val target = pendingTargetPackage
        val internalName = apkInternalNameInput.text.toString().trim()
        val route = apkRouteInput.text.toString().trim()

        if (host.isBlank() && target.isBlank()) {
            apkStatus.text = "Pilih aplikasi container atau aplikasi tujuan terlebih dahulu."
            Toast.makeText(this, "Pilih aplikasi terlebih dahulu", Toast.LENGTH_SHORT).show()
            return
        }

        // Jika container dipilih, gunakan Accessibility hanya untuk memilih nama game yang tepat.
        if (host.isNotBlank()) {
            val useAccessibility = route.isBlank()
            if (useAccessibility && internalName.isBlank()) {
                apkStatus.text = "Isi nama game internal terlebih dahulu."
                Toast.makeText(this, "Nama game belum diisi", Toast.LENGTH_SHORT).show()
                return
            }
            if (useAccessibility && !isAincradAccessibilityEnabled()) {
                apkStatus.text = "Aktifkan Accessibility RYOOXIT secara manual, lalu kembali dan tekan JALANKAN."
                AlertDialog.Builder(this, R.style.RyooDialog)
                    .setTitle("Aktifkan Accessibility")
                    .setMessage("RYOOXIT memerlukan izin Accessibility untuk menemukan dan memilih label '$internalName' di aplikasi container '$host'. Izin tidak akan diaktifkan otomatis. Buka pengaturan lalu aktifkan layanan RYOOXIT secara manual.")
                    .setPositiveButton("BUKA PENGATURAN") { _, _ -> openAincradAccessibilitySettings() }
                    .setNegativeButton(R.string.cancel, null)
                    .showGlass()
                return
            }
            if (useAccessibility && !AincradAccessibilityService.begin(this, host, internalName)) {
                apkStatus.text = "Accessibility sudah diaktifkan tetapi layanan belum tersambung. Tunggu sebentar, lalu coba lagi."
                Toast.makeText(this, apkStatus.text, Toast.LENGTH_LONG).show()
                return
            }

            try {
                val launchIntent = if (route.isNotBlank()) {
                    createContainerRouteIntent(host, route)
                } else {
                    packageManager.getLaunchIntentForPackage(host)
                        ?: throw android.content.ActivityNotFoundException("Aplikasi container tidak memiliki launcher Activity.")
                }
                startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                apkStatus.text = if (useAccessibility) {
                    "Aincrad dibuka. RYOOXIT sedang mencari label '$internalName'. Layanan akan berhenti setelah memilih game."
                } else {
                    "Container dibuka melalui rute resmi."
                }
                if (!useAccessibility) Toast.makeText(this, "Container dijalankan", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                if (useAccessibility) {
                    AincradAccessibilityService.cancel(this, "Gagal membuka container: ${e.message ?: "kesalahan tidak diketahui"}")
                }
                apkStatus.text = "Gagal membuka container: ${e.message ?: "kesalahan tidak diketahui"}"
                AlertDialog.Builder(this, R.style.RyooDialog)
                    .setTitle("Gagal menjalankan")
                    .setMessage(apkStatus.text)
                    .setPositiveButton(R.string.ok, null).showGlass()
            }
            return
        }

        // Tanpa container, aplikasi tujuan yang terpasang dapat dibuka langsung.
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(target)
                ?: throw android.content.ActivityNotFoundException("Aplikasi tujuan tidak memiliki launcher Activity.")
            startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            apkStatus.text = "Aplikasi tujuan berhasil dibuka."
        } catch (e: Exception) {
            apkStatus.text = "Gagal membuka aplikasi tujuan: ${e.message ?: "kesalahan tidak diketahui"}"
            AlertDialog.Builder(this, R.style.RyooDialog)
                .setTitle("Gagal menjalankan")
                .setMessage(apkStatus.text)
                .setPositiveButton(R.string.ok, null).showGlass()
        }
    }

    private fun createContainerRouteIntent(hostPackage: String, route: String): Intent {
        val intent = if (route.startsWith("intent:", ignoreCase = true)) {
            Intent.parseUri(route, Intent.URI_INTENT_SCHEME)
        } else {
            Intent(Intent.ACTION_VIEW, Uri.parse(route))
        }
        val explicitPackage = intent.`package`
        val componentPackage = intent.component?.packageName
        if (intent.selector != null ||
            (explicitPackage != null && explicitPackage != hostPackage) ||
            (componentPackage != null && componentPackage != hostPackage)) {
            throw SecurityException("Rute hanya boleh diarahkan ke aplikasi container yang dipilih.")
        }
        intent.setPackage(hostPackage)
        if (intent.resolveActivity(packageManager) == null) {
            throw android.content.ActivityNotFoundException("Container tidak menyediakan handler untuk deep link tersebut.")
        }
        return intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    // ===== Foto profil =====
    private fun showAvatarMenu() {
        val items = mutableListOf("🖼  Pilih dari galeri")
        if (avatarFile.exists()) items += "🗑  Hapus foto"
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle("Foto profil")
            .setItems(items.toTypedArray()) { _, which ->
                if (which == 0) {
                    try { pickAvatar.launch("image/*") }
                    catch (_: Exception) { toastFile("Tidak ada aplikasi galeri.") }
                } else {
                    avatarFile.delete(); applyAvatar(); toastFile("Foto dihapus")
                }
            }.showGlass()
    }

    // Baca gambar pilihan, putar sesuai EXIF, potong persegi di tengah, kecilkan ke 512px, simpan
    private fun saveAvatar(uri: Uri) {
        thread {
            val ok = try {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val raw = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw Exception("gambar tidak terbaca")
                val orientation = try {
                    contentResolver.openInputStream(uri)?.use {
                        ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                    } ?: ExifInterface.ORIENTATION_NORMAL
                } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
                val m = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                }
                val side = minOf(raw.width, raw.height)
                val square = Bitmap.createBitmap(raw, (raw.width - side) / 2, (raw.height - side) / 2, side, side, m, true)
                val out = Bitmap.createScaledBitmap(square, 512, 512, true)
                val tmp = File(filesDir, "avatar.tmp")
                tmp.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
                if (avatarFile.exists()) avatarFile.delete()
                tmp.renameTo(avatarFile)
            } catch (_: Throwable) { false }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (ok) { applyAvatar(); toastFile("Foto profil diganti") }
                else toastFile("Gagal memakai gambar ini")
            }
        }
    }

    // Terapkan foto ke avatar Profile dan logo Home (tanpa foto: ikon user bawaan)
    private fun applyAvatar() {
        val bmp: Bitmap? = if (avatarFile.exists())
            try { BitmapFactory.decodeFile(avatarFile.absolutePath) } catch (_: Throwable) { null }
        else null
        styleAvatar(findViewById(R.id.imgAvatar), bmp, 44)
        styleAvatar(findViewById(R.id.imgLogo), bmp, 40)
    }

    private fun styleAvatar(iv: ImageView, bmp: Bitmap?, defaultDp: Int) {
        val lp = iv.layoutParams as FrameLayout.LayoutParams
        if (bmp != null) {
            val m = dp(3)
            lp.width = ViewGroup.LayoutParams.MATCH_PARENT; lp.height = ViewGroup.LayoutParams.MATCH_PARENT
            lp.setMargins(m, m, m, m)
            iv.layoutParams = lp
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
            }
            iv.clipToOutline = true
            iv.setImageBitmap(bmp)
        } else {
            lp.width = dp(defaultDp); lp.height = dp(defaultDp)
            lp.setMargins(0, 0, 0, 0)
            iv.layoutParams = lp
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.clipToOutline = false
            iv.outlineProvider = ViewOutlineProvider.BACKGROUND
            iv.setImageResource(R.drawable.ic_user)
        }
    }

    // Tutup/reset pencarian. rerender = true -> muat ulang daftar file biasa
    private fun resetSearch(rerender: Boolean) {
        searchQuery = ""
        searchInput?.let {
            it.setText("")
            (getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager)
                .hideSoftInputFromWindow(it.windowToken, 0)
        }
        searchBar?.visibility = View.GONE
        if (rerender) renderCurrentFileTab()
    }

    // Cari rekursif (maks. 8 tingkat, 300 hasil) di folder Internal
    private fun searchInternalFiles(dir: File, q: String): List<File> {
        val found = ArrayList<File>()
        try {
            dir.walkTopDown().maxDepth(8)
                .onEnter { found.size < 300 && it.canRead() }
                .forEach { f ->
                    if (found.size < 300 && f != dir && f.name.contains(q, ignoreCase = true)) found.add(f)
                }
        } catch (_: Exception) { }
        return found.take(300).sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
    }

    // Cari rekursif lewat root (find); /proc dan /sys dilewati
    private fun searchRootFiles(path: String, q: String): List<File> {
        return try {
            val pat = shq("*" + q.replace("\\", "\\\\").replace("*", "\\*").replace("?", "\\?").replace("[", "\\[") + "*")
            val base = "find ${shq(path)} -maxdepth 8 \\( -path /proc -o -path /sys \\) -prune -o -iname $pat"
            val script = "$base -type d -print 2>/dev/null | head -n 100 | sed 's/\$/\\//'; " +
                "$base ! -type d -print 2>/dev/null | head -n 200"
            val proc = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
            val output = proc.inputStream.bufferedReader().readLines()
            proc.waitFor()
            val dirs = mutableSetOf<String>()
            val list = output.filter { it.isNotBlank() }.map { line ->
                val isDir = line.endsWith("/")
                val full = line.removeSuffix("/")
                if (isDir) dirs.add(full)
                File(full)
            }
            rootDirectories = dirs
            list
        } catch (_: Exception) { emptyList() }
    }

    private fun updateFileTabStyles(tabs: LinearLayout, accent: Int) {
        for (i in 0 until tabs.childCount) {
            val v = tabs.getChildAt(i) as TextView
            val selected = i == fileTab
            v.setTextColor(if (selected) Color.WHITE else 0xFFCCBBDD.toInt())
            v.background = if (selected) android.graphics.drawable.GradientDrawable().apply {
                setColor(accent); cornerRadius = dp(14).toFloat()
            } else null
        }
    }

    private fun renderFileTab(host: LinearLayout, accent: Int) {
        host.removeAllViews()
        if (zipOrig != null) { renderToken++; renderZip(host, accent); return }   // renderToken++: buang hasil daftar file yang masih dimuat
        val q = searchQuery
        val searching = q.isNotEmpty()
        val pathLabel = TextView(this).apply {
            textSize = 12f; setTextColor(0xFFD8C5EA.toInt()); setPadding(dp(4), dp(4), dp(4), dp(10))
            val where = when (fileTab) {
                FILE_INTERNAL -> internalPath.absolutePath
                FILE_ROOT -> rootPath
                else -> "File yang dibuka selama sesi ini"
            }
            text = if (searching) "🔍 \"$q\" di $where" else where
        }
        host.addView(pathLabel)
        if (fileTab == FILE_INTERNAL && !hasAllFilesAccess()) {
            val info = TextView(this).apply {
                text = "Izinkan RyooXIT mengelola semua file agar dapat menjelajahi penyimpanan bersama."
                textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(16), dp(18), dp(16), dp(18))
                background = fileCardBackground()
            }
            host.addView(info)
            host.addView(fileActionButton("BERI IZIN PENYIMPANAN", accent) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            })
            return
        }
        if (!searching) {
            if (fileTab == FILE_ROOT) {
                host.addView(fileActionButton("📂  Buka /data/local/tmp", accent) { rootPath = TMP_DIR; renderCurrentFileTab() })
            }
            clip?.let { c -> if (fileTab != FILE_RECENT) host.addView(pasteBar(c, accent)) }
            if (fileTab != FILE_RECENT) {
                host.addView(fileActionButton("⬆  Naik satu folder", accent) { navigateFileUp() })
            }
        }

        val token = ++renderToken
        val tabNow = fileTab

        fun populate(files: List<File>) {
            if (searching && files.isEmpty()) {
                host.addView(TextView(this).apply {
                    text = "Tidak ada hasil untuk \"$q\"."
                    setTextColor(Color.LTGRAY); textSize = 14f; setPadding(dp(12), dp(24), dp(12), dp(24))
                })
            } else if (tabNow == FILE_RECENT && files.isEmpty()) {
                host.addView(TextView(this).apply {
                    text = "Belum ada file dibuka. File yang kamu buka akan muncul di sini."
                    setTextColor(Color.LTGRAY); textSize = 14f; setPadding(dp(12), dp(24), dp(12), dp(24))
                })
            }
            files.forEach { file ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(12), dp(12), dp(12)); background = fileCardBackground()
                    isClickable = true; isFocusable = true
                }
                val icon = TextView(this).apply {
                    text = if (fileIsDirectory(file)) "📁" else fileIcon(file.name)
                    textSize = 23f; setPadding(0, 0, dp(12), 0)
                }
                row.addView(icon)
                val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                labels.addView(TextView(this).apply {
                    text = file.name.ifBlank { file.absolutePath }; textSize = 14f
                    setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                })
                labels.addView(TextView(this).apply {
                    val info = if (fileIsDirectory(file)) "Folder" else readableSize(file.length())
                    text = if (searching) "$info  •  ${file.parent ?: ""}" else info
                    textSize = 11f; setTextColor(0xFFCCBBDD.toInt())
                })
                row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                row.setOnClickListener { openFileEntry(file) }
                row.setOnLongClickListener { showFileActions(file); true }
                host.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
            if (files.isEmpty() && tabNow != FILE_RECENT && !searching) {
                host.addView(TextView(this).apply {
                    text = "Folder kosong atau tidak dapat dibaca."
                    setTextColor(Color.LTGRAY); setPadding(dp(12), dp(24), dp(12), dp(24))
                })
            }
        }

        if (tabNow == FILE_RECENT) {
            populate(recentFiles.map { File(it) }.filter { it.exists() && (!searching || it.name.contains(q, ignoreCase = true)) }
                .sortedByDescending { it.lastModified() })
            return
        }

        // Internal & Root: baca daftar di thread latar supaya layar tidak membeku
        val loading = TextView(this).apply {
            text = if (searching) "Mencari…" else "Memuat…"
            setTextColor(Color.LTGRAY); textSize = 14f; setPadding(dp(12), dp(24), dp(12), dp(24))
        }
        host.addView(loading)
        val dirNow = internalPath
        val rootNow = rootPath
        thread {
            val files: List<File> = try {
                if (searching) {
                    if (tabNow == FILE_INTERNAL) searchInternalFiles(dirNow, q) else searchRootFiles(rootNow, q)
                } else if (tabNow == FILE_INTERNAL) {
                    val sorted = dirNow.listFiles()
                        ?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
                    sorted ?: emptyList()
                } else {
                    listRootFiles(rootNow)
                }
            } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (isFinishing || isDestroyed || token != renderToken) return@runOnUiThread
                host.removeView(loading)
                populate(files)
            }
        }
    }

    private fun fileCardBackground() = android.graphics.drawable.GradientDrawable().apply {
        setColor(0x66200A35); cornerRadius = dp(15).toFloat()
        setStroke(dp(1), 0x887F42B8.toInt())
    }

    private fun fileActionButton(label: String, accent: Int, action: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 13f
        setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(dp(12), dp(14), dp(12), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(accent); cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) }
    }

    private fun hasAllFilesAccess(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun listRootFiles(path: String): List<File> {
        return try {
            val quoted = "'" + path.replace("'", "'\\''") + "'"
            val proc = ProcessBuilder("su", "-c", "ls -1Ap $quoted").redirectErrorStream(true).start()
            val output = proc.inputStream.bufferedReader().readLines()
            if (proc.waitFor() != 0) return emptyList()
            val dirs = mutableSetOf<String>()
            val list = output.filter { it.isNotBlank() }.map { name ->
                val isDir = name.endsWith("/")
                val clean = name.removeSuffix("/")
                val full = if (path == "/") "/$clean" else "${path.trimEnd('/')}/$clean"
                if (isDir) dirs.add(full)
                File(full)
            }
            rootDirectories = dirs
            list
        } catch (_: Exception) { emptyList() }
    }

    private fun openFileEntry(file: File) {
        if (fileIsDirectory(file)) {
            if (fileTab == FILE_INTERNAL) internalPath = file else rootPath = file.absolutePath
            resetSearch(false)
            renderCurrentFileTab(); return
        }
        recentFiles.add(file.absolutePath)
        val ext = file.extension.lowercase()
        when {
            ext == "sh" -> AlertDialog.Builder(this, R.style.RyooDialog).setTitle(file.name)
                .setMessage("Jalankan script ini melalui akses root?")
                .setNegativeButton("Batal", null).setPositiveButton("Jalankan") { _, _ -> runFileScript(file) }.showGlass()
            ext == "zip" -> openZipBrowser(file)
            ext in TEXT_EXT -> showTextFile(file, fileTab == FILE_ROOT)
            fileTab == FILE_ROOT -> toastFile("File: ${file.absolutePath}")
            else -> openWithApp(file)
        }
    }

    // Buka file dengan aplikasi lain. Tipe file ditentukan dari ekstensi (bukan "*/*"),
    // supaya Android menawarkan aplikasi yang cocok; APK langsung ke pemasang paket.
    private fun openWithApp(file: File) {
        try {
            val ext = file.extension.lowercase()
            val mime = if (ext == "apk") APK_MIME
                else android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            if (mime == APK_MIME && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                !packageManager.canRequestPackageInstalls()) {
                AlertDialog.Builder(this, R.style.RyooDialog)
                    .setTitle("Izin diperlukan")
                    .setMessage("Izinkan RyooXIT memasang aplikasi, lalu kembali dan ketuk file APK lagi.")
                    .setPositiveButton("Buka pengaturan") { _, _ ->
                        startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                            Uri.parse("package:$packageName")))
                    }
                    .setNegativeButton("Batal", null).showGlass()
                return
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val view = Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(if (mime == APK_MIME) view else Intent.createChooser(view, file.name))
        } catch (e: Exception) { toastFile("Tidak ada aplikasi untuk membuka file ini.") }
    }

    // Baca file teks di thread latar, dibatasi ukurannya (file besar tidak membuat app macet / kehabisan memori)
    private fun showTextFile(file: File, viaRoot: Boolean) {
        thread {
            var err: String? = null
            val text: String? = try {
                if (viaRoot) rootReadText(file.absolutePath)
                else file.inputStream().use { readCapped(it, TEXT_CAP) }
            } catch (e: Exception) { err = e.message; null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (text == null) toastFile("Tidak dapat membaca file: $err")
                else {
                    val note = if (text.toByteArray().size >= TEXT_CAP - 8)
                        "\n\n[… isi dipotong pada ${TEXT_CAP / 1000} KB]" else ""
                    showTextDialog(file.name, text, "Tutup", note)
                }
            }
        }
    }

    // Baca stream sampai habis tapi hanya simpan `cap` byte pertama
    private fun readCapped(ins: java.io.InputStream, cap: Int): String {
        val bo = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            val room = cap - bo.size()
            if (room > 0) bo.write(buf, 0, minOf(n, room))
        }
        return bo.toString("UTF-8")
    }

    private fun fileIsDirectory(file: File): Boolean {
        if (fileTab != FILE_ROOT) return file.isDirectory
        return rootDirectories.contains(file.absolutePath)
    }

    private fun rootReadText(path: String): String {
        val q = "'" + path.replace("'", "'\\''") + "'"
        val p = ProcessBuilder("su", "-c", "head -c $TEXT_CAP $q").redirectErrorStream(true).start()
        val result = readCapped(p.inputStream, TEXT_CAP); p.waitFor(); return result
    }

    private fun runFileScript(file: File) {
        thread {
            val q = "'" + file.absolutePath.replace("'", "'\\''") + "'"
            val out = try {
                val p = ProcessBuilder("su", "-c", "sh $q").redirectErrorStream(true).start()
                val text = readCapped(p.inputStream, OUT_CAP).takeLast(20000); val code = p.waitFor()
                (text.ifBlank { "Script selesai tanpa output." }) + "\n\nExit code: $code"
            } catch (e: Exception) { "Gagal menjalankan script: ${e.message}" }
            runOnUiThread { showTextDialog("Output ${file.name}", out, "OK") }
        }
    }

    // ===== Menu tekan-tahan: salin, pindah, hapus, kompres, bagikan, kirim ke /data/local/tmp =====
    private fun showFileActions(file: File) {
        val isDir = fileIsDirectory(file)
        val isZip = !isDir && file.extension.equals("zip", true)
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "📂  Buka" to { openFileEntry(file) }
        items += "📋  Salin" to { setClip(file, isDir, false) }
        items += "✂️  Pindahkan" to { setClip(file, isDir, true) }
        items += "🗑  Hapus" to { confirmDeleteFile(file, isDir) }
        items += "🗜  Kompres (.zip)" to { compressFile(file, isDir) }
        if (isZip) {
            items += "📦  Ekstrak di sini" to { extractZipAction(file, null, false) }
            items += "📦  Ekstrak ke $TMP_DIR" to { extractZipAction(file, null, true) }
        }
        if (!isDir) items += "📤  Bagikan" to { shareFile(file) }
        if (isZip) items += "↗  Buka dengan aplikasi lain" to { openWithApp(file) }
        items += "⚡  Salin ke $TMP_DIR" to { sendToTmp(file, false) }
        items += "⚡  Pindahkan ke $TMP_DIR" to { sendToTmp(file, true) }
        items += "🔗  Salin lokasi" to {
            copyText("Path", file.absolutePath); toastFile("Lokasi disalin")
        }
        if (!isDir) items += "⚙️  Jalankan sebagai script" to { runFileScript(file) }
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(file.name)
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .showGlass()
    }

    private fun shq(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun rootRun(script: String): Pair<Int, String> = try {
        val p = ProcessBuilder("su", "-c", script).redirectErrorStream(true).start()
        val out = readCapped(p.inputStream, TEXT_CAP)
        p.waitFor() to out
    } catch (e: Exception) { -1 to (e.message ?: "su tidak tersedia") }

    private fun copyText(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText(label, text))
    }

    private fun toastLong(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // Dialog teks (isi file / output perintah) dengan tombol Salin; teksnya juga bisa diblok manual
    private fun showTextDialog(title: String, text: String, closeLabel: String, note: String = "") {
        val d = AlertDialog.Builder(this, R.style.RyooDialog).setTitle(title).setMessage(text + note)
            .setPositiveButton(closeLabel, null)
            .setNeutralButton(R.string.copy, null)
            .create()
        d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        d.show()
        // Tombol Salin tidak menutup dialog
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            copyText(title, text)
            toastFile(getString(R.string.copied) + " (${text.length})")
        }
        try { d.findViewById<TextView>(android.R.id.message)?.setTextIsSelectable(true) } catch (_: Exception) { }
    }

    private fun isUnderStorage(path: String) =
        path.startsWith(Environment.getExternalStorageDirectory().absolutePath)

    // Jalankan operasi file di thread latar dengan dialog "mohon tunggu"
    private fun runFileOp(title: String, onOk: () -> Unit = {}, op: () -> Pair<Boolean, String>) {
        val pd = AlertDialog.Builder(this, R.style.RyooDialog).setTitle(title)
            .setMessage("Mohon tunggu…").setCancelable(false).create()
        pd.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        pd.show()
        thread {
            val res = try { op() } catch (e: Exception) { false to "Gagal: ${e.message}" }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                try { pd.dismiss() } catch (_: Exception) { }
                if (res.first) onOk()
                if (res.second.isNotBlank()) toastLong(res.second)
                renderCurrentFileTab()
            }
        }
    }

    private fun uniqueFile(dir: File, name: String, isDir: Boolean): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val base = if (isDir) name else name.substringBeforeLast('.', name)
        val ext = if (isDir || !name.contains('.')) "" else "." + name.substringAfterLast('.')
        var n = 1
        while (t.exists()) { t = File(dir, "${base}_$n$ext"); n++ }
        return t
    }

    private fun copyAny(src: File, dst: File, isDir: Boolean) {
        if (isDir) src.copyRecursively(dst, overwrite = false) else src.copyTo(dst)
    }

    // Skrip root: salin/pindah ke folder tujuan; kalau nama sudah ada, ditambah _1, _2, ...
    private fun rootTransferScript(src: String, dstDir: String, move: Boolean): String {
        val op = if (move) "mv" else "cp -r"
        return "s=${shq(src)}; d=${shq(dstDir)}; n=\$(basename \"\$s\"); t=\"\$d/\$n\"; i=1; " +
            "while [ -e \"\$t\" ]; do t=\"\$d/\${n}_\$i\"; i=\$((i+1)); done; " +
            "$op \"\$s\" \"\$t\" && echo \"\$t\""
    }

    private fun setClip(file: File, isDir: Boolean, cut: Boolean) {
        clip = ClipItem(file.absolutePath, isDir, cut, fileTab == FILE_ROOT || !isUnderStorage(file.absolutePath))
        renderCurrentFileTab()
        toastFile(if (cut) "Dipilih untuk dipindah. Buka folder tujuan lalu ketuk TEMPEL."
                  else "Disalin. Buka folder tujuan lalu ketuk TEMPEL.")
    }

    private fun pasteBar(c: ClipItem, accent: Int): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(6), dp(8)); background = fileCardBackground()
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(4) }
        }
        bar.addView(TextView(this).apply {
            text = "📋  ${if (c.cut) "Pindahkan" else "Salin"}: ${File(c.path).name}"
            textSize = 12f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(TextView(this).apply {
            text = "TEMPEL"; textSize = 12f; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(dp(14), dp(9), dp(14), dp(9))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(accent); cornerRadius = dp(12).toFloat()
            }
            setOnClickListener { pasteClip() }
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        bar.addView(TextView(this).apply {
            text = "✕"; textSize = 18f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { clip = null; renderCurrentFileTab() }
        })
        return bar
    }

    private fun pasteClip() {
        val c = clip ?: return
        val dest = when (fileTab) {
            FILE_INTERNAL -> internalPath.absolutePath
            FILE_ROOT -> rootPath
            else -> return
        }
        val src = File(c.path)
        if (c.isDir && (dest == c.path || dest.startsWith(c.path.trimEnd('/') + "/"))) {
            toastFile("Folder tidak bisa dimasukkan ke dalam dirinya sendiri"); return
        }
        if (c.cut && src.parent == dest) { toastFile("File sudah ada di folder ini"); return }
        val useRoot = c.viaRoot || fileTab == FILE_ROOT
        runFileOp(if (c.cut) "Memindahkan…" else "Menyalin…", onOk = { if (c.cut) clip = null }) {
            if (useRoot) {
                val (code, out) = rootRun(rootTransferScript(c.path, dest, c.cut))
                if (code == 0) (true to "Berhasil: ${out.trim()}")
                else (false to "Gagal: ${out.trim().ifBlank { "butuh akses root" }}")
            } else {
                val t = uniqueFile(File(dest), src.name, c.isDir)
                if (c.cut) {
                    if (!src.renameTo(t)) { copyAny(src, t, c.isDir); src.deleteRecursively() }
                } else copyAny(src, t, c.isDir)
                (true to "Berhasil: ${t.name}")
            }
        }
    }

    // Kirim langsung ke /data/local/tmp (butuh root)
    private fun sendToTmp(file: File, move: Boolean) {
        runFileOp(if (move) "Memindahkan ke $TMP_DIR…" else "Menyalin ke $TMP_DIR…") {
            val (code, out) = rootRun(rootTransferScript(file.absolutePath, TMP_DIR, move))
            if (code == 0) (true to "Berhasil: ${out.trim()}")
            else (false to "Gagal (butuh akses root): ${out.trim()}")
        }
    }

    private fun confirmDeleteFile(file: File, isDir: Boolean) {
        val path = file.absolutePath
        if (path in PROTECTED_PATHS || file.parent == "/") {
            toastFile("Folder sistem ini tidak boleh dihapus dari sini"); return
        }
        AlertDialog.Builder(this, R.style.RyooDialog)
            .setTitle("Hapus ${if (isDir) "folder" else "file"}?")
            .setMessage(path + (if (isDir) "\n\nIsi folder ikut terhapus dan tidak bisa dikembalikan."
                                else "\n\nTidak bisa dikembalikan."))
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                val viaRoot = fileTab == FILE_ROOT || !isUnderStorage(path)
                runFileOp("Menghapus…", onOk = {
                    recentFiles.remove(path); if (clip?.path == path) clip = null
                }) {
                    if (viaRoot) {
                        val (code, out) = rootRun("rm -rf ${shq(path)}")
                        if (code == 0) (true to "Terhapus") else (false to "Gagal: ${out.trim()}")
                    } else {
                        val ok = if (isDir) file.deleteRecursively() else file.delete()
                        if (ok) (true to "Terhapus") else (false to "Gagal menghapus (cek izin)")
                    }
                }
            }.showGlass()
    }

    // Kompres ke .zip di folder yang sama
    private fun compressFile(file: File, isDir: Boolean) {
        val parent = file.parentFile ?: run { toastFile("Tidak bisa dikompres"); return }
        val outName = (if (isDir) file.name else file.nameWithoutExtension.ifBlank { file.name }) + ".zip"
        runFileOp("Mengompres…") {
            val t = uniqueFile(parent, outName, false)
            try { zipTo(file, t); (true to "Berhasil: ${t.name}") }
            catch (e: Exception) { t.delete(); (false to "Gagal mengompres: ${e.message}") }
        }
    }

    private fun zipTo(src: File, out: File) {
        val base = src.parentFile ?: src
        java.util.zip.ZipOutputStream(java.io.BufferedOutputStream(java.io.FileOutputStream(out))).use { zos ->
            fun add(f: File) {
                val name = f.relativeTo(base).path.replace(File.separatorChar, '/') + (if (f.isDirectory) "/" else "")
                zos.putNextEntry(java.util.zip.ZipEntry(name))
                if (f.isFile) f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
                if (f.isDirectory) f.listFiles()?.forEach { add(it) }
            }
            add(src)
        }
    }

    private fun shareFile(file: File) {
        if (fileIsDirectory(file)) { toastFile("Folder tidak bisa dibagikan langsung. Kompres dulu."); return }
        try {
            val ext = file.extension.lowercase()
            val mime = if (ext == "apk") APK_MIME
                else android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).setType(mime)
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(send, file.name))
        } catch (e: Exception) { toastFile("Tidak bisa membagikan file ini") }
    }

    // ===== Jelajah & ekstrak zip =====
    private fun closeZipBrowser() {
        if (zipIsCopy) zipSrc?.delete()
        zipSrc = null; zipOrig = null; zipInner = ""; zipIndex = emptyList(); zipIsCopy = false
        try { File(cacheDir, "zipopen").deleteRecursively() } catch (_: Exception) { }
    }

    // File zip yang bisa dibaca app. Kalau tidak bisa (mis. di /data/local/tmp), disalin dulu lewat root ke cache.
    private fun readableCopy(f: File): Pair<File, Boolean>? {
        if (f.canRead()) return f to false
        val tmp = File(cacheDir, "zipview_${System.currentTimeMillis()}.zip")
        val (code, _) = rootRun("cp ${shq(f.absolutePath)} ${shq(tmp.absolutePath)} && chmod 666 ${shq(tmp.absolutePath)}")
        return if (code == 0 && tmp.exists()) tmp to true else null
    }

    private fun openZipBrowser(file: File) {
        runFileOp("Membuka zip…") {
            val rc = readableCopy(file) ?: return@runFileOp (false to "Zip tidak bisa dibaca (butuh akses root?)")
            try {
                val list = mutableListOf<ZipItem>()
                java.util.zip.ZipFile(rc.first).use { zf ->
                    val en = zf.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        list.add(ZipItem(e.name, e.isDirectory, e.size))
                    }
                }
                closeZipBrowser()
                zipSrc = rc.first; zipIsCopy = rc.second; zipOrig = file; zipInner = ""; zipIndex = list
                (true to "")
            } catch (e: Exception) {
                if (rc.second) rc.first.delete()
                (false to "Zip tidak bisa dibuka: ${e.message}")
            }
        }
    }

    // Isi satu "folder" di dalam zip (folder yang tidak punya entri sendiri tetap dikenali)
    private fun zipChildren(prefix: String): List<ZipItem> {
        val map = LinkedHashMap<String, ZipItem>()
        for (z in zipIndex) {
            if (z.name == prefix || !z.name.startsWith(prefix)) continue
            val rest = z.name.substring(prefix.length)
            val slash = rest.indexOf('/')
            if (slash < 0) map[rest] = ZipItem(rest, false, z.size)
            else {
                val d = rest.substring(0, slash)
                if (d.isNotEmpty() && map[d]?.isDir != true) map[d] = ZipItem(d, true, 0L)
            }
        }
        return map.values.sortedWith(compareBy<ZipItem>({ !it.isDir }, { it.name.lowercase(Locale.ROOT) }))
    }

    private fun renderZip(host: LinearLayout, accent: Int) {
        val z = zipOrig ?: return
        host.addView(TextView(this).apply {
            textSize = 12f; setTextColor(0xFFD8C5EA.toInt()); setPadding(dp(4), dp(4), dp(4), dp(10))
            text = "📦 ${z.name}/$zipInner"
        })
        host.addView(fileActionButton(if (zipInner.isEmpty()) "✕  Tutup zip" else "⬆  Naik satu folder", accent) { navigateFileUp() })
        host.addView(fileActionButton("📦  Ekstrak semua di sini", accent) { extractZipAction(z, null, false) })
        val items = zipChildren(zipInner)
        if (items.isEmpty()) {
            host.addView(TextView(this).apply {
                text = "Folder ini kosong."
                setTextColor(Color.LTGRAY); setPadding(dp(12), dp(24), dp(12), dp(24))
            })
        }
        items.take(1000).forEach { e ->
            host.addView(zipRow(e), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        if (items.size > 1000) {
            host.addView(TextView(this).apply {
                text = "… ${items.size - 1000} item lainnya tidak ditampilkan"
                setTextColor(Color.LTGRAY); textSize = 12f; setPadding(dp(12), dp(8), dp(12), dp(8))
            })
        }
    }

    private fun zipRow(z: ZipItem): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12)); background = fileCardBackground()
            isClickable = true; isFocusable = true
        }
        row.addView(TextView(this).apply {
            text = if (z.isDir) "📁" else fileIcon(z.name)
            textSize = 23f; setPadding(0, 0, dp(12), 0)
        })
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(TextView(this).apply {
            text = z.name; textSize = 14f
            setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })
        labels.addView(TextView(this).apply {
            text = if (z.isDir) "Folder" else readableSize(z.size.coerceAtLeast(0))
            textSize = 11f; setTextColor(0xFFCCBBDD.toInt())
        })
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        row.setOnClickListener { onZipEntry(z) }
        row.setOnLongClickListener { showZipEntryActions(z); true }
        return row
    }

    private fun onZipEntry(z: ZipItem) {
        val full = zipInner + z.name + (if (z.isDir) "/" else "")
        if (z.isDir) { zipInner = full; renderCurrentFileTab(); return }
        val ext = z.name.substringAfterLast('.', "").lowercase()
        if (ext in TEXT_EXT || ext == "sh") viewZipText(full) else openZipEntry(full)
    }

    private fun showZipEntryActions(z: ZipItem) {
        val orig = zipOrig ?: return
        val full = zipInner + z.name + (if (z.isDir) "/" else "")
        val items = listOf<Pair<String, () -> Unit>>(
            "📂  Buka" to { onZipEntry(z) },
            "📦  Ekstrak ini di sini" to { extractZipAction(orig, full, false) },
            "⚡  Ekstrak ini ke $TMP_DIR" to { extractZipAction(orig, full, true) }
        )
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(z.name)
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .showGlass()
    }

    // Lihat isi file teks langsung dari dalam zip
    private fun viewZipText(entry: String) {
        val src = zipSrc ?: return
        thread {
            var err: String? = null
            val text: String? = try {
                java.util.zip.ZipFile(src).use { zf ->
                    val e = zf.getEntry(entry) ?: throw java.io.IOException("entri tidak ditemukan")
                    zf.getInputStream(e).use { readCapped(it, TEXT_CAP) }
                }
            } catch (e: Exception) { err = e.message; null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (text == null) toastFile("Tidak dapat membaca: $err")
                else {
                    val note = if (text.toByteArray().size >= TEXT_CAP - 8)
                        "\n\n[… isi dipotong pada ${TEXT_CAP / 1000} KB]" else ""
                    showTextDialog(File(entry).name, text, "Tutup", note)
                }
            }
        }
    }

    // File non-teks di dalam zip: ekstrak sementara ke cache lalu buka dengan aplikasi yang cocok
    private fun openZipEntry(entry: String) {
        val src = zipSrc ?: return
        thread {
            var err: String? = null
            val out: File? = try {
                val dir = File(cacheDir, "zipopen").apply { mkdirs() }
                val f = File(dir, File(entry).name)
                java.util.zip.ZipFile(src).use { zf ->
                    val e = zf.getEntry(entry) ?: throw java.io.IOException("entri tidak ditemukan")
                    zf.getInputStream(e).use { ins -> java.io.FileOutputStream(f).use { ins.copyTo(it) } }
                }
                f
            } catch (e: Exception) { err = e.message; null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (out == null) toastFile("Gagal membuka: $err") else openWithApp(out)
            }
        }
    }

    // Ekstrak seluruh zip (prefix == null) atau satu entri/folder di dalamnya.
    // Tujuan: folder bernama sama dengan zip di samping zip, atau ke /data/local/tmp (lewat root).
    private fun extractZipAction(zip: File, prefix: String?, toTmp: Boolean) {
        runFileOp("Mengekstrak…") {
            val browsing = zipOrig?.absolutePath == zip.absolutePath
            val browsed = zipSrc
            val rc: Pair<File, Boolean> = (if (browsing && browsed != null) (browsed to false) else readableCopy(zip))
                ?: return@runFileOp (false to "Zip tidak bisa dibaca (butuh akses root?)")
            try {
                val base = zip.nameWithoutExtension.ifBlank { zip.name }
                val parent = zip.parentFile ?: File("/")
                val viaRoot = toTmp || !isUnderStorage(zip.absolutePath)
                if (!viaRoot) {
                    val dest = uniqueFile(parent, base, true)
                    val n = extractZip(rc.first, dest, prefix)
                    (true to "Selesai: $n item → ${dest.name}")
                } else {
                    // Ekstrak ke cache dulu, lalu root menyalinnya ke tujuan (app tidak bisa menulis ke sana langsung)
                    val stage = File(cacheDir, "ex_${System.currentTimeMillis()}")
                    val n = extractZip(rc.first, stage, prefix)
                    val dstDir = if (toTmp) TMP_DIR else parent.absolutePath
                    val script = "d=${shq(dstDir)}; n=${shq(base)}; t=\"\$d/\$n\"; i=1; " +
                        "while [ -e \"\$t\" ]; do t=\"\$d/\${n}_\$i\"; i=\$((i+1)); done; " +
                        "cp -r ${shq(stage.absolutePath)} \"\$t\" && echo \"\$t\""
                    val (code, out) = rootRun(script)
                    stage.deleteRecursively()
                    if (code == 0) (true to "Selesai: $n item → ${out.trim()}")
                    else (false to "Gagal: ${out.trim().ifBlank { "butuh akses root" }}")
                }
            } finally {
                if (rc.second) rc.first.delete()
            }
        }
    }

    // Ekstrak ke folder dest. Aman dari path berbahaya di dalam zip ("../"). Mengembalikan jumlah item.
    private fun extractZip(zipPath: File, dest: File, prefix: String?): Int {
        var count = 0
        dest.mkdirs()
        val destCanon = dest.canonicalPath
        // Kalau yang dipilih satu entri/folder: simpan dengan nama foldernya, tanpa induk di atasnya
        val baseDir = prefix?.trimEnd('/')?.substringBeforeLast('/', "")
            ?.let { if (it.isEmpty()) "" else "$it/" } ?: ""
        java.util.zip.ZipFile(zipPath).use { zf ->
            val en = zf.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (prefix != null && !(e.name == prefix || (prefix.endsWith("/") && e.name.startsWith(prefix)))) continue
                val rel = e.name.removePrefix(baseDir)
                if (rel.isEmpty()) continue
                val target = File(dest, rel)
                val canon = target.canonicalPath
                if (canon != destCanon && !canon.startsWith(destCanon + File.separator)) continue
                if (e.isDirectory) target.mkdirs()
                else {
                    target.parentFile?.mkdirs()
                    zf.getInputStream(e).use { ins -> java.io.FileOutputStream(target).use { ins.copyTo(it) } }
                }
                count++
            }
        }
        return count
    }

    private fun navigateFileUp(): Boolean {
        if (zipOrig != null) {
            if (zipInner.isNotEmpty()) {
                val up = zipInner.trimEnd('/').substringBeforeLast('/', "")
                zipInner = if (up.isEmpty()) "" else "$up/"
            } else closeZipBrowser()
            renderCurrentFileTab(); return true
        }
        if (searchQuery.isNotEmpty()) resetSearch(false)
        when (fileTab) {
            FILE_INTERNAL -> {
                val storageRoot = Environment.getExternalStorageDirectory().absoluteFile
                if (internalPath.absoluteFile == storageRoot) return false
                val parent = internalPath.parentFile ?: return false
                if (!parent.absolutePath.startsWith(storageRoot.absolutePath)) return false
                internalPath = parent
            }
            FILE_ROOT -> { if (rootPath == "/") return false; rootPath = File(rootPath).parent ?: "/" }
            else -> return false
        }
        renderCurrentFileTab(); return true
    }

    private fun renderCurrentFileTab() {
        val pair = pageFile.tag as? Pair<*, *> ?: return
        val tabs = pair.first as? LinearLayout ?: return
        val host = pair.second as? LinearLayout ?: return
        updateFileTabStyles(tabs, if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255))
        renderFileTab(host, if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255))
    }

    private fun fileIcon(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "sh" -> "⚙️"; "so" -> "🧩"; "apk" -> "📦"; "jpg", "jpeg", "png", "webp" -> "🖼️"
        "zip", "7z", "rar" -> "🗜️"; "txt", "log", "conf", "prop" -> "📄"; else -> "📃"
    }

    private fun readableSize(size: Long): String = when {
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> "%.1f KB".format(size / 1024.0)
        else -> "%.1f MB".format(size / (1024.0 * 1024.0))
    }

    private fun toastFile(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun setNavItem(itemId: Int, labelId: Int, selected: Boolean) {
        findViewById<View>(labelId).visibility = if (selected) View.VISIBLE else View.GONE
        findViewById<View>(itemId).setBackgroundResource(if (selected) R.drawable.bg_nav_sel else 0)
    }

    // ===== Tema: Biru (bawaan) / Ungu =====
    private fun isPurple(): Boolean = prefs.getString("theme", "blue") == "purple"

    // Ganti tema: ambil "foto" tampilan lama, buat ulang activity dengan tema baru,
    // lalu foto lama memudar sehingga terasa seperti transisi halus.
    private fun switchTheme(key: String) {
        val content = findViewById<View>(android.R.id.content)
        pendingSnapshot = try {
            Bitmap.createBitmap(content.width, content.height, Bitmap.Config.ARGB_8888)
                .also { content.draw(Canvas(it)) }
        } catch (e: Exception) { null }
        prefs.edit().putString("theme", key).apply()
        recreate()
    }

    private fun playThemeSwitchAnim() {
        val snap = pendingSnapshot ?: return
        pendingSnapshot = null
        val host = findViewById<ViewGroup>(android.R.id.content)
        val root = host.getChildAt(0)
        val overlay = ImageView(this).apply { setImageBitmap(snap); isClickable = true }
        host.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.alpha = 0.55f; root.scaleX = 0.97f; root.scaleY = 0.97f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f)).start()
        overlay.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .withEndAction { host.removeView(overlay) }.start()
    }

    private fun openLink(url: String, errRes: Int) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: Exception) { Toast.makeText(this, errRes, Toast.LENGTH_SHORT).show() }
    }

    // ===== Data perangkat (dibaca langsung dari sistem HP) =====
    private val ticker = object : Runnable {
        override fun run() {
            updateSession()
            if (tick % 2 == 0) updateStats()
            if (tick % 4 == 0) updateNet()
            tick++
            handler.postDelayed(this, 1000)
        }
    }

    private fun startTicker() {
        handler.removeCallbacks(ticker)
        tick = 0
        handler.post(ticker)
    }

    private fun stopTicker() { handler.removeCallbacks(ticker) }

    private fun fillStaticInfo() {
        findViewById<TextView>(R.id.txtDeviceId).text = deviceId()
        findViewById<TextView>(R.id.txtDeviceIdHome).text = deviceId()
        val man = Build.MANUFACTURER.orEmpty()
        val model = Build.MODEL.orEmpty()
        val name = if (model.startsWith(man, ignoreCase = true)) model
                   else man.replaceFirstChar { it.uppercase() } + " " + model
        findViewById<TextView>(R.id.txtModel).text = name.trim()
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "-"
        findViewById<TextView>(R.id.txtOs).text = "Android ${Build.VERSION.RELEASE}  •  $abi"
        val ver = appVersion()
        findViewById<TextView>(R.id.txtVersion).text = "V$ver"
        findViewById<TextView>(R.id.txtVersionHome).text = "v$ver"
        findViewById<TextView>(R.id.txtInfoSub).text = "RyooXIT v$ver"
        applyRootUi()
    }

    private fun appVersion(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.3" } catch (e: Exception) { "1.0.3" }

    private fun updateLastRun() {
        val t = prefs.getLong("lastRun", 0L)
        findViewById<TextView>(R.id.txtLastRun).text =
            if (t == 0L) getString(R.string.last_run_never)
            else getString(R.string.last_run,
                java.text.SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(java.util.Date(t)))
    }

    // ID unik perangkat (8 digit) diturunkan dari ANDROID_ID
    private fun deviceId(): String {
        val raw = try { Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) }
                  catch (e: Exception) { null } ?: Build.FINGERPRINT
        val d = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        var n = 0L
        for (i in 0 until 4) n = (n shl 8) or (d[i].toLong() and 0xFF)
        return "%08d".format(n % 100_000_000L)
    }

    private fun updateSession() {
        val s = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        findViewById<TextView>(R.id.txtSession).text =
            "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }

    private fun updateStats() {
        // RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramPct = if (mi.totalMem > 0) (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt() else 0
        findViewById<TextView>(R.id.txtRam).text = ramPct.toString()
        setVerticalBar(ramPct)

        // Storage (partisi data)
        val st = try { StatFs(Environment.getDataDirectory().path) } catch (e: Exception) { null }
        val stPct = if (st != null && st.totalBytes > 0)
            (((st.totalBytes - st.availableBytes) * 100) / st.totalBytes).toInt() else 0
        findViewById<TextView>(R.id.txtStorage).text = stPct.toString()
        findViewById<ProgressBar>(R.id.progStorage).progress = stPct

        // CPU: frekuensi saat ini (kHz) dari sysfs. Kalau diblokir sistem, tampilkan jumlah core.
        val cores = Runtime.getRuntime().availableProcessors()
        var cur = 0L; var max = 0L
        for (i in 0 until cores) {
            cur = maxOf(cur, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq"))
            max = maxOf(max, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq"))
        }
        val tvCpu = findViewById<TextView>(R.id.txtCpu)
        val tvUnit = findViewById<TextView>(R.id.txtCpuUnit)
        val pbCpu = findViewById<ProgressBar>(R.id.progCpu)
        if (cur > 0) {
            tvCpu.text = String.format(Locale.US, "%.2f", cur / 1_000_000.0)
            tvUnit.text = "GHz"
            pbCpu.progress = if (max > 0) ((cur * 100) / max).toInt().coerceIn(0, 100) else 0
        } else {
            tvCpu.text = cores.toString()
            tvUnit.setText(R.string.cpu_core_unit)
            pbCpu.progress = 0
        }

        // Skor performa: berdasarkan RAM & storage yang masih lega
        val score = (0.6 * (100 - ramPct) + 0.4 * (100 - stPct)).roundToInt().coerceIn(0, 100)
        findViewById<TextView>(R.id.txtScore).text = "$score / 100"
        findViewById<ProgressBar>(R.id.progScore).progress = score
    }

    private fun readLong(path: String): Long =
        try { File(path).readText().trim().toLong() } catch (e: Exception) { 0L }

    private fun setVerticalBar(pct: Int) {
        val p = pct.coerceIn(0, 100)
        val empty = findViewById<View>(R.id.barEmpty)
        val fill = findViewById<View>(R.id.barFill)
        (empty.layoutParams as LinearLayout.LayoutParams).weight = (100 - p).toFloat()
        (fill.layoutParams as LinearLayout.LayoutParams).weight = p.toFloat()
        findViewById<View>(R.id.barTrack).requestLayout()
    }

    private fun updateNet() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        val type = when {
            caps == null -> getString(R.string.net_none)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getString(R.string.net_mobile)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> getString(R.string.net_other)
        }
        findViewById<TextView>(R.id.txtNetInfo).text = if (caps == null) type else "$type  •  $PING_HOST"
        val tvPing = findViewById<TextView>(R.id.txtPing)
        if (caps == null) { tvPing.text = "—"; return }
        if (pinging) return
        pinging = true
        thread {
            // Latensi = waktu sambung TCP ke host DNS publik
            val ms = try {
                val t0 = SystemClock.elapsedRealtime()
                Socket().use { it.connect(InetSocketAddress(PING_HOST, 443), 2000) }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (e: Exception) { -1 }
            runOnUiThread {
                pinging = false
                tvPing.text = if (ms >= 0) ms.toString() else "—"
            }
        }
    }

    // ===== Pengaturan: hanya Tema & Bahasa =====
    private fun showSettings() {
        val d = Dialog(this, R.style.RyooSheet)
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        d.setContentView(v)
        v.findViewById<TextView>(R.id.valTheme).text = optionLabel(THEME_KEYS, if (isPurple()) "purple" else "blue")
        v.findViewById<TextView>(R.id.valLang).text = optionLabel(LANG_KEYS, prefs.getString("lang", "system"))
        // Mode root & kirim key lewat file: tersimpan langsung saat diubah
        bindSwitch(v, R.id.rowRoot, R.id.swRoot, "root", true)
        bindSwitch(v, R.id.rowKeyFile, R.id.swKeyFile, "keyToFile", false)
        bindSwitch(v, R.id.rowAutoUpdate, R.id.swAutoUpdate, "autoUpdate", true)
        v.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { d.dismiss() }
        v.findViewById<View>(R.id.rowTheme).setOnClickListener { d.dismiss(); chooseTheme() }
        v.findViewById<View>(R.id.rowLang).setOnClickListener { d.dismiss(); chooseLang() }
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun bindSwitch(v: View, rowId: Int, swId: Int, key: String, def: Boolean) {
        val sw = v.findViewById<androidx.appcompat.widget.SwitchCompat>(swId)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { b, on ->
            prefs.edit().putBoolean(key, on).apply()
            b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        v.findViewById<View>(rowId).setOnClickListener { sw.toggle() }
    }

    private fun optionLabel(keys: Array<String>, key: String?): String {
        val labels = when {
            keys === THEME_KEYS -> arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
            else -> arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        }
        return labels[keys.indexOf(key).coerceAtLeast(0)]
    }

    private fun chooseTheme() {
        val labels = arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
        val cur = if (isPurple()) 1 else 0
        var sel = cur
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.appearance)
            .setSingleChoiceItems(labels, cur) { _, which -> sel = which }
            .setPositiveButton(R.string.ok) { _, _ -> if (sel != cur) switchTheme(THEME_KEYS[sel]) }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    private fun chooseLang() {
        val labels = arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        val cur = LANG_KEYS.indexOf(prefs.getString("lang", "system")).coerceAtLeast(0)
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.language)
            .setSingleChoiceItems(labels, cur) { dlg, which ->
                prefs.edit().putString("lang", LANG_KEYS[which]).apply()
                dlg.dismiss()
                RyooApp.applyLang(LANG_KEYS[which])     // activity dibuat ulang otomatis
            }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    // ===== Pilihan command (dengan nama) =====
    private fun customCmds(): MutableList<SavedCmd> {
        val out = mutableListOf<SavedCmd>()
        try {
            val arr = org.json.JSONArray(prefs.getString("customCmds", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.get(i)
                if (o is org.json.JSONObject) out.add(SavedCmd(o.optString("n"), o.optString("c")))
                else out.add(SavedCmd("", o.toString()))        // format lama: hanya teks command
            }
        } catch (_: Exception) { }
        return out
    }

    private fun saveCustomCmds(list: List<SavedCmd>) {
        val arr = org.json.JSONArray()
        list.forEach { arr.put(org.json.JSONObject().put("n", it.name).put("c", it.cmd)) }
        prefs.edit().putString("customCmds", arr.toString()).apply()
    }

    private fun presetCmds(): List<SavedCmd> = PRESET_CMDS.map { SavedCmd(PRESET_NAMES[it] ?: "", it) }

    // Nama dari command yang sedang terisi di kotak (kalau cocok dengan yang tersimpan)
    private fun commandName(cmd: String): String? =
        (presetCmds() + customCmds()).firstOrNull { it.cmd == cmd && it.name.isNotBlank() }?.name

    private fun refreshCmdTitle() {
        txtCmdTitle.text = commandName(cmdBox.text.toString().trim()) ?: getString(R.string.cmd_card_title)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun themeColor(attr: Int): Int {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun showCommandPicker() {
        val dlg = Dialog(this, R.style.RyooDialog)
        val pad = dp(20)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, dp(12)) }

        // Judul
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            setText(R.string.cmd_pick_title); textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(12) })

        fun pick(cmd: String) { cmdBox.setText(cmd); dlg.dismiss() }

        // Tambah / ubah command: nama (opsional) + isi command
        fun showEdit(existing: SavedCmd?, rebuild: () -> Unit) {
            fun field(h: String, mono: Boolean) = EditText(this).apply {
                hint = h
                setHintTextColor(themeColor(R.attr.t_text_hint) and 0x00FFFFFF or 0x66000000)
                setTextColor(themeColor(R.attr.t_text_primary))
                textSize = 13f
                if (mono) typeface = android.graphics.Typeface.MONOSPACE
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    (if (mono) android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                        android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS else 0)
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            val nameIn = field(getString(R.string.cmd_name_hint), false).apply { setText(existing?.name ?: "") }
            val cmdIn = field(getString(R.string.cmd_add_hint), true).apply { setText(existing?.cmd ?: "") }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad, dp(8), pad, 0)
                addView(nameIn)
                addView(cmdIn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
            }
            AlertDialog.Builder(this, R.style.RyooDialog)
                .setTitle(if (existing == null) R.string.cmd_add_title else R.string.cmd_edit_title).setView(box)
                .setPositiveButton(R.string.cmd_save) { _, _ ->
                    val n = nameIn.text.toString().trim()
                    val c = cmdIn.text.toString().trim()
                    if (c.isNotEmpty()) {
                        val l = customCmds()
                        val idx = if (existing != null) l.indexOf(existing) else l.indexOfFirst { it.cmd == c }
                        if (idx >= 0) l[idx] = SavedCmd(n, c)
                        else if (c !in PRESET_CMDS) l.add(SavedCmd(n, c))
                        saveCustomCmds(l)
                        refreshCmdTitle()
                        rebuild()
                    }
                }
                .setNegativeButton(R.string.cancel, null).showGlass()
        }

        fun confirmDelete(item: SavedCmd, rebuild: () -> Unit) {
            AlertDialog.Builder(this, R.style.RyooDialog)
                .setTitle(R.string.cmd_delete_title)
                .setMessage(if (item.name.isNotBlank()) item.name + "\n" + item.cmd else item.cmd)
                .setPositiveButton(R.string.cmd_delete) { _, _ ->
                    val l = customCmds(); l.remove(item); saveCustomCmds(l)
                    refreshCmdTitle(); rebuild()
                }
                .setNegativeButton(R.string.cancel, null).showGlass()
        }

        fun addRow(item: SavedCmd, custom: Boolean, rebuild: () -> Unit) {
            val named = item.name.isNotBlank()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                if (named) addView(TextView(this@MainActivity).apply {
                    text = item.name; textSize = 15f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(themeColor(R.attr.t_text_primary))
                })
                addView(TextView(this@MainActivity).apply {
                    text = item.cmd; textSize = if (named) 11f else 13f
                    typeface = android.graphics.Typeface.MONOSPACE
                    setTextColor(themeColor(if (named) R.attr.t_text_hint else R.attr.t_text_primary))
                    maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
                })
                setOnClickListener { pick(item.cmd) }
                if (custom) setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity, R.style.RyooDialog)
                        .setTitle(if (named) item.name else item.cmd)
                        .setItems(arrayOf(getString(R.string.cmd_edit), getString(R.string.cmd_delete))) { _, which ->
                            if (which == 0) showEdit(item, rebuild) else confirmDelete(item, rebuild)
                        }.showGlass()
                    true
                }
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(8) })
        }

        lateinit var rebuild: () -> Unit
        rebuild = {
            list.removeAllViews()
            presetCmds().forEach { addRow(it, false, rebuild) }
            customCmds().forEach { addRow(it, true, rebuild) }
            val add = TextView(this).apply {
                setText(R.string.cmd_write); textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(themeColor(R.attr.t_on_accent))
                setBackgroundResource(R.drawable.bg_btn_primary)
                setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_add, 0, 0, 0)
                compoundDrawablePadding = dp(8)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { showEdit(null, rebuild) }
            }
            list.addView(add, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(4) })
        }
        rebuild()

        root.addView(TextView(this).apply {
            setText(R.string.cmd_hold_hint); textSize = 11f
            setTextColor(themeColor(R.attr.t_text_hint))
        })

        dlg.setContentView(root)
        dlg.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dlg.show()
    }

    private fun AlertDialog.Builder.showGlass() {
        val d = create()
        d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        d.show()
    }

    private fun showInfo() {
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle("RyooXIT v${appVersion()}")
            .setMessage(R.string.info_msg)
            .setNeutralButton(R.string.check_update) { _, _ -> updater.check(true) }
            .setPositiveButton(R.string.ok, null).showGlass()
    }

    // ===== Cek tanda tangan APK =====
    // Ganti EXPECTED_SHA256 dengan hash sertifikat keystore kamu sendiri.
    // Cara dapat hash: keytool -list -v -keystore nama.jks -alias alias_kamu
    private fun isSignatureValid(): Boolean {
        // APK debug hanya untuk pengujian lokal/virtual; jangan gunakan untuk distribusi.
        // Build release tetap wajib memakai sertifikat resmi yang cocok dengan EXPECTED_SHA256.
        if (BuildConfig.DEBUG) return true
        return try {
            val sigHash = getSigningSha256() ?: return false
            sigHash.equals(EXPECTED_SHA256, ignoreCase = true)
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    private fun getSigningSha256(): String? {
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = packageManager.getPackageInfo(
                packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signingInfo = info.signingInfo ?: return null
            if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
            else signingInfo.signingCertificateHistory
        } else {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            info.signatures ?: return null
        }
        if (sigs.isEmpty()) return null
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(sigs[0].toByteArray())
        return digest.joinToString(":") { b -> "%02X".format(b) }
    }

    // ===== Background terenkripsi (XOR) dari assets/bg_blue.dat & bg_purple.dat (satu foto per tema) =====
    private fun loadBackground() {
        val iv = findViewById<ImageView>(R.id.imgBg)
        val file = if (isPurple()) "bg_purple.dat" else "bg_blue.dat"
        thread {
            try {
                val raw = assets.open(file).readBytes()
                val out = ByteArray(raw.size)
                for (i in raw.indices) out[i] = (raw[i].toInt() xor BG_KEY).toByte()
                val bmp = BitmapFactory.decodeByteArray(out, 0, out.size)
                runOnUiThread { iv.setImageBitmap(bmp) }
            } catch (e: Exception) { /* biarkan background polos kalau gagal */ }
        }
    }

    // Splash: logo + nama dua warna, lalu fade-out (dilewati saat activity dibuat ulang karena ganti tema/bahasa)
    private fun setupSplash(show: Boolean) {
        val splash = findViewById<View>(R.id.splash)
        if (!show) { splash.visibility = View.GONE; return }
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(600)
                .withEndAction { splash.visibility = View.GONE }.start()
        }, 1200)
    }

    // Logo berdenyut, XIT bercahaya, tombol mengecil saat ditekan
    @SuppressLint("ClickableViewAccessibility")
    private fun setupAnimations(btnRun: Button) {
        ObjectAnimator.ofPropertyValuesHolder(
            findViewById<View>(R.id.imgLogo),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f)
        ).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        ObjectAnimator.ofFloat(findViewById<View>(R.id.txtXit), View.ALPHA, 1f, 0.55f).apply {
            duration = 1100; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        btnRun.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    // Deteksi root ringan (tidak memunculkan popup izin)
    private fun checkRoot() {
        thread {
            val found = try {
                listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                    "/vendor/bin/su", "/product/bin/su").any { File(it).exists() } ||
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "command -v su"))
                        .inputStream.bufferedReader().readText().isNotBlank()
            } catch (e: Exception) { false }
            runOnUiThread { rootFound = found; rootChecked = true; applyRootUi() }
        }
    }

    private fun applyRootUi() {
        val tv = findViewById<TextView>(R.id.rootStatus)
        val badge = findViewById<TextView>(R.id.txtRootBadge)
        val sub = findViewById<TextView>(R.id.txtAccessSub)
        if (!rootChecked) {
            tv.setText(R.string.root_checking)
            badge.setText(R.string.root_checking)
            return
        }
        if (rootFound) {
            tv.setText(R.string.root_found)
            tv.setTextColor(Color.parseColor("#3DFF8F"))
            badge.setText(R.string.root_active)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#3DDC84"))
            badge.setTextColor(Color.parseColor("#06301A"))
            sub.setText(R.string.access_sub_root)
        } else {
            tv.setText(R.string.root_not_found)
            tv.setTextColor(Color.parseColor("#FF5A5A"))
            badge.setText(R.string.root_inactive)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FF8A80"))
            badge.setTextColor(Color.parseColor("#4A0A0A"))
            sub.setText(R.string.access_sub_noroot)
        }
    }

    companion object {
        private const val PAGE_HOME = 0
        private const val PAGE_FILE = 1
        private const val PAGE_PROFILE = 2
        private const val PAGE_APK = 3
        private const val PREF_APK_HOST = "apkHostPackage"
        private const val PREF_APK_TARGET = "apkTargetPackage"
        private const val PREF_APK_INTERNAL_NAME = "apkInternalName"
        private const val PREF_APK_ROUTE = "apkHostRoute"
        private const val FILE_INTERNAL = 0
        private const val FILE_ROOT = 1
        private const val FILE_RECENT = 2
        private const val PING_HOST = "1.1.1.1"
        private const val TEXT_CAP = 48_000          // batas byte saat membaca file teks
        private const val OUT_CAP = 200_000          // batas byte output perintah yang ditampung
        private val TEXT_EXT = setOf("txt", "log", "conf", "cfg", "ini", "prop", "properties", "json", "xml", "md", "csv", "yml", "yaml")
        private const val APK_MIME = "application/vnd.android.package-archive"
        private const val TMP_DIR = "/data/local/tmp"
        // Folder sistem yang tidak boleh dihapus lewat File Manager
        private val PROTECTED_PATHS = setOf("/", "/data", "/data/local", "/data/local/tmp", "/system", "/vendor",
            "/product", "/cache", "/proc", "/sys", "/dev", "/sdcard", "/storage", "/storage/emulated", "/storage/emulated/0")
        private val sessionStart = SystemClock.elapsedRealtime()

        // GANTI dengan link channel WhatsApp kamu
        const val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb8eX0Z1NCrYCXEXuu0K"
        // GANTI dengan nomor WhatsApp admin (format internasional tanpa + / 0 di depan, contoh 6281234567890)
        const val WA_ADMIN_URL = "https://wa.me/6285861526715"
        const val TIKTOK_URL = "https://www.tiktok.com/@ryoofren?_r=1&_t=ZS-9BE8WQ79dxu"
        private val THEME_KEYS = arrayOf("blue", "purple")
        private var pendingSnapshot: Bitmap? = null
        private val LANG_KEYS = arrayOf("system", "id", "en")
        const val DEFAULT_CMD = "echo \"RYOOXIT V2.3\"; echo \"Script tersimpan di: assets/ryooxit_v23/RYOOXIT_V2.3.sh\"; echo \"Ukuran script: 10.4 MB\"; echo \"Preset ini menampilkan lokasi file; tidak menjalankan overlay.\""
        val PRESET_CMDS = listOf(DEFAULT_CMD)
        // Satu preset bawaan; command buatan pengguna tetap dapat ditambahkan.
        val PRESET_NAMES = mapOf(DEFAULT_CMD to "RYOOXIT V2.3")

        // Kunci XOR untuk background terenkripsi (harus sama dengan yang dipakai saat enkripsi).
        const val BG_KEY = 0x5A

        // Hash SHA-256 sertifikat RELEASE resmi kamu.
        // Dapatkan dengan: keytool -list -v -keystore ryooxit.jks -alias ryooxit
        const val EXPECTED_SHA256 =
            "26:A5:E8:E3:4F:9A:AA:5C:EF:4C:A8:F8:FA:9A:EB:5F:36:85:66:33:0C:83:2E:82:E6:B4:DA:31:E1:4C:0C:06"
    }
}
