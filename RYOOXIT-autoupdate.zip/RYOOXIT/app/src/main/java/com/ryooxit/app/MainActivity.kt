package com.ryooxit.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.Signature
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.storage.StorageManager
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.content.FileProvider
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("ryooxit", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val updater by lazy { Updater(this) }

    private lateinit var cmdBox: EditText
    private lateinit var keyBox: EditText
    private lateinit var pageHome: View
    private lateinit var pageProfile: View
    private lateinit var pageFile: FrameLayout

    private var page = PAGE_HOME
    private var rootFound = false
    private var rootChecked = false
    private var tick = 0
    private var pinging = false
    private var fileTab = FILE_INTERNAL
    private var internalPath: File = Environment.getExternalStorageDirectory()
    private var rootPath: String = "/"
    private val recentFiles = linkedSetOf<String>()
    @Volatile private var rootDirectories: Set<String> = emptySet()
    private var renderToken = 0

    // ===== Siklus hidup =====
    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Tema (Biru / Ungu) dipilih dari pengaturan; bawaan Biru
        setTheme(if (isPurple()) R.style.Theme_Ryooxit_Purple else R.style.Theme_Ryooxit)
        super.onCreate(savedInstanceState)

        if (!isSignatureValid()) {
            // APK sudah diubah / ditandatangani ulang oleh orang lain: hentikan app.
            AlertDialog.Builder(this)
                .setTitle(R.string.verify_fail_title)
                .setMessage(R.string.verify_fail_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.close) { _, _ -> finishAffinity(); exitProcess(0) }
                .show()
            return
        }

        setContentView(R.layout.activity_main)
        page = savedInstanceState?.getInt("page", PAGE_HOME) ?: PAGE_HOME

        // Kedua tema gelap: ikon status bar & navigation bar berwarna terang
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        pageHome = findViewById(R.id.pageHome)
        pageProfile = findViewById(R.id.pageProfile)
        pageFile = findViewById(R.id.pageFile)
        buildFileExplorer()
        loadBackground()

        cmdBox = findViewById(R.id.cmdBox)
        keyBox = findViewById(R.id.keyBox)
        val btnRun = findViewById<Button>(R.id.btnRun)
        cmdBox.setText(prefs.getString("cmd", DEFAULT_CMD))
        updateLastRun()
        keyBox.setText(prefs.getString("key", ""))

        setupSplash(savedInstanceState == null)
        // Update otomatis: cek sekali tiap app dibuka (bukan saat activity dibuat ulang karena ganti tema/bahasa)
        if (savedInstanceState == null && prefs.getBoolean("autoUpdate", true)) {
            window.decorView.postDelayed({ if (!isFinishing) updater.check(false) }, 2500)
        }
        setupAnimations(btnRun)
        checkRoot()
        fillStaticInfo()

        // Navigasi bawah
        findViewById<View>(R.id.navHome).setOnClickListener { showPage(PAGE_HOME, true) }
        findViewById<View>(R.id.navFile).setOnClickListener { showPage(PAGE_FILE, true) }
        findViewById<View>(R.id.navProfile).setOnClickListener { showPage(PAGE_PROFILE, true) }
        showPage(page)
        playThemeSwitchAnim()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when (page) {
                    PAGE_FILE -> { if (!navigateFileUp()) showPage(PAGE_HOME, true) }
                    PAGE_PROFILE -> showPage(PAGE_HOME, true)
                    else -> { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })

        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnInfo).setOnClickListener { showInfo() }
        findViewById<View>(R.id.btnProfileTop).setOnClickListener { showPage(PAGE_PROFILE, true) }
        findViewById<View>(R.id.btnCmdGo).setOnClickListener { showCommandPicker() }
        findViewById<LinearLayout>(R.id.btnChannel).setOnClickListener {
            openLink(WA_CHANNEL_URL, R.string.link_fail)
        }
        findViewById<LinearLayout>(R.id.btnAdmin).setOnClickListener {
            openLink(WA_ADMIN_URL, R.string.wa_fail)
        }

        findViewById<LinearLayout>(R.id.btnTiktok).setOnClickListener {
            openLink(TIKTOK_URL, R.string.link_fail)
        }

        btnRun.setOnClickListener {
            val cmd = cmdBox.text.toString().trim()
            if (cmd.isEmpty()) return@setOnClickListener
            val root = prefs.getBoolean("root", true)
            val key = keyBox.text.toString().trim()
            prefs.edit().putString("key", key).putString("cmd", cmd).apply()
            btnRun.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            btnRun.isEnabled = false
            btnRun.setText(R.string.running)
            val writeKeyFile = prefs.getBoolean("keyToFile", false)
            thread {
                val out = try {
                    // Opsional: tulis key ke /data/local/tmp/key.txt dulu, sebelum script dijalankan.
                    // Script bisa membacanya sendiri, misalnya: KEY=$(cat /data/local/tmp/key.txt)
                    if (writeKeyFile && key.isNotEmpty() && root) {
                        val wp = ProcessBuilder("su", "-c", "umask 077; cat > /data/local/tmp/key.txt")
                            .redirectErrorStream(true).start()
                        wp.outputStream.bufferedWriter().use { w -> w.write(key) }
                        wp.waitFor()
                    }
                    // Jalankan perintah melalui shell yang konsisten dan tampilkan exit code.
                    // Hindari "su -c su -c ..." jika prefix su -c sudah ditulis pengguna.
                    val cleanCmd = cmd.trim().replace(Regex("^su\\s+-c\\s+"), "")
                        .let { value ->
                            if (value.startsWith('"') && value.endsWith('"') && value.length >= 2)
                                value.substring(1, value.length - 1) else value
                        }
                    val args = if (root) arrayOf("su", "-c", cleanCmd)
                               else arrayOf("sh", "-c", cleanCmd)
                    val p = ProcessBuilder(*args).redirectErrorStream(true).start()

                    // Batas waktu: proses yang menggantung dihentikan supaya tombol Run tidak terkunci
                    val timedOut = java.util.concurrent.atomic.AtomicBoolean(false)
                    val watchdog = thread {
                        try { Thread.sleep(CMD_TIMEOUT_MS); timedOut.set(true); p.destroy() }
                        catch (_: InterruptedException) { }
                    }

                    // Kirim key bila diperlukan, lalu tutup stdin agar proses menerima EOF.
                    p.outputStream.bufferedWriter().use { w ->
                        if (key.isNotEmpty()) w.write(key + "\n")
                    }

                    val output = p.inputStream.use { readCapped(it, OUT_CAP) }
                    val exitCode = p.waitFor()
                    watchdog.interrupt()
                    // key.txt hanya perlu ada selama script berjalan: hapus setelah selesai
                    if (writeKeyFile && key.isNotEmpty() && root) {
                        try {
                            ProcessBuilder("su", "-c", "rm -f /data/local/tmp/key.txt")
                                .redirectErrorStream(true).start().waitFor()
                        } catch (_: Exception) { }
                    }
                    val timeoutNote = if (timedOut.get())
                        "\n\n[Dihentikan: melebihi ${CMD_TIMEOUT_MS / 1000} detik]" else ""
                    val diagnosis = when {
                        output.contains("cannot locate symbol", ignoreCase = true) ||
                            output.contains("CANNOT LINK EXECUTABLE", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Kegagalan linker: executable atau library-nya tidak cocok/tidak menyediakan simbol yang diminta. Runner tidak dapat memperbaiki ABI atau library yang salah secara otomatis."
                        output.contains("Permission denied", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Izin ditolak. Periksa izin file, konteks SELinux, dan hak akses proses."
                        output.contains("not found", ignoreCase = true) ->
                            "\n\n[DIAGNOSTIK] Perintah atau file yang dipanggil tidak ditemukan. Periksa PATH dan lokasi file."
                        else -> ""
                    }
                    (output.ifBlank { getString(R.string.done_no_output) }).takeLast(20000) +
                        "\n\nExit code: $exitCode" + diagnosis + timeoutNote
                } catch (ex: Exception) { "Error: ${ex.message}" }
                prefs.edit().putLong("lastRun", System.currentTimeMillis()).apply()
                runOnUiThread {
                    updateLastRun()
                    btnRun.isEnabled = true
                    btnRun.setText(R.string.run)
                    AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.output_title).setMessage(out)
                        .setPositiveButton(R.string.ok, null).showGlass()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", page)
    }

    override fun onResume() {
        super.onResume()
        if (::pageProfile.isInitialized && page == PAGE_PROFILE) startTicker()
        if (::pageFile.isInitialized && page == PAGE_FILE && fileTab == FILE_INTERNAL && hasAllFilesAccess())
            renderCurrentFileTab()
    }

    override fun onPause() {
        super.onPause()
        stopTicker()
    }

    // ===== Navigasi Home / Profile (dengan animasi geser + pudar) =====
    private fun showPage(p: Int, animate: Boolean = false) {
        val prev = page
        page = p
        val pages = listOf(pageHome, pageFile, pageProfile)
        val inV = pages[p.coerceIn(PAGE_HOME, PAGE_PROFILE)]
        val outV = pages[prev.coerceIn(PAGE_HOME, PAGE_PROFILE)]
        inV.animate().cancel(); outV.animate().cancel()

        if (animate && prev != p) {
            // Bar bawah: label membuka/menutup dengan mulus
            val nav = findViewById<View>(R.id.navHome).parent as ViewGroup
            android.transition.TransitionManager.beginDelayedTransition(
                nav, android.transition.AutoTransition().setDuration(260))
        }
        setNavItem(R.id.navHome, R.id.navHomeLabel, p == PAGE_HOME)
        setNavItem(R.id.navFile, R.id.navFileLabel, p == PAGE_FILE)
        setNavItem(R.id.navProfile, R.id.navProfileLabel, p == PAGE_PROFILE)
        if (p == PAGE_PROFILE) startTicker() else stopTicker()

        if (!animate || prev == p) {
            inV.visibility = View.VISIBLE; inV.alpha = 1f; inV.translationX = 0f
            outV.visibility = View.GONE; outV.alpha = 1f; outV.translationX = 0f
            return
        }
        val dx = resources.displayMetrics.widthPixels * 0.14f
        val dir = if (p > prev) 1f else -1f
        outV.animate().alpha(0f).translationX(-dir * dx * 0.6f).setDuration(200)
            .withEndAction {
                if (page == p) { outV.visibility = View.GONE }
                outV.alpha = 1f; outV.translationX = 0f
            }.start()
        inV.alpha = 0f; inV.translationX = dir * dx; inV.visibility = View.VISIBLE
        inV.animate().alpha(1f).translationX(0f).setStartDelay(70).setDuration(340)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
        val staggerTarget = when (p) {
            PAGE_PROFILE -> (pageProfile as ViewGroup).getChildAt(0) as? ViewGroup
            PAGE_FILE -> pageFile.getChildAt(0) as? ViewGroup
            else -> ((pageHome as ViewGroup).getChildAt(0) as ViewGroup).getChildAt(0) as? ViewGroup
        }
        staggerTarget?.let { staggerIn(it) }
    }

    // Kartu-kartu muncul berurutan dari bawah
    private fun staggerIn(col: ViewGroup) {
        val rise = resources.displayMetrics.density * 26f
        for (i in 0 until col.childCount) {
            val ch = col.getChildAt(i)
            ch.animate().cancel()
            ch.alpha = 0f; ch.translationY = rise
            ch.animate().alpha(1f).translationY(0f)
                .setStartDelay(110L + i * 55L).setDuration(360)
                .setInterpolator(DecelerateInterpolator(1.5f)).start()
        }
    }

    // ===== FILE: tiga halaman (Internal, Root, Terbaru) =====
    private fun buildFileExplorer() {
        val accent = if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255)
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(38), dp(18), dp(110))
        }
        val title = TextView(this).apply {
            text = "File Manager"
            textSize = 30f; setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        }
        base.addView(title)
        val subtitle = TextView(this).apply {
            text = "Jelajahi penyimpanan dan file sistem"
            textSize = 13f; setTextColor(Color.LTGRAY)
            setPadding(0, dp(3), 0, dp(16))
        }
        base.addView(subtitle)
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0x55301050); cornerRadius = dp(18).toFloat()
                setStroke(dp(1), 0x887F42B8.toInt())
            }
        }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabLabels = listOf("Internal", "Root", "Terbaru")
        tabLabels.forEachIndexed { index, label ->
            val tab = TextView(this).apply {
                text = label; textSize = 14f; gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12)); setTextColor(Color.WHITE)
                setOnClickListener { fileTab = index; renderFileTab(content, accent); updateFileTabStyles(tabs, accent) }
            }
            tabs.addView(tab, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        base.addView(tabs)
        base.addView(content, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(14) })
        pageFile.addView(ScrollView(this).apply {
            isFillViewport = true; isVerticalScrollBarEnabled = false; addView(base)
        }, FrameLayout.LayoutParams(-1, -1))
        pageFile.tag = Pair(tabs, content)
        updateFileTabStyles(tabs, accent)
        renderFileTab(content, accent)
    }

    private fun updateFileTabStyles(tabs: LinearLayout, accent: Int) {
        for (i in 0 until tabs.childCount) {
            val v = tabs.getChildAt(i) as TextView
            val selected = i == fileTab
            v.setTextColor(if (selected) Color.WHITE else 0xFFCCBBDD.toInt())
            v.background = if (selected) android.graphics.drawable.GradientDrawable().apply {
                setColor(accent); cornerRadius = dp(14).toFloat()
            } else null
        }
    }

    private fun renderFileTab(host: LinearLayout, accent: Int) {
        host.removeAllViews()
        val pathLabel = TextView(this).apply {
            textSize = 12f; setTextColor(0xFFD8C5EA.toInt()); setPadding(dp(4), dp(4), dp(4), dp(10))
            text = when (fileTab) {
                FILE_INTERNAL -> internalPath.absolutePath
                FILE_ROOT -> rootPath
                else -> "File yang dibuka selama sesi ini"
            }
        }
        host.addView(pathLabel)
        if (fileTab == FILE_INTERNAL && !hasAllFilesAccess()) {
            val info = TextView(this).apply {
                text = "Izinkan RyooXIT mengelola semua file agar dapat menjelajahi penyimpanan bersama."
                textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(16), dp(18), dp(16), dp(18))
                background = fileCardBackground()
            }
            host.addView(info)
            host.addView(fileActionButton("BERI IZIN PENYIMPANAN", accent) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(intent)
                } catch (_: Exception) { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            })
            return
        }
        if (fileTab != FILE_RECENT) {
            host.addView(fileActionButton("⬆  Naik satu folder", accent) { navigateFileUp() })
        }

        val token = ++renderToken
        val tabNow = fileTab

        fun populate(files: List<File>) {
            if (tabNow == FILE_RECENT && files.isEmpty()) {
                host.addView(TextView(this).apply {
                    text = "Belum ada file dibuka. File yang kamu buka akan muncul di sini."
                    setTextColor(Color.LTGRAY); textSize = 14f; setPadding(dp(12), dp(24), dp(12), dp(24))
                })
            }
            files.forEach { file ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(12), dp(12), dp(12)); background = fileCardBackground()
                    isClickable = true; isFocusable = true
                }
                val icon = TextView(this).apply {
                    text = if (fileIsDirectory(file)) "📁" else fileIcon(file.name)
                    textSize = 23f; setPadding(0, 0, dp(12), 0)
                }
                row.addView(icon)
                val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                labels.addView(TextView(this).apply {
                    text = file.name.ifBlank { file.absolutePath }; textSize = 14f
                    setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
                    maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                })
                labels.addView(TextView(this).apply {
                    text = if (fileIsDirectory(file)) "Folder" else readableSize(file.length())
                    textSize = 11f; setTextColor(0xFFCCBBDD.toInt())
                })
                row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
                row.setOnClickListener { openFileEntry(file) }
                row.setOnLongClickListener { showFileActions(file); true }
                host.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
            if (files.isEmpty() && tabNow != FILE_RECENT) {
                host.addView(TextView(this).apply {
                    text = "Folder kosong atau tidak dapat dibaca."
                    setTextColor(Color.LTGRAY); setPadding(dp(12), dp(24), dp(12), dp(24))
                })
            }
        }

        if (tabNow == FILE_RECENT) {
            populate(recentFiles.map { File(it) }.filter { it.exists() }
                .sortedByDescending { it.lastModified() })
            return
        }

        // Internal & Root: baca daftar di thread latar supaya layar tidak membeku
        val loading = TextView(this).apply {
            text = "Memuat…"
            setTextColor(Color.LTGRAY); textSize = 14f; setPadding(dp(12), dp(24), dp(12), dp(24))
        }
        host.addView(loading)
        val dirNow = internalPath
        val rootNow = rootPath
        thread {
            val files: List<File> = try {
                if (tabNow == FILE_INTERNAL) {
                    val sorted = dirNow.listFiles()
                        ?.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase(Locale.ROOT) }))
                    sorted ?: emptyList()
                } else {
                    listRootFiles(rootNow)
                }
            } catch (e: Exception) { emptyList() }
            runOnUiThread {
                if (isFinishing || isDestroyed || token != renderToken) return@runOnUiThread
                host.removeView(loading)
                populate(files)
            }
        }
    }

    private fun fileCardBackground() = android.graphics.drawable.GradientDrawable().apply {
        setColor(0x66200A35); cornerRadius = dp(15).toFloat()
        setStroke(dp(1), 0x887F42B8.toInt())
    }

    private fun fileActionButton(label: String, accent: Int, action: () -> Unit) = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 13f
        setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(dp(12), dp(14), dp(12), dp(14))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(accent); cornerRadius = dp(14).toFloat()
        }
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) }
    }

    private fun hasAllFilesAccess(): Boolean = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    private fun listRootFiles(path: String): List<File> {
        return try {
            val quoted = "'" + path.replace("'", "'\\''") + "'"
            val proc = ProcessBuilder("su", "-c", "ls -1Ap $quoted").redirectErrorStream(true).start()
            val output = proc.inputStream.bufferedReader().readLines()
            if (proc.waitFor() != 0) return emptyList()
            val dirs = mutableSetOf<String>()
            val list = output.filter { it.isNotBlank() }.map { name ->
                val isDir = name.endsWith("/")
                val clean = name.removeSuffix("/")
                val full = if (path == "/") "/$clean" else "${path.trimEnd('/')}/$clean"
                if (isDir) dirs.add(full)
                File(full)
            }
            rootDirectories = dirs
            list
        } catch (_: Exception) { emptyList() }
    }

    private fun openFileEntry(file: File) {
        if (fileIsDirectory(file)) {
            if (fileTab == FILE_INTERNAL) internalPath = file else rootPath = file.absolutePath
            renderCurrentFileTab(); return
        }
        recentFiles.add(file.absolutePath)
        val ext = file.extension.lowercase()
        when {
            ext == "sh" -> AlertDialog.Builder(this, R.style.RyooDialog).setTitle(file.name)
                .setMessage("Jalankan script ini melalui akses root?")
                .setNegativeButton("Batal", null).setPositiveButton("Jalankan") { _, _ -> runFileScript(file) }.showGlass()
            ext in TEXT_EXT -> showTextFile(file, fileTab == FILE_ROOT)
            fileTab == FILE_ROOT -> toastFile("File: ${file.absolutePath}")
            else -> try {
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                startActivity(Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "*/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (e: Exception) { toastFile("Tidak ada aplikasi untuk membuka file ini.") }
        }
    }

    // Baca file teks di thread latar, dibatasi ukurannya (file besar tidak membuat app macet / kehabisan memori)
    private fun showTextFile(file: File, viaRoot: Boolean) {
        thread {
            var err: String? = null
            val text: String? = try {
                if (viaRoot) rootReadText(file.absolutePath)
                else file.inputStream().use { readCapped(it, TEXT_CAP) }
            } catch (e: Exception) { err = e.message; null }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (text == null) toastFile("Tidak dapat membaca file: $err")
                else AlertDialog.Builder(this, R.style.RyooDialog).setTitle(file.name)
                    .setMessage(text.take(12000)).setPositiveButton("Tutup", null).showGlass()
            }
        }
    }

    // Baca stream sampai habis tapi hanya simpan `cap` byte pertama
    private fun readCapped(ins: java.io.InputStream, cap: Int): String {
        val bo = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            val room = cap - bo.size()
            if (room > 0) bo.write(buf, 0, minOf(n, room))
        }
        return bo.toString("UTF-8")
    }

    private fun fileIsDirectory(file: File): Boolean {
        if (fileTab != FILE_ROOT) return file.isDirectory
        return rootDirectories.contains(file.absolutePath)
    }

    private fun rootReadText(path: String): String {
        val q = "'" + path.replace("'", "'\\''") + "'"
        val p = ProcessBuilder("su", "-c", "head -c $TEXT_CAP $q").redirectErrorStream(true).start()
        val result = readCapped(p.inputStream, TEXT_CAP); p.waitFor(); return result
    }

    private fun runFileScript(file: File) {
        thread {
            val q = "'" + file.absolutePath.replace("'", "'\\''") + "'"
            val out = try {
                val p = ProcessBuilder("su", "-c", "sh $q").redirectErrorStream(true).start()
                val text = readCapped(p.inputStream, OUT_CAP).takeLast(20000); val code = p.waitFor()
                (text.ifBlank { "Script selesai tanpa output." }) + "\n\nExit code: $code"
            } catch (e: Exception) { "Gagal menjalankan script: ${e.message}" }
            runOnUiThread { AlertDialog.Builder(this, R.style.RyooDialog).setTitle("Output ${file.name}")
                .setMessage(out).setPositiveButton("OK", null).showGlass() }
        }
    }

    private fun showFileActions(file: File) {
        val actions = if (fileIsDirectory(file)) arrayOf("Buka", "Salin lokasi") else arrayOf("Buka", "Salin lokasi", "Jalankan sebagai script")
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(file.name).setItems(actions) { _, which ->
            when (which) {
                0 -> openFileEntry(file)
                1 -> { val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("Path", file.absolutePath)); toastFile("Lokasi disalin") }
                2 -> runFileScript(file)
            }
        }.showGlass()
    }

    private fun navigateFileUp(): Boolean {
        when (fileTab) {
            FILE_INTERNAL -> {
                val storageRoot = Environment.getExternalStorageDirectory().absoluteFile
                if (internalPath.absoluteFile == storageRoot) return false
                val parent = internalPath.parentFile ?: return false
                if (!parent.absolutePath.startsWith(storageRoot.absolutePath)) return false
                internalPath = parent
            }
            FILE_ROOT -> { if (rootPath == "/") return false; rootPath = File(rootPath).parent ?: "/" }
            else -> return false
        }
        renderCurrentFileTab(); return true
    }

    private fun renderCurrentFileTab() {
        val pair = pageFile.tag as? Pair<*, *> ?: return
        val tabs = pair.first as? LinearLayout ?: return
        val host = pair.second as? LinearLayout ?: return
        updateFileTabStyles(tabs, if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255))
        renderFileTab(host, if (isPurple()) Color.rgb(177, 92, 255) else Color.rgb(77, 163, 255))
    }

    private fun fileIcon(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "sh" -> "⚙️"; "so" -> "🧩"; "apk" -> "📦"; "jpg", "jpeg", "png", "webp" -> "🖼️"
        "zip", "7z", "rar" -> "🗜️"; "txt", "log", "conf", "prop" -> "📄"; else -> "📃"
    }

    private fun readableSize(size: Long): String = when {
        size < 1024 -> "$size B"
        size < 1024 * 1024 -> "%.1f KB".format(size / 1024.0)
        else -> "%.1f MB".format(size / (1024.0 * 1024.0))
    }

    private fun toastFile(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun setNavItem(itemId: Int, labelId: Int, selected: Boolean) {
        findViewById<View>(labelId).visibility = if (selected) View.VISIBLE else View.GONE
        findViewById<View>(itemId).setBackgroundResource(if (selected) R.drawable.bg_nav_sel else 0)
    }

    // ===== Tema: Biru (bawaan) / Ungu =====
    private fun isPurple(): Boolean = prefs.getString("theme", "blue") == "purple"

    // Ganti tema: ambil "foto" tampilan lama, buat ulang activity dengan tema baru,
    // lalu foto lama memudar sehingga terasa seperti transisi halus.
    private fun switchTheme(key: String) {
        val content = findViewById<View>(android.R.id.content)
        pendingSnapshot = try {
            Bitmap.createBitmap(content.width, content.height, Bitmap.Config.ARGB_8888)
                .also { content.draw(Canvas(it)) }
        } catch (e: Exception) { null }
        prefs.edit().putString("theme", key).apply()
        recreate()
    }

    private fun playThemeSwitchAnim() {
        val snap = pendingSnapshot ?: return
        pendingSnapshot = null
        val host = findViewById<ViewGroup>(android.R.id.content)
        val root = host.getChildAt(0)
        val overlay = ImageView(this).apply { setImageBitmap(snap); isClickable = true }
        host.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.alpha = 0.55f; root.scaleX = 0.97f; root.scaleY = 0.97f
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f)).start()
        overlay.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(650)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .withEndAction { host.removeView(overlay) }.start()
    }

    private fun openLink(url: String, errRes: Int) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (e: Exception) { Toast.makeText(this, errRes, Toast.LENGTH_SHORT).show() }
    }

    // ===== Data perangkat (dibaca langsung dari sistem HP) =====
    private val ticker = object : Runnable {
        override fun run() {
            updateSession()
            if (tick % 2 == 0) updateStats()
            if (tick % 4 == 0) updateNet()
            tick++
            handler.postDelayed(this, 1000)
        }
    }

    private fun startTicker() {
        handler.removeCallbacks(ticker)
        tick = 0
        handler.post(ticker)
    }

    private fun stopTicker() { handler.removeCallbacks(ticker) }

    private fun fillStaticInfo() {
        findViewById<TextView>(R.id.txtDeviceId).text = deviceId()
        findViewById<TextView>(R.id.txtDeviceIdHome).text = deviceId()
        val man = Build.MANUFACTURER.orEmpty()
        val model = Build.MODEL.orEmpty()
        val name = if (model.startsWith(man, ignoreCase = true)) model
                   else man.replaceFirstChar { it.uppercase() } + " " + model
        findViewById<TextView>(R.id.txtModel).text = name.trim()
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "-"
        findViewById<TextView>(R.id.txtOs).text = "Android ${Build.VERSION.RELEASE}  •  $abi"
        val ver = appVersion()
        findViewById<TextView>(R.id.txtVersion).text = "V$ver"
        findViewById<TextView>(R.id.txtVersionHome).text = "v$ver"
        findViewById<TextView>(R.id.txtInfoSub).text = "RyooXIT v$ver"
        applyRootUi()
    }

    private fun appVersion(): String =
        try { packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.3" } catch (e: Exception) { "1.0.3" }

    private fun updateLastRun() {
        val t = prefs.getLong("lastRun", 0L)
        findViewById<TextView>(R.id.txtLastRun).text =
            if (t == 0L) getString(R.string.last_run_never)
            else getString(R.string.last_run,
                java.text.SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(java.util.Date(t)))
    }

    // ID unik perangkat (8 digit) diturunkan dari ANDROID_ID
    private fun deviceId(): String {
        val raw = try { Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) }
                  catch (e: Exception) { null } ?: Build.FINGERPRINT
        val d = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        var n = 0L
        for (i in 0 until 4) n = (n shl 8) or (d[i].toLong() and 0xFF)
        return "%08d".format(n % 100_000_000L)
    }

    private fun updateSession() {
        val s = (SystemClock.elapsedRealtime() - sessionStart) / 1000
        findViewById<TextView>(R.id.txtSession).text =
            "%02d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60)
    }

    private fun updateStats() {
        // RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramPct = if (mi.totalMem > 0) (((mi.totalMem - mi.availMem) * 100) / mi.totalMem).toInt() else 0
        findViewById<TextView>(R.id.txtRam).text = ramPct.toString()
        setVerticalBar(ramPct)

        // Storage (partisi data)
        val st = try { StatFs(Environment.getDataDirectory().path) } catch (e: Exception) { null }
        val stPct = if (st != null && st.totalBytes > 0)
            (((st.totalBytes - st.availableBytes) * 100) / st.totalBytes).toInt() else 0
        findViewById<TextView>(R.id.txtStorage).text = stPct.toString()
        findViewById<ProgressBar>(R.id.progStorage).progress = stPct

        // CPU: frekuensi saat ini (kHz) dari sysfs. Kalau diblokir sistem, tampilkan jumlah core.
        val cores = Runtime.getRuntime().availableProcessors()
        var cur = 0L; var max = 0L
        for (i in 0 until cores) {
            cur = maxOf(cur, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/scaling_cur_freq"))
            max = maxOf(max, readLong("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq"))
        }
        val tvCpu = findViewById<TextView>(R.id.txtCpu)
        val tvUnit = findViewById<TextView>(R.id.txtCpuUnit)
        val pbCpu = findViewById<ProgressBar>(R.id.progCpu)
        if (cur > 0) {
            tvCpu.text = String.format(Locale.US, "%.2f", cur / 1_000_000.0)
            tvUnit.text = "GHz"
            pbCpu.progress = if (max > 0) ((cur * 100) / max).toInt().coerceIn(0, 100) else 0
        } else {
            tvCpu.text = cores.toString()
            tvUnit.setText(R.string.cpu_core_unit)
            pbCpu.progress = 0
        }

        // Skor performa: berdasarkan RAM & storage yang masih lega
        val score = (0.6 * (100 - ramPct) + 0.4 * (100 - stPct)).roundToInt().coerceIn(0, 100)
        findViewById<TextView>(R.id.txtScore).text = "$score / 100"
        findViewById<ProgressBar>(R.id.progScore).progress = score
    }

    private fun readLong(path: String): Long =
        try { File(path).readText().trim().toLong() } catch (e: Exception) { 0L }

    private fun setVerticalBar(pct: Int) {
        val p = pct.coerceIn(0, 100)
        val empty = findViewById<View>(R.id.barEmpty)
        val fill = findViewById<View>(R.id.barFill)
        (empty.layoutParams as LinearLayout.LayoutParams).weight = (100 - p).toFloat()
        (fill.layoutParams as LinearLayout.LayoutParams).weight = p.toFloat()
        findViewById<View>(R.id.barTrack).requestLayout()
    }

    private fun updateNet() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = try { cm.getNetworkCapabilities(cm.activeNetwork) } catch (e: Exception) { null }
        val type = when {
            caps == null -> getString(R.string.net_none)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> getString(R.string.net_mobile)
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> getString(R.string.net_other)
        }
        findViewById<TextView>(R.id.txtNetInfo).text = if (caps == null) type else "$type  •  $PING_HOST"
        val tvPing = findViewById<TextView>(R.id.txtPing)
        if (caps == null) { tvPing.text = "—"; return }
        if (pinging) return
        pinging = true
        thread {
            // Latensi = waktu sambung TCP ke host DNS publik
            val ms = try {
                val t0 = SystemClock.elapsedRealtime()
                Socket().use { it.connect(InetSocketAddress(PING_HOST, 443), 2000) }
                (SystemClock.elapsedRealtime() - t0).toInt()
            } catch (e: Exception) { -1 }
            runOnUiThread {
                pinging = false
                tvPing.text = if (ms >= 0) ms.toString() else "—"
            }
        }
    }

    // ===== Pengaturan: hanya Tema & Bahasa =====
    private fun showSettings() {
        val d = Dialog(this, R.style.RyooSheet)
        val v = layoutInflater.inflate(R.layout.dialog_settings, null)
        d.setContentView(v)
        v.findViewById<TextView>(R.id.valTheme).text = optionLabel(THEME_KEYS, if (isPurple()) "purple" else "blue")
        v.findViewById<TextView>(R.id.valLang).text = optionLabel(LANG_KEYS, prefs.getString("lang", "system"))
        // Mode root & kirim key lewat file: tersimpan langsung saat diubah
        bindSwitch(v, R.id.rowRoot, R.id.swRoot, "root", true)
        bindSwitch(v, R.id.rowKeyFile, R.id.swKeyFile, "keyToFile", false)
        bindSwitch(v, R.id.rowAutoUpdate, R.id.swAutoUpdate, "autoUpdate", true)
        v.findViewById<View>(R.id.btnCloseSheet).setOnClickListener { d.dismiss() }
        v.findViewById<View>(R.id.rowTheme).setOnClickListener { d.dismiss(); chooseTheme() }
        v.findViewById<View>(R.id.rowLang).setOnClickListener { d.dismiss(); chooseLang() }
        d.window?.apply {
            setGravity(Gravity.BOTTOM)
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun bindSwitch(v: View, rowId: Int, swId: Int, key: String, def: Boolean) {
        val sw = v.findViewById<androidx.appcompat.widget.SwitchCompat>(swId)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { b, on ->
            prefs.edit().putBoolean(key, on).apply()
            b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        v.findViewById<View>(rowId).setOnClickListener { sw.toggle() }
    }

    private fun optionLabel(keys: Array<String>, key: String?): String {
        val labels = when {
            keys === THEME_KEYS -> arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
            else -> arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        }
        return labels[keys.indexOf(key).coerceAtLeast(0)]
    }

    private fun chooseTheme() {
        val labels = arrayOf(getString(R.string.opt_blue), getString(R.string.opt_purple))
        val cur = if (isPurple()) 1 else 0
        var sel = cur
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.appearance)
            .setSingleChoiceItems(labels, cur) { _, which -> sel = which }
            .setPositiveButton(R.string.ok) { _, _ -> if (sel != cur) switchTheme(THEME_KEYS[sel]) }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    private fun chooseLang() {
        val labels = arrayOf(getString(R.string.opt_system), "Indonesia", "English")
        val cur = LANG_KEYS.indexOf(prefs.getString("lang", "system")).coerceAtLeast(0)
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.language)
            .setSingleChoiceItems(labels, cur) { dlg, which ->
                prefs.edit().putString("lang", LANG_KEYS[which]).apply()
                dlg.dismiss()
                RyooApp.applyLang(LANG_KEYS[which])     // activity dibuat ulang otomatis
            }
            .setNegativeButton(R.string.cancel, null).showGlass()
    }

    // ===== Pilihan command =====
    private fun customCmds(): MutableList<String> {
        val out = mutableListOf<String>()
        try {
            val arr = org.json.JSONArray(prefs.getString("customCmds", "[]"))
            for (i in 0 until arr.length()) out.add(arr.getString(i))
        } catch (_: Exception) { }
        return out
    }

    private fun saveCustomCmds(list: List<String>) {
        prefs.edit().putString("customCmds", org.json.JSONArray(list).toString()).apply()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    private fun themeColor(attr: Int): Int {
        val tv = android.util.TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun showCommandPicker() {
        val dlg = Dialog(this, R.style.RyooDialog)
        val pad = dp(20)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, dp(12)) }

        // Judul + tombol +
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            setText(R.string.cmd_pick_title); textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(themeColor(R.attr.t_text_primary))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(header)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(list) }
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(12) })

        fun pick(cmd: String) { cmdBox.setText(cmd); dlg.dismiss() }

        fun addRow(cmd: String, custom: Boolean, rebuild: () -> Unit) {
            val row = TextView(this).apply {
                text = cmd; textSize = 13f; typeface = android.graphics.Typeface.MONOSPACE
                setTextColor(themeColor(R.attr.t_text_primary))
                setPadding(dp(14), dp(14), dp(14), dp(14))
                setBackgroundResource(R.drawable.bg_chip)
                setOnClickListener { pick(cmd) }
                if (custom) setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity, R.style.RyooDialog)
                        .setTitle(R.string.cmd_delete_title).setMessage(cmd)
                        .setPositiveButton(R.string.cmd_delete) { _, _ ->
                            val l = customCmds(); l.remove(cmd); saveCustomCmds(l); rebuild()
                        }
                        .setNegativeButton(R.string.cancel, null).showGlass()
                    true
                }
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(8) })
        }

        lateinit var rebuild: () -> Unit
        fun showAdd() {
            val input = EditText(this).apply {
                hint = getString(R.string.cmd_add_hint)          // transparan, hilang saat mengetik
                setHintTextColor(themeColor(R.attr.t_text_hint) and 0x00FFFFFF or 0x66000000)
                setTextColor(themeColor(R.attr.t_text_primary))
                textSize = 13f; typeface = android.graphics.Typeface.MONOSPACE
                inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            val box = FrameLayout(this).apply { setPadding(pad, dp(8), pad, 0); addView(input) }
            AlertDialog.Builder(this, R.style.RyooDialog).setTitle(R.string.cmd_add_title).setView(box)
                .setPositiveButton(R.string.cmd_save) { _, _ ->
                    val c = input.text.toString().trim()
                    if (c.isNotEmpty()) {
                        val l = customCmds()
                        if (c !in l && c !in PRESET_CMDS) { l.add(c); saveCustomCmds(l) }
                        rebuild()
                    }
                }
                .setNegativeButton(R.string.cancel, null).showGlass()
        }

        rebuild = {
            list.removeAllViews()
            PRESET_CMDS.forEach { addRow(it, false, rebuild) }
            customCmds().forEach { addRow(it, true, rebuild) }
            val add = TextView(this).apply {
                setText(R.string.cmd_write); textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
                setTextColor(themeColor(R.attr.t_on_accent))
                setBackgroundResource(R.drawable.bg_btn_primary)
                setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_add, 0, 0, 0)
                compoundDrawablePadding = dp(8)
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setOnClickListener { showAdd() }
            }
            list.addView(add, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(4) })
        }
        rebuild()

        root.addView(TextView(this).apply {
            setText(R.string.cmd_hold_hint); textSize = 11f
            setTextColor(themeColor(R.attr.t_text_hint))
        })

        dlg.setContentView(root)
        dlg.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        dlg.window?.setLayout((resources.displayMetrics.widthPixels * 0.9f).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
        dlg.show()
    }

    private fun AlertDialog.Builder.showGlass() {
        val d = create()
        d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        d.show()
    }

    private fun showInfo() {
        AlertDialog.Builder(this, R.style.RyooDialog).setTitle("RyooXIT v${appVersion()}")
            .setMessage(R.string.info_msg)
            .setNeutralButton(R.string.check_update) { _, _ -> updater.check(true) }
            .setPositiveButton(R.string.ok, null).showGlass()
    }

    // ===== Cek tanda tangan APK =====
    // Ganti EXPECTED_SHA256 dengan hash sertifikat keystore kamu sendiri.
    // Cara dapat hash: keytool -list -v -keystore nama.jks -alias alias_kamu
    private fun isSignatureValid(): Boolean {
        return try {
            val sigHash = getSigningSha256() ?: return false
            sigHash.equals(EXPECTED_SHA256, ignoreCase = true)
        } catch (e: Exception) { false }
    }

    @Suppress("DEPRECATION")
    private fun getSigningSha256(): String? {
        val sigs: Array<Signature> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val info = packageManager.getPackageInfo(
                packageName, PackageManager.GET_SIGNING_CERTIFICATES)
            val signingInfo = info.signingInfo ?: return null
            if (signingInfo.hasMultipleSigners()) signingInfo.apkContentsSigners
            else signingInfo.signingCertificateHistory
        } else {
            val info = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES)
            info.signatures ?: return null
        }
        if (sigs.isEmpty()) return null
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(sigs[0].toByteArray())
        return digest.joinToString(":") { b -> "%02X".format(b) }
    }

    // ===== Background terenkripsi (XOR) dari assets/bg_blue.dat & bg_purple.dat (satu foto per tema) =====
    private fun loadBackground() {
        val iv = findViewById<ImageView>(R.id.imgBg)
        val file = if (isPurple()) "bg_purple.dat" else "bg_blue.dat"
        thread {
            try {
                val raw = assets.open(file).readBytes()
                val out = ByteArray(raw.size)
                for (i in raw.indices) out[i] = (raw[i].toInt() xor BG_KEY).toByte()
                val bmp = BitmapFactory.decodeByteArray(out, 0, out.size)
                runOnUiThread { iv.setImageBitmap(bmp) }
            } catch (e: Exception) { /* biarkan background polos kalau gagal */ }
        }
    }

    // Splash: logo + nama dua warna, lalu fade-out (dilewati saat activity dibuat ulang karena ganti tema/bahasa)
    private fun setupSplash(show: Boolean) {
        val splash = findViewById<View>(R.id.splash)
        if (!show) { splash.visibility = View.GONE; return }
        splash.postDelayed({
            splash.animate().alpha(0f).setDuration(600)
                .withEndAction { splash.visibility = View.GONE }.start()
        }, 1200)
    }

    // Logo berdenyut, XIT bercahaya, tombol mengecil saat ditekan
    @SuppressLint("ClickableViewAccessibility")
    private fun setupAnimations(btnRun: Button) {
        ObjectAnimator.ofPropertyValuesHolder(
            findViewById<View>(R.id.imgLogo),
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.07f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.07f)
        ).apply {
            duration = 1400; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        ObjectAnimator.ofFloat(findViewById<View>(R.id.txtXit), View.ALPHA, 1f, 0.55f).apply {
            duration = 1100; repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE; start()
        }
        btnRun.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(80).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
            false
        }
    }

    // Deteksi root ringan (tidak memunculkan popup izin)
    private fun checkRoot() {
        thread {
            val found = try {
                listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
                    "/vendor/bin/su", "/product/bin/su").any { File(it).exists() } ||
                    Runtime.getRuntime().exec(arrayOf("sh", "-c", "command -v su"))
                        .inputStream.bufferedReader().readText().isNotBlank()
            } catch (e: Exception) { false }
            runOnUiThread { rootFound = found; rootChecked = true; applyRootUi() }
        }
    }

    private fun applyRootUi() {
        val tv = findViewById<TextView>(R.id.rootStatus)
        val badge = findViewById<TextView>(R.id.txtRootBadge)
        val sub = findViewById<TextView>(R.id.txtAccessSub)
        if (!rootChecked) {
            tv.setText(R.string.root_checking)
            badge.setText(R.string.root_checking)
            return
        }
        if (rootFound) {
            tv.setText(R.string.root_found)
            tv.setTextColor(Color.parseColor("#3DFF8F"))
            badge.setText(R.string.root_active)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#3DDC84"))
            badge.setTextColor(Color.parseColor("#06301A"))
            sub.setText(R.string.access_sub_root)
        } else {
            tv.setText(R.string.root_not_found)
            tv.setTextColor(Color.parseColor("#FF5A5A"))
            badge.setText(R.string.root_inactive)
            badge.backgroundTintList = ColorStateList.valueOf(Color.parseColor("#FF8A80"))
            badge.setTextColor(Color.parseColor("#4A0A0A"))
            sub.setText(R.string.access_sub_noroot)
        }
    }

    companion object {
        private const val PAGE_HOME = 0
        private const val PAGE_FILE = 1
        private const val PAGE_PROFILE = 2
        private const val FILE_INTERNAL = 0
        private const val FILE_ROOT = 1
        private const val FILE_RECENT = 2
        private const val PING_HOST = "1.1.1.1"
        private const val TEXT_CAP = 48_000          // batas byte saat membaca file teks
        private const val OUT_CAP = 200_000          // batas byte output perintah yang ditampung
        private const val CMD_TIMEOUT_MS = 120_000L  // perintah dihentikan setelah 2 menit
        private val TEXT_EXT = setOf("txt", "log", "conf", "prop", "json", "xml")
        private val sessionStart = SystemClock.elapsedRealtime()

        // GANTI dengan link channel WhatsApp kamu
        const val WA_CHANNEL_URL = "https://whatsapp.com/channel/0029Vb8eX0Z1NCrYCXEXuu0K"
        // GANTI dengan nomor WhatsApp admin (format internasional tanpa + / 0 di depan, contoh 6281234567890)
        const val WA_ADMIN_URL = "https://wa.me/6285861526715"
        const val TIKTOK_URL = "https://www.tiktok.com/@ryoofren?_r=1&_t=ZS-9BE8WQ79dxu"
        private val THEME_KEYS = arrayOf("blue", "purple")
        private var pendingSnapshot: Bitmap? = null
        private val LANG_KEYS = arrayOf("system", "id", "en")
        const val DEFAULT_CMD = "su -c \"cd /data/local/tmp && sh ./RyooXIT.sh\""
        val PRESET_CMDS = listOf(
            DEFAULT_CMD,
            "su -c \"cd /data/local/tmp && sh ./INJECT.sh\""
        )

        // Kunci XOR untuk background terenkripsi (harus sama dengan yang dipakai saat enkripsi).
        const val BG_KEY = 0x5A

        // Hash SHA-256 sertifikat RELEASE resmi kamu.
        // Dapatkan dengan: keytool -list -v -keystore ryooxit.jks -alias ryooxit
        const val EXPECTED_SHA256 =
            "26:A5:E8:E3:4F:9A:AA:5C:EF:4C:A8:F8:FA:9A:EB:5F:36:85:66:33:0C:83:2E:82:E6:B4:DA:31:E1:4C:0C:06"
    }
}
