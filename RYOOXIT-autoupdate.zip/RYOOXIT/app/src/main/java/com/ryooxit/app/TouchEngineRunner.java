package com.ryooxit.app;

import com.zayon.optimize.touch.TouchBridge;

/** Entry point launched by app_process under the user's root grant. */
public final class TouchEngineRunner {
    private TouchEngineRunner() {}

    public static void main(String[] args) {
        if (args == null || args.length != 2) {
            System.err.println("Usage: TouchEngineRunner <absolute-library-path> <config-path>");
            System.exit(64);
            return;
        }
        try {
            System.load(args[0]);
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try { TouchBridge.nativeReleaseAll(); } catch (Throwable ignored) { }
            }, "ryooxit-touch-cleanup"));
            int result = TouchBridge.nativeRun(args[1]);
            System.out.println("nativeRun returned: " + result);
            System.exit(result == 0 ? 0 : 1);
        } catch (Throwable error) {
            error.printStackTrace(System.err);
            System.exit(70);
        }
    }
}
