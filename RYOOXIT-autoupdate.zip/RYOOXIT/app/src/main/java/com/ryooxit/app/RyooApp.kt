package com.ryooxit.app

import android.app.Application
import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

// Menerapkan bahasa tersimpan sejak proses mulai (default "system": ikut bahasa HP).
// Tema Biru/Ungu dipasang di MainActivity.
class RyooApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val p = getSharedPreferences("ryooxit", Context.MODE_PRIVATE)
        applyLang(p.getString("lang", "system") ?: "system")
    }

    companion object {
        fun applyLang(lang: String) {
            AppCompatDelegate.setApplicationLocales(
                if (lang == "system") LocaleListCompat.getEmptyLocaleList()
                else LocaleListCompat.forLanguageTags(lang)
            )
        }
    }
}
