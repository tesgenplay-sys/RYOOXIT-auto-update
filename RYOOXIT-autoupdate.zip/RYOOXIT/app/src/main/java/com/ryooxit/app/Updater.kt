package com.ryooxit.app

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.Signature
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Update otomatis lewat GitHub Releases.
 *
 *  - HP ROOT     : unduh -> verifikasi -> pasang diam-diam via `su -c pm install -r` -> app dibuka lagi sendiri.
 *  - HP NON-ROOT : tampil dialog "Update tersedia" -> unduh -> verifikasi -> installer Android (1x ketuk Instal).
 *
 * Lapisan keamanan (semuanya wajib lolos, kalau gagal update dibatalkan):
 *  1. HTTPS saja (termasuk setiap redirect), host APK dibatasi ke ALLOWED_APK_HOSTS.
 *  2. SHA-256 file APK harus sama dengan yang tertulis di version.json.
 *  3. Nama paket sama, versionCode sama dengan JSON dan LEBIH BESAR dari versi terpasang (anti-downgrade).
 *  4. Sertifikat penanda tangan APK baru harus sama dengan MainActivity.EXPECTED_SHA256.
 *  5. Jalur root: hash dicek ulang di dalam shell root tepat sebelum `pm install`.
 */
class Updater(private val act: AppCompatActivity) {

    private class Info(
        val code: Long,
        val name: String,
        val url: String,
        val sha256: String,
        val changelog: String,
        val force: Boolean
    )

    private val busy = AtomicBoolean(false)
    @Volatile private var dialogShown = false

    // ===================== Titik masuk =====================

    /** manual = true  -> tampilkan pesan "sudah terbaru" / "gagal cek". */
    fun check(manual: Boolean) {
        if (!isConfigured()) {
            if (manual) toast(act.getString(R.string.update_not_configured))
            return
        }
        if (!busy.compareAndSet(false, true)) return
        thread {
            try {
                cleanOldFiles()
                val info = fetchInfo()
                if (info.code <= currentCode()) {
                    if (manual) toast(act.getString(R.string.update_uptodate))
                    return@thread
                }
                if (hasSu()) {
                    toast(act.getString(R.string.update_root_start, info.name))
                    val apk = downloadAndVerify(info, null)
                    rootInstall(apk, info)          // kalau sukses, proses app mati di sini
                    // Sampai di sini berarti pemasangan root gagal -> pakai installer biasa
                    toast(act.getString(R.string.update_root_fail))
                    installNormally(apk)
                } else {
                    showUpdateDialog(info)
                }
            } catch (e: Exception) {
                if (e is SecurityException) toast(act.getString(R.string.update_verify_fail))
                else if (manual) toast(act.getString(R.string.update_check_fail) + (e.message?.let { ": $it" } ?: ""))
            } finally {
                busy.set(false)
            }
        }
    }

    private fun isConfigured() = !UPDATE_JSON_URL.contains("GANTI_")

    // ===================== Dialog (non-root) =====================

    private fun showUpdateDialog(info: Info) {
        if (dialogShown) return
        act.runOnUiThread {
            if (act.isFinishing || act.isDestroyed) return@runOnUiThread
            dialogShown = true
            val b = AlertDialog.Builder(act, R.style.RyooDialog)
                .setTitle(R.string.update_available_title)
                .setMessage(act.getString(R.string.update_available_msg, info.name, info.changelog))
                .setCancelable(!info.force)
                .setPositiveButton(R.string.update_now, null)
            if (!info.force) b.setNegativeButton(R.string.update_later, null)
            val d = b.create()
            d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
            d.setOnDismissListener { dialogShown = false }
            d.show()
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                d.dismiss()
                startManualInstall(info)
            }
        }
    }

    private fun startManualInstall(info: Info) {
        if (!busy.compareAndSet(false, true)) return
        val pd = AlertDialog.Builder(act, R.style.RyooDialog)
            .setTitle(R.string.update_downloading_title)
            .setMessage("0%")
            .setCancelable(false)
            .create()
        pd.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
        pd.show()
        thread {
            try {
                val apk = downloadAndVerify(info) { p -> act.runOnUiThread { pd.setMessage("$p%") } }
                act.runOnUiThread { pd.dismiss() }
                installNormally(apk)
            } catch (e: Exception) {
                act.runOnUiThread { pd.dismiss() }
                if (e is SecurityException) toast(act.getString(R.string.update_verify_fail))
                else toast(act.getString(R.string.update_check_fail) + (e.message?.let { ": $it" } ?: ""))
            } finally {
                busy.set(false)
            }
        }
    }

    // ===================== Ambil version.json =====================

    private fun fetchInfo(): Info {
        val c = openHttps(UPDATE_JSON_URL)
        val bytes = try {
            c.inputStream.use { ins ->
                val bo = ByteArrayOutputStream()
                val buf = ByteArray(4096)
                var total = 0
                while (true) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > 65536) throw IOException("version.json terlalu besar")
                    bo.write(buf, 0, n)
                }
                bo.toByteArray()
            }
        } finally { c.disconnect() }

        val j = JSONObject(String(bytes, Charsets.UTF_8))
        val sha = j.getString("sha256").trim().replace(":", "").lowercase()
        if (!Regex("^[0-9a-f]{64}$").matches(sha)) throw IOException("sha256 di version.json tidak valid")
        val code = j.getLong("versionCode")
        return Info(
            code = code,
            name = j.optString("versionName", code.toString()),
            url = j.getString("apkUrl"),
            sha256 = sha,
            changelog = j.optString("changelog", ""),
            force = j.optBoolean("forceUpdate", false)
        )
    }

    // ===================== Unduh + verifikasi =====================

    private fun downloadAndVerify(info: Info, onProgress: ((Int) -> Unit)?): File {
        val u = URL(info.url)
        if (u.protocol != "https" || u.host !in ALLOWED_APK_HOSTS)
            throw SecurityException("apkUrl tidak diizinkan")

        val dir = File(act.cacheDir, "updates").apply { mkdirs() }
        val apk = File(dir, "RyooXIT-${info.code}.apk")

        // File yang sama sudah pernah diunduh & lolos cek? pakai lagi.
        if (apk.exists()) {
            if (sha256(apk) == info.sha256) {
                try { verifyApk(apk, info); return apk } catch (e: SecurityException) { apk.delete() }
            } else apk.delete()
        }

        val part = File(dir, "RyooXIT-${info.code}.part")
        val c = openHttps(info.url)
        try {
            val total = c.contentLengthLong
            if (total > MAX_APK_BYTES) throw IOException("file terlalu besar")
            var done = 0L
            var lastPct = -1
            c.inputStream.use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (done > MAX_APK_BYTES) throw IOException("file terlalu besar")
                        if (total > 0 && onProgress != null) {
                            val p = (done * 100 / total).toInt()
                            if (p != lastPct) { lastPct = p; onProgress(p) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            part.delete(); throw e
        } finally { c.disconnect() }

        if (sha256(part) != info.sha256) { part.delete(); throw SecurityException("SHA-256 tidak cocok") }
        if (!part.renameTo(apk)) { part.delete(); throw IOException("gagal menyimpan file") }
        try { verifyApk(apk, info) } catch (e: Exception) { apk.delete(); throw e }
        return apk
    }

    /** Cek isi APK: paket, versionCode, dan sertifikat penanda tangan. */
    @Suppress("DEPRECATION")
    private fun verifyApk(apk: File, info: Info) {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES
        else android.content.pm.PackageManager.GET_SIGNATURES
        val pi = act.packageManager.getPackageArchiveInfo(apk.path, flags)
            ?: throw SecurityException("APK tidak bisa dibaca")
        if (pi.packageName != act.packageName) throw SecurityException("nama paket berbeda")
        val vc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi.longVersionCode else pi.versionCode.toLong()
        if (vc != info.code) throw SecurityException("versionCode tidak sesuai JSON")
        if (vc <= currentCode()) throw SecurityException("downgrade ditolak")
        val cert = certSha256(pi) ?: throw SecurityException("tanda tangan tidak ditemukan")
        if (!cert.equals(MainActivity.EXPECTED_SHA256, ignoreCase = true))
            throw SecurityException("tanda tangan APK berbeda")
    }

    @Suppress("DEPRECATION")
    private fun certSha256(pi: PackageInfo): String? {
        val sigs: Array<Signature>? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val si = pi.signingInfo ?: return null
            if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
        } else pi.signatures
        if (sigs == null || sigs.isEmpty()) return null
        val digest = MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray())
        return digest.joinToString(":") { b -> "%02X".format(b) }
    }

    @Suppress("DEPRECATION")
    private fun currentCode(): Long {
        val pi = act.packageManager.getPackageInfo(act.packageName, 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi.longVersionCode else pi.versionCode.toLong()
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(32 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Buka koneksi HTTPS; redirect diikuti manual dan tiap lompatan wajib HTTPS (GitHub me-redirect ke CDN). */
    private fun openHttps(startUrl: String): HttpURLConnection {
        var url = startUrl
        repeat(6) {
            val u = URL(url)
            if (u.protocol != "https") throw SecurityException("hanya HTTPS yang diizinkan")
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.setRequestProperty("Cache-Control", "no-cache")
            c.setRequestProperty("User-Agent", "RyooXIT-Updater")
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrBlank()) throw IOException("redirect tanpa tujuan")
                url = URL(u, loc).toString()
                return@repeat
            }
            if (code != 200) { c.disconnect(); throw IOException("HTTP $code") }
            return c
        }
        throw IOException("terlalu banyak redirect")
    }

    // ===================== Pasang: jalur ROOT =====================

    private fun hasSu(): Boolean = try {
        listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/su/bin/su",
            "/vendor/bin/su", "/product/bin/su").any { File(it).exists() } ||
            Runtime.getRuntime().exec(arrayOf("sh", "-c", "command -v su"))
                .inputStream.bufferedReader().readText().isNotBlank()
    } catch (e: Exception) { false }

    /**
     * Pasang lewat root. Skrip dijalankan terlepas dari app (nohup) karena `pm install -r`
     * pada paket sendiri akan mematikan proses app. Setelah sukses skrip membuka app lagi.
     * Fungsi ini HANYA kembali kalau pemasangan gagal / su ditolak.
     */
    private fun rootInstall(apk: File, info: Info) {
        val pkg = act.packageName
        val log = "/data/local/tmp/ryooxit_update.log"
        val tmp = "/data/local/tmp/ryooxit_update.apk"
        val script = listOf(
            "rm -f $log $tmp",
            "( cp '${apk.absolutePath}' $tmp && chmod 644 $tmp && " +
                "[ \"\$(sha256sum $tmp | cut -d' ' -f1)\" = \"${info.sha256}\" ] && " +
                "pm install -r $tmp ) > $log 2>&1",
            "R=\$?",
            "rm -f $tmp",
            "if [ \$R -eq 0 ]; then am start --user 0 -n $pkg/.MainActivity >/dev/null 2>&1; " +
                "else echo RYOO_FAIL >> $log; fi"
        ).joinToString("\n")

        val sh = File(act.cacheDir, "apply_update.sh")
        sh.writeText(script)

        val code = try {
            ProcessBuilder("su", "-c", "nohup sh ${sh.absolutePath} >/dev/null 2>&1 &")
                .redirectErrorStream(true).start().waitFor()
        } catch (e: Exception) { -1 }
        if (code != 0) return                       // su ditolak / tidak ada

        // Tunggu hasil. Kalau pemasangan sukses, proses ini dimatikan sistem selama menunggu.
        repeat(45) {
            Thread.sleep(1000)
            val out = runSu("cat $log")
            if (out.contains("RYOO_FAIL")) { runSu("rm -f $log"); return }
        }
    }

    private fun runSu(cmd: String): String = try {
        val p = ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start()
        val t = p.inputStream.bufferedReader().readText()
        p.waitFor()
        t
    } catch (e: Exception) { "" }

    // ===================== Pasang: jalur NON-ROOT =====================

    private fun installNormally(apk: File) {
        act.runOnUiThread {
            if (act.isFinishing || act.isDestroyed) return@runOnUiThread
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !act.packageManager.canRequestPackageInstalls()) {
                val d = AlertDialog.Builder(act, R.style.RyooDialog)
                    .setTitle(R.string.update_allow_title)
                    .setMessage(R.string.update_allow_msg)
                    .setPositiveButton(R.string.update_open_settings) { _, _ ->
                        act.startActivity(
                            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}"))
                        )
                    }
                    .setNegativeButton(R.string.cancel, null)
                    .create()
                d.window?.setBackgroundDrawableResource(R.drawable.bg_dialog)
                d.show()
                return@runOnUiThread
            }
            try {
                val uri = FileProvider.getUriForFile(act, "${act.packageName}.fileprovider", apk)
                val i = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                act.startActivity(i)
            } catch (e: Exception) {
                Toast.makeText(act, act.getString(R.string.update_check_fail) + ": " + (e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ===================== Util =====================

    private fun cleanOldFiles() {
        try {
            File(act.cacheDir, "apply_update.sh").delete()
            File(act.cacheDir, "updates").listFiles()?.forEach { if (it.name.endsWith(".part")) it.delete() }
        } catch (_: Exception) { }
    }

    private fun toast(msg: String) {
        act.runOnUiThread { Toast.makeText(act, msg, Toast.LENGTH_LONG).show() }
    }

    companion object {
        // GANTI: user & repo GitHub kamu. File version.json ada di cabang main.
        const val UPDATE_JSON_URL =
            "https://raw.githubusercontent.com/tesgenplay-sys/RYOOXIT-auto-update/main/version.json"

        // Host yang boleh dipakai untuk apkUrl (github.com me-redirect ke CDN GitHub, itu ikut diizinkan).
        private val ALLOWED_APK_HOSTS = setOf("github.com")

        private const val MAX_APK_BYTES = 100L * 1024 * 1024
    }
}
