package com.zayon.optimize.touch;

/** JNI signatures exported by the authorized Zayon ARM64 touch engine. */
public final class TouchBridge {
    private TouchBridge() {}

    public static native int nativeRun(String configPath);
    public static native int nativeRetune();
    public static native int nativeAttach(int value);
    public static native void nativeRelease(int value);
    public static native void nativeReleaseAll();
}
