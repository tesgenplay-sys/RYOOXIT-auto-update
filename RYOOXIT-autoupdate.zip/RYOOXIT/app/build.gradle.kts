import java.util.Properties
import java.io.FileInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Baca keystore.properties (untuk build lokal di Android Studio).
// Kalau tidak ada, pakai variabel environment (dipakai di GitHub Actions / Secrets).
val keystoreProps = Properties()
val keystorePropsFile = rootProject.file("keystore.properties")
if (keystorePropsFile.exists()) {
    keystoreProps.load(FileInputStream(keystorePropsFile))
}
fun prop(name: String): String =
    (keystoreProps.getProperty(name) ?: System.getenv(name) ?: "").toString()

android {
    namespace = "com.ryooxit.app"
    compileSdk = 34

    // AGP 8 menonaktifkan BuildConfig secara default. MainActivity memakai
    // BuildConfig.DEBUG untuk melewati pemeriksaan sertifikat hanya pada debug.
    buildFeatures {
        buildConfig = true
    }
    defaultConfig {
        applicationId = "com.ryooxit.app"
        minSdk = 24
        targetSdk = 34
        versionCode = (project.findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 3
        versionName = (project.findProperty("appVersionName") as String?) ?: "1.0.3"
    }

    signingConfigs {
        create("release") {
            val storeFilePath = prop("RYOOXIT_STORE_FILE")
            if (storeFilePath.isNotBlank()) {
                storeFile = rootProject.file(storeFilePath)
                storePassword = prop("RYOOXIT_STORE_PASSWORD")
                keyAlias = prop("RYOOXIT_KEY_ALIAS")
                keyPassword = prop("RYOOXIT_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        getByName("release") {
            val storeFilePath = prop("RYOOXIT_STORE_FILE")
            if (storeFilePath.isNotBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
            isMinifyEnabled = false
        }
    }

    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
